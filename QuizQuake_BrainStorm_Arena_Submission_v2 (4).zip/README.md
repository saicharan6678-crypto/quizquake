# QuizQuake — BrainStorm Arena (submission)

Full documentation: [`quizquake/README.md`](quizquake/README.md)

```bash
cd quizquake
npm install
npm run dev        # http://localhost:5173
npm test           # server + client test suites
```

Windows: double-click `START_PROJECT.bat`. Requires Node.js 20+.
