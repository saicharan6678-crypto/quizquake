@echo off
title QuizQuake - BrainStorm Arena Launcher
cd /d "%~dp0quizquake"
call START_QUIZQUAKE.bat
