# QuizQuake — BrainStorm Arena

A full-stack Computer Science quiz platform: adaptive difficulty, topic-based assignments, a Big-O complexity lab, an algorithm visualiser, achievements/XP, and PDF reports & certificates.

**Stack:** React 18 + TypeScript + Vite (client) · Node.js + Express + TypeScript (server) · SQLite via `better-sqlite3` · Zod · Vitest

---

## Quick start

Requires **Node.js 20 or newer**.

```bash
npm install        # installs client + server workspaces
npm run dev        # API on :4000, client on :5173
```

Windows: double-click `START_PROJECT.bat` (does the same). Then open <http://localhost:5173>.

| Command | What it does |
| :-- | :-- |
| `npm run dev` | Runs API + Vite dev server together |
| `npm run typecheck` | Strict TypeScript check of client, server and tests |
| `npm test` | Runs the server and client test suites (Vitest) |
| `npm run build` | Production build of client and server |
| `npm start` | Serves the built client and API from one Node process on `:4000` |
| `npm run verify` | typecheck → test → build (what CI runs) |

> `better-sqlite3` ships prebuilt binaries for current Node versions. If `npm install` ever tries to compile it, install the platform build tools (Windows: "Desktop development with C++"; macOS: `xcode-select --install`) or use a Node LTS release.

### Server configuration (environment variables, all optional)

| Variable | Default | Purpose |
| :-- | :-- | :-- |
| `PORT` | `4000` | API port |
| `DB_PATH` | `server/data/quizquake.db` | SQLite file (created and seeded on first start) |
| `CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` | Comma-separated browser origin allow-list |
| `RATE_LIMIT_MAX` | `300` | API requests per IP per minute |
| `WRITE_RATE_LIMIT_MAX` | `60` | POST/DELETE requests per IP per minute |
| `LOG_LEVEL` | `info` | `debug`, `info`, `warn`, `error`, `silent` |

Invalid values stop the server at start-up with a clear message (fail fast).

---

## Architecture

```
quizquake/
├── shared/types.ts                  Shared Question / Attempt contracts
├── server/
│   ├── data/questions.json          Seed data, imported into SQLite on first run
│   ├── src/
│   │   ├── index.ts                 Bootstrap, graceful shutdown
│   │   ├── app.ts                   Express app factory (helmet, CORS, rate limits, routes)
│   │   ├── config.ts                Validated environment configuration
│   │   ├── logger.ts                Structured JSON logger
│   │   ├── errors.ts                HttpError helpers
│   │   ├── db/database.ts           Schema, pragmas, seeding
│   │   ├── repositories/            Data access (questions, attempts) — parameterised SQL only
│   │   ├── validation/schemas.ts    Zod schemas = single source of truth for payloads
│   │   ├── middleware/              validate, error handler, request logger
│   │   └── routes/                  health, questions, attempts/stats
│   └── tests/                       Unit + in-process HTTP tests
└── client/
    └── src/
        ├── api.ts                   Offline-first API client (timeouts, validation, fallbacks)
        ├── validation.ts            Runtime guards for untrusted data
        ├── utils.ts                 Adaptive difficulty, question selection, history
        ├── services/                logger, safeStorage, pdfExport, xpSystem, achievements, soundFX, particles
        ├── components/              UI modules
        └── __tests__/               Unit tests
```

**Layers (server):** `routes → validation → repositories → SQLite`. Routes contain no SQL, repositories contain no HTTP, and `createApp()` is separate from `listen()` so the whole API is testable in-process.

### REST API

| Method & path | Description |
| :-- | :-- |
| `GET /api/health` | Status, uptime, row counts |
| `GET /api/topics` | Distinct topics |
| `GET /api/questions?topic=&difficulty=&limit=&offset=` | Filtered, paged questions (+ `total`) |
| `POST /api/questions` | Create/update a custom question (201 / 200) |
| `POST /api/questions/bulk` | Atomically import up to 500 questions |
| `DELETE /api/questions/:id` | Delete a custom question (built-ins return 403) |
| `GET /api/attempts?limit=` · `POST /api/attempts` | Attempt history |
| `GET /api/stats` | Per-topic attempts, average accuracy, best score |

Errors always use one envelope: `{ "error": { "code", "message", "details?" } }`.

---

## Engineering decisions

- **SQLite instead of a JSON file.** The previous design re-read and re-wrote one file, which fails under concurrent writes. SQLite gives ACID transactions, indexes and WAL-mode concurrent readers; bulk imports run in a single transaction (all-or-nothing). Repositories keep the engine swappable (e.g. PostgreSQL).
- **Validate at every trust boundary.** Zod validates all request bodies, queries and params on the server (types, ranges, lengths, `correctIndex < options.length`, safe ids). The client validates localStorage data, imported files and server responses before using them.
- **No silent failures.** Every former empty `catch` now goes through a logger (`services/logger.ts` on the client, structured JSON logs with request ids on the server). Storage access is centralised in `services/safeStorage.ts`.
- **Offline-first client.** Custom questions are saved locally first and mirrored to the server best-effort; if the API is down the app falls back to the bundled question bank.
- **Security hardening.** Helmet headers (with a CSP that allows Google Fonts), CORS allow-list, global and stricter write rate limits, 1 MB body limit, parameterised SQL only, built-in questions protected from overwrite/deletion, no stack traces in responses.
- **Separation of concerns.** PDF export moved from `utils.ts` to `services/pdfExport.ts`.

## Testing

`npm test` runs Vitest suites covering:

- **Adaptive logic** — every branch of `nextDifficulty`, question selection fallbacks, no-repeat guarantee.
- **Validation** — accepted/rejected payloads for questions, attempts and query parameters.
- **Repositories** — CRUD, filtering, pagination, atomic batch rollback, SQL-injection strings treated as data, built-in protection.
- **HTTP API** — status codes, validation errors, malformed JSON, 413 oversize bodies, 409/403/404 rules, security headers, CORS allow-list, rate limiting (429).
- **Resilience** — storage that throws, corrupted JSON, unreachable server, malformed server responses.

`npm run test:coverage -w server` / `-w client` produce coverage reports.

## Known limitations

- There is no user authentication (not required by the project spec); attempts are stored per installation, not per user.
- Seed questions are stored in SQLite on first run; editing `questions.json` afterwards does not alter an existing database (delete `server/data/quizquake.db` to re-seed).
