@echo off
title QuizQuake: BrainStorm Arena
cd /d "%~dp0"

echo ===================================================
echo     QuizQuake: BrainStorm Arena - Letz Project
echo ===================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js 20 or newer is required to run QuizQuake.
  echo Please download and install Node.js from https://nodejs.org/
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo [1/3] First-time setup detected.
  echo Installing project dependencies (clean npm install)...
  echo This only takes a minute. Please wait...
  call npm install
  if errorlevel 1 (
    echo.
    echo [ERROR] Dependency installation failed.
    pause
    exit /b 1
  )
  echo [SUCCESS] Dependencies installed successfully!
  echo.
)

echo [2/3] Starting QuizQuake Backend and Frontend concurrently...
echo [3/3] Opening web browser at http://localhost:5173 ...
echo.
echo Keep this command window open while testing the application.
echo To stop QuizQuake, press Ctrl+C in this window.
echo.

timeout /t 2 /nobreak >nul
start http://localhost:5173
call npm run dev
pause
