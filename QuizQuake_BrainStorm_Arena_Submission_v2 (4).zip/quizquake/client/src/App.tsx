import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Award,
  BarChart3,
  BookOpen,
  Brain,
  CheckCircle2,
  Clock,
  Cpu,
  Download,
  FileText,
  Flame,
  Layers,
  Play,
  PlusCircle,
  RotateCcw,
  Sparkles,
  Timer,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { deleteQuestionOnServer, fetchAllQuestions, removeCustomQuestion, saveCustomQuestion, syncAttemptToServer } from './api';
import { exportAttemptPdf } from './services/pdfExport';
import { QuestionBankManager } from './components/QuestionBankManager';
import { TopicAssignmentView } from './components/TopicAssignmentView';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { FlashcardsDeck } from './components/FlashcardsDeck';
import { HeroArenaBanner } from './components/HeroArenaBanner';
import { MotionBackground } from './components/MotionBackground';
import { MotionTimerRing } from './components/MotionTimerRing';
import { FloatingNotification, ScoreFloatingBadge } from './components/ScoreFloatingBadge';
import { AchievementsModal } from './components/AchievementsModal';
import { SoundWaveVisualizer } from './components/SoundWaveVisualizer';
import { InteractiveScratchpad } from './components/InteractiveScratchpad';
import { ComboOverdriveBar } from './components/ComboOverdriveBar';
import { InteractiveLifelines } from './components/InteractiveLifelines';
import { CertificateModal } from './components/CertificateModal';
import { ComplexityStudio } from './components/ComplexityStudio';
import { SpeedBlitzView } from './components/SpeedBlitzView';
import { AlgorithmVisualizer } from './components/AlgorithmVisualizer';
import { VivaDefenseModal } from './components/VivaDefenseModal';
import { AttemptSummary, Difficulty, Question, QuizAnswerRecord } from './types';
import {
  getDifficultyThemeClass,
  getTopicThemeClass,
  loadAttemptHistory,
  nextDifficulty,
  pickNextAdaptiveQuestion,
  saveAttempt,
} from './utils';
import { soundFX } from './services/soundFX';
import { particleEngine } from './services/particleExplosion';
import { awardXp, calculatePlayerStats, getPlayerXp, PlayerStats } from './services/xpSystem';
import {
  loadUnlockedAchievements,
  unlockAchievement,
  Achievement,
} from './services/achievements';

type Tab = 'adaptive' | 'assignment' | 'blitz' | 'complexity' | 'algorithm' | 'flashcards' | 'diagnostics' | 'builder';

export default function App() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>('adaptive');
  const [history, setHistory] = useState<AttemptSummary[]>(() => loadAttemptHistory());

  // Sound & XP State
  const [soundActive, setSoundActive] = useState<boolean>(soundFX.enabled);
  const [playerStats, setPlayerStats] = useState<PlayerStats>(() => calculatePlayerStats(getPlayerXp()));
  const [floatingNotification, setFloatingNotification] = useState<FloatingNotification | null>(null);
  const [levelUpAlert, setLevelUpAlert] = useState<{ level: number; title: string } | null>(null);

  // Certificate & Viva Modal State
  const [certificateAttempt, setCertificateAttempt] = useState<AttemptSummary | null>(null);
  const [isVivaModalOpen, setIsVivaModalOpen] = useState(false);

  // Remediation Drill Target
  const [remediationTopic, setRemediationTopic] = useState<string | undefined>(undefined);

  // Achievements State
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => loadUnlockedAchievements());
  const [isAchievementsOpen, setIsAchievementsOpen] = useState(false);
  const [achievementToast, setAchievementToast] = useState<Achievement | null>(null);

  // Adaptive Arena state
  const [arenaRunning, setArenaRunning] = useState(false);
  const [arenaQuestion, setArenaQuestion] = useState<Question | null>(null);
  const [arenaUsedIds, setArenaUsedIds] = useState<Set<string>>(new Set());
  const [arenaDifficulty, setArenaDifficulty] = useState<Difficulty>('Easy');
  const [arenaStreak, setArenaStreak] = useState(0);
  const [arenaBestStreak, setArenaBestStreak] = useState(0);
  const [arenaScore, setArenaScore] = useState(0);
  const [arenaRecords, setArenaRecords] = useState<QuizAnswerRecord[]>([]);
  const [arenaSelected, setArenaSelected] = useState<number | null>(null);
  const [arenaTimeLeft, setArenaTimeLeft] = useState(600);
  const [arenaTotalTime, setArenaTotalTime] = useState(600);
  const [arenaFinishedAttempt, setArenaFinishedAttempt] = useState<AttemptSummary | null>(null);

  // Adaptive Arena Lifelines state
  const [arenaUsed5050, setArenaUsed5050] = useState(false);
  const [arenaUsedFreeze, setArenaUsedFreeze] = useState(false);
  const [arenaUsedClue, setArenaUsedClue] = useState(false);
  const [arenaEliminatedOptions, setArenaEliminatedOptions] = useState<Set<number>>(new Set());
  const [arenaShowClue, setArenaShowClue] = useState(false);
  const [questionStartTime, setQuestionStartTime] = useState<number>(Date.now());

  useEffect(() => {
    fetchAllQuestions().then((data) => {
      setQuestions(data);
      setLoading(false);
    });
  }, []);

  const topics = useMemo(() => Array.from(new Set(questions.map((q) => q.topic))), [questions]);

  const handleToggleSound = () => {
    const newState = soundFX.toggleSound();
    setSoundActive(newState);
  };

  const handleTriggerAchievement = (id: string) => {
    const res = unlockAchievement(id);
    if (res.newlyUnlocked && res.achievement) {
      setUnlockedAchievements(loadUnlockedAchievements());
      soundFX.playVictory();
      particleEngine.fireConfetti(60);
      setAchievementToast(res.achievement);
      setTimeout(() => setAchievementToast(null), 4500);
    }
  };

  const handleAwardXp = (amount: number, reason: string = 'Points Earned!') => {
    const res = awardXp(amount);
    setPlayerStats(res.stats);
    setFloatingNotification({
      id: `xp-${Date.now()}`,
      text: `+${amount} XP! ${reason}`,
      type: 'bonus',
    });

    if (res.stats.level >= 3) {
      handleTriggerAchievement('high_roller');
    }

    if (res.leveledUp) {
      soundFX.playLevelUp();
      particleEngine.fireConfetti(100);
      setLevelUpAlert({ level: res.stats.level, title: res.stats.title });
      setTimeout(() => setLevelUpAlert(null), 4500);
    }
  };

  const handleRecordAttempt = (attempt: AttemptSummary) => {
    setHistory(saveAttempt(attempt));
    void syncAttemptToServer(attempt);
  };

  const handleAddCustomQuestion = (q: Question) => {
    saveCustomQuestion(q);
    setQuestions((prev) => [q, ...prev]);
    handleTriggerAchievement('curator');
  };

  const handleImportQuestions = (qs: Question[]) => {
    qs.forEach((q) => saveCustomQuestion(q));
    setQuestions((prev) => [...qs, ...prev]);
    handleTriggerAchievement('curator');
  };

  const handleDeleteQuestion = (id: string) => {
    setQuestions((prev) => prev.filter((q) => q.id !== id));
    removeCustomQuestion(id);
    void deleteQuestionOnServer(id);
  };

  const startAdaptiveArena = () => {
    soundFX.playClick();
    const used = new Set<string>();
    const first = pickNextAdaptiveQuestion(questions, used, 'Easy', topics[0]);
    if (!first) return;
    used.add(first.id);

    setArenaUsedIds(used);
    setArenaQuestion(first);
    setArenaDifficulty('Easy');
    setArenaStreak(0);
    setArenaBestStreak(0);
    setArenaScore(0);
    setArenaRecords([]);
    setArenaSelected(null);
    setArenaTimeLeft(600);
    setArenaTotalTime(600);
    setArenaFinishedAttempt(null);
    setArenaUsed5050(false);
    setArenaUsedFreeze(false);
    setArenaUsedClue(false);
    setArenaEliminatedOptions(new Set());
    setArenaShowClue(false);
    setQuestionStartTime(Date.now());
    setArenaRunning(true);
  };

  const handleArenaUse5050 = () => {
    if (arenaUsed5050 || !arenaQuestion) return;
    setArenaUsed5050(true);
    handleTriggerAchievement('lifeline_user');

    const wrongIndices = arenaQuestion.options
      .map((_, idx) => idx)
      .filter((idx) => idx !== arenaQuestion.correctIndex);

    const shuffled = wrongIndices.sort(() => Math.random() - 0.5);
    setArenaEliminatedOptions(new Set(shuffled.slice(0, 2)));
  };

  const handleArenaUseFreeze = () => {
    if (arenaUsedFreeze) return;
    setArenaUsedFreeze(true);
    setArenaTimeLeft((t) => t + 30);
    setArenaTotalTime((t) => t + 30);
    handleTriggerAchievement('lifeline_user');
  };

  const finishAdaptiveArena = (finalRecords: QuizAnswerRecord[], finalScore: number, bestStreak: number) => {
    setArenaRunning(false);
    const correctCount = finalRecords.filter((r) => r.isCorrect).length;
    const totalCount = finalRecords.length;
    const accuracyPercent = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;
    const passed = accuracyPercent >= 70;

    const summary: AttemptSummary = {
      id: `arena-${Date.now()}`,
      mode: 'adaptive',
      title: 'Adaptive BrainStorm Arena',
      topicFilter: 'Adaptive Multi-Topic',
      completedAt: new Date().toLocaleString(),
      score: finalScore,
      correctCount,
      totalCount,
      accuracyPercent,
      passed,
      bestStreak,
      records: finalRecords,
    };

    setArenaFinishedAttempt(summary);
    handleRecordAttempt(summary);

    if (accuracyPercent >= 90) {
      handleTriggerAchievement('perfect_pass');
    }

    if (passed) {
      soundFX.playVictory();
      particleEngine.fireConfetti(100);
      handleAwardXp(finalScore + 200, 'Arena Victory Bonus!');
    } else {
      soundFX.playIncorrect();
      handleAwardXp(Math.max(50, finalScore), 'Arena Effort XP');
    }
  };

  useEffect(() => {
    if (!arenaRunning) return;
    if (arenaTimeLeft <= 0) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }
    const id = window.setInterval(() => setArenaTimeLeft((t) => t - 1), 1000);
    return () => window.clearInterval(id);
  }, [arenaRunning, arenaTimeLeft, arenaRecords, arenaScore, arenaBestStreak]);

  const answerAdaptive = (optIdx: number, e?: React.MouseEvent) => {
    if (!arenaQuestion || arenaSelected !== null || arenaEliminatedOptions.has(optIdx)) return;
    setArenaSelected(optIdx);

    const elapsedSeconds = (Date.now() - questionStartTime) / 1000;
    const isCorrect = optIdx === arenaQuestion.correctIndex;
    const newStreak = isCorrect ? arenaStreak + 1 : 0;
    const newBest = Math.max(arenaBestStreak, newStreak);
    const tierPts = arenaQuestion.difficulty === 'Hard' ? 150 : arenaQuestion.difficulty === 'Medium' ? 120 : 100;
    const gained = isCorrect ? tierPts + (newStreak - 1) * 25 : 0;

    if (e) {
      particleEngine.burstAt(e.clientX, e.clientY, isCorrect);
    }

    if (isCorrect) {
      soundFX.playCorrect();
      handleTriggerAchievement('first_blood');

      if (elapsedSeconds <= 5) {
        handleTriggerAchievement('speed_demon');
      }

      if (newStreak >= 5) {
        soundFX.playStreak(newStreak);
        handleTriggerAchievement('streak_5');
        setFloatingNotification({
          id: `streak-${Date.now()}`,
          text: `⚡ OVERDRIVE! ${newStreak}x STREAK! +${gained} pts`,
          type: 'streak',
          x: e?.clientX,
          y: e?.clientY ? e.clientY - 45 : undefined,
        });
      } else if (newStreak >= 3) {
        soundFX.playStreak(newStreak);
        handleTriggerAchievement('streak_3');
        setFloatingNotification({
          id: `streak-${Date.now()}`,
          text: `🔥 ${newStreak}x STREAK! +${gained} pts`,
          type: 'streak',
          x: e?.clientX,
          y: e?.clientY ? e.clientY - 40 : undefined,
        });
      } else {
        setFloatingNotification({
          id: `pts-${Date.now()}`,
          text: `+${gained} pts!`,
          type: 'points',
          x: e?.clientX,
          y: e?.clientY ? e.clientY - 40 : undefined,
        });
      }
    } else {
      soundFX.playIncorrect();
    }

    setArenaStreak(newStreak);
    setArenaBestStreak(newBest);
    setArenaScore((s) => s + gained);

    const rec: QuizAnswerRecord = {
      questionId: arenaQuestion.id,
      topic: arenaQuestion.topic,
      subtopic: arenaQuestion.subtopic,
      difficulty: arenaQuestion.difficulty,
      question: arenaQuestion.question,
      options: arenaQuestion.options,
      selectedIndex: optIdx,
      correctIndex: arenaQuestion.correctIndex,
      isCorrect,
      explanation: arenaQuestion.explanation,
      timeSpentSec: Math.round(elapsedSeconds),
    };
    setArenaRecords((prev) => [...prev, rec]);
  };

  const nextAdaptiveStep = () => {
    soundFX.playClick();
    if (!arenaQuestion) return;
    const lastCorrect = arenaSelected === arenaQuestion.correctIndex;
    const nextDiff = nextDifficulty(arenaDifficulty, arenaStreak, lastCorrect);
    const nextTopic = topics[arenaRecords.length % Math.max(1, topics.length)];

    if (arenaRecords.length >= 10) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }

    const nextQ = pickNextAdaptiveQuestion(questions, arenaUsedIds, nextDiff, nextTopic);
    if (!nextQ) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }

    const updatedUsed = new Set(arenaUsedIds);
    updatedUsed.add(nextQ.id);
    setArenaUsedIds(updatedUsed);
    setArenaDifficulty(nextDiff);
    setArenaQuestion(nextQ);
    setArenaSelected(null);
    setArenaEliminatedOptions(new Set());
    setArenaShowClue(false);
    setQuestionStartTime(Date.now());
  };

  const topicStats = useMemo(() => {
    const map: Record<string, { correct: number; total: number }> = {};
    for (const t of topics) map[t] = { correct: 0, total: 0 };

    for (const att of history) {
      for (const r of att.records) {
        if (!map[r.topic]) map[r.topic] = { correct: 0, total: 0 };
        map[r.topic].total += 1;
        if (r.isCorrect) map[r.topic].correct += 1;
      }
    }

    return Object.entries(map).map(([topicName, val]) => ({
      topic: topicName,
      correct: val.correct,
      total: val.total,
      pct: val.total > 0 ? Math.round((val.correct / val.total) * 100) : 0,
    }));
  }, [history, topics]);

  // Find lowest scoring topic for automated targeted remediation drill
  const weakestTopicStat = useMemo(() => {
    const attempted = topicStats.filter((t) => t.total >= 2);
    if (attempted.length === 0) return null;
    return [...attempted].sort((a, b) => a.pct - b.pct)[0];
  }, [topicStats]);

  const handleLaunchRemediation = (topicName: string) => {
    soundFX.playClick();
    setRemediationTopic(topicName);
    setTab('assignment');
  };

  return (
    <div className="app-shell">
      {/* Motion Background & Dynamic Constellation Mesh */}
      <MotionBackground />

      {/* Floating Kinetic Popup Text */}
      <ScoreFloatingBadge notification={floatingNotification} />

      {/* Interactive Scratchpad Drawer */}
      <InteractiveScratchpad />

      {/* Achievements Modal */}
      <AchievementsModal
        isOpen={isAchievementsOpen}
        onClose={() => setIsAchievementsOpen(false)}
        unlockedIds={unlockedAchievements}
      />

      {/* Certificate of Achievement Modal */}
      {certificateAttempt && (
        <CertificateModal
          attempt={certificateAttempt}
          isOpen={!!certificateAttempt}
          onClose={() => setCertificateAttempt(null)}
        />
      )}

      {/* Invigilator Viva Defense & System Architecture Guide */}
      <VivaDefenseModal
        isOpen={isVivaModalOpen}
        onClose={() => setIsVivaModalOpen(false)}
      />

      {/* Achievement Unlocked Toast Notification */}
      {achievementToast && (
        <div className="achievement-toast animate-fade-up">
          <div className="achievement-toast-icon">{achievementToast.icon}</div>
          <div>
            <div className="toast-badge-tag">TROPHY UNLOCKED</div>
            <strong>{achievementToast.title}</strong>
            <p style={{ margin: 0, fontSize: '0.8rem', opacity: 0.9 }}>{achievementToast.description}</p>
          </div>
        </div>
      )}

      {/* Celebratory Level-Up Banner */}
      {levelUpAlert && (
        <div className="level-up-toast animate-fade-up">
          <div className="level-up-icon-wrap">
            <Trophy size={26} className="text-amber" />
          </div>
          <div>
            <div className="level-up-tag">RANK ADVANCEMENT</div>
            <strong className="level-up-title">
              Level {levelUpAlert.level} — {levelUpAlert.title}
            </strong>
          </div>
        </div>
      )}

      {/* Topbar */}
      <header className="topbar">
        <div className="brand" onClick={() => setTab('adaptive')} style={{ cursor: 'pointer' }}>
          <div className="logo-pulse">
            <Brain size={28} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <h1>QuizQuake: BrainStorm Arena</h1>
              <span className="live-chip">
                <Sparkles size={12} /> {questions.length} Questions Live
              </span>
            </div>
            <p>Adaptive Computer Science Assessment &amp; Topic Assignment Studio</p>
          </div>
        </div>

        {/* Topbar Right Controls */}
        <div className="topbar-right-group">
          {/* Viva Defense & Specs Guide Button */}
          <button
            type="button"
            className="btn btn-secondary btn-sm viva-guide-btn"
            onClick={() => {
              soundFX.playClick();
              setIsVivaModalOpen(true);
            }}
            title="Open Invigilator Viva Defense & System Specs Guide"
          >
            <BookOpen size={14} className="text-cyan" />
            <span>Viva Guide</span>
            <span className="live-chip" style={{ fontSize: '0.62rem', padding: '1px 5px' }}>KIT</span>
          </button>

          {/* Audio Equalizer Waveform */}
          <SoundWaveVisualizer isActive={soundActive} />

          {/* Trophy Room Button */}
          <button
            type="button"
            className="trophy-btn"
            onClick={() => {
              soundFX.playClick();
              setIsAchievementsOpen(true);
            }}
            title="Open Trophy Room & Achievements"
          >
            <Trophy size={16} />
            <span className="trophy-count-pill">{unlockedAchievements.length}</span>
          </button>

          {/* Player Level & XP Header Pill */}
          <div
            className="player-xp-pill"
            title={`${playerStats.currentLevelXp} / ${playerStats.nextLevelXp} XP to Level ${playerStats.level + 1}`}
          >
            <div className="player-level-badge">Lv {playerStats.level}</div>
            <div className="player-xp-details">
              <span className="player-title">{playerStats.title}</span>
              <div className="player-bar-track">
                <div className="player-bar-fill" style={{ width: `${playerStats.progressPercent}%` }} />
              </div>
            </div>
          </div>

          {/* Sound FX Toggle */}
          <button
            type="button"
            className={`sound-toggle-btn ${soundActive ? 'active' : ''}`}
            onClick={handleToggleSound}
            title={soundActive ? 'Mute Sound FX' : 'Enable Sound FX'}
          >
            {soundActive ? <Volume2 size={17} /> : <VolumeX size={17} />}
          </button>
        </div>

        {/* Main Tab Navigation */}
        <nav className="tabs">
          <button
            type="button"
            className={`tab-btn ${tab === 'adaptive' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('adaptive');
            }}
          >
            <Zap size={15} /> Adaptive Arena
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'assignment' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('assignment');
            }}
          >
            <FileText size={15} /> Topic Studio
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'blitz' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('blitz');
            }}
          >
            <Timer size={15} /> Speed Blitz
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'complexity' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('complexity');
            }}
          >
            <Cpu size={15} /> Big-O Lab
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'algorithm' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('algorithm');
            }}
          >
            <Activity size={15} /> Algorithm Sandbox
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'flashcards' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('flashcards');
            }}
          >
            <Layers size={15} /> 3D Flashcards
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'diagnostics' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('diagnostics');
            }}
          >
            <BarChart3 size={15} /> Diagnostics
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'builder' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setTab('builder');
            }}
          >
            <PlusCircle size={15} /> Question Bank
          </button>
        </nav>
      </header>

      <main className="container">
        {loading ? (
          <div className="card animate-stage">
            <div className="shimmer-loader">Loading Computer Science question repository...</div>
          </div>
        ) : (
          <>
            {/* Show Hero Arena Marquee Banner on Arena tab when not running */}
            {tab === 'adaptive' && !arenaRunning && (
              <HeroArenaBanner
                playerStats={playerStats}
                questionCount={questions.length}
                onLaunchArena={startAdaptiveArena}
                onLaunchAssignment={() => setTab('assignment')}
              />
            )}

            {tab === 'adaptive' && (
              <div className="card animate-stage" style={{ marginTop: arenaRunning ? 0 : '1.5rem' }}>
                <div className="row-between" style={{ marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                    <div className="icon-badge gradient-indigo">
                      <Zap size={20} />
                    </div>
                    <div>
                      <h2 style={{ margin: 0 }}>Adaptive BrainStorm Arena</h2>
                      <p className="muted" style={{ margin: '0.2rem 0 0', fontSize: '0.88rem' }}>
                        2 consecutive correct answers elevate tier (Easy → Medium → Hard); 1 miss steps down.
                      </p>
                    </div>
                  </div>
                  {!arenaRunning && (
                    <button type="button" className="btn btn-primary" onClick={startAdaptiveArena}>
                      <Zap size={16} /> Start 10-Question Adaptive Run
                    </button>
                  )}
                </div>

                {arenaRunning && arenaQuestion && (
                  <div key={arenaQuestion.id} className="animate-question-swap">
                    <div className="row-between" style={{ marginBottom: '0.85rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
                        <span className="q-number-pill">Question {arenaRecords.length + 1} of 10</span>
                        <span className={`badge ${getTopicThemeClass(arenaQuestion.topic)}`}>
                          {arenaQuestion.topic}
                        </span>
                        <span className={`badge ${getDifficultyThemeClass(arenaQuestion.difficulty)}`}>
                          {arenaQuestion.difficulty}
                        </span>
                      </div>

                      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
                        <MotionTimerRing secondsLeft={arenaTimeLeft} totalSeconds={arenaTotalTime} />
                        <span className={`streak-pill ${arenaStreak >= 2 ? 'streak-hot' : ''}`}>
                          <Flame size={15} /> Streak: <strong>{arenaStreak}</strong>
                        </span>
                        <span className="score-pill">
                          Score: <strong>{arenaScore}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Interactive Tactical Lifelines */}
                    <InteractiveLifelines
                      used5050={arenaUsed5050}
                      usedFreeze={arenaUsedFreeze}
                      usedClue={arenaUsedClue}
                      clueText={`Key subtopic: ${arenaQuestion.subtopic}. Focus on foundational principles.`}
                      showClue={arenaShowClue}
                      onUse5050={handleArenaUse5050}
                      onUseFreeze={handleArenaUseFreeze}
                      onToggleClue={() => {
                        setArenaUsedClue(true);
                        setArenaShowClue(!arenaShowClue);
                        handleTriggerAchievement('lifeline_user');
                      }}
                    />

                    {/* Dynamic Combo Overdrive Bar */}
                    <div style={{ margin: '0.85rem 0 1.1rem' }}>
                      <ComboOverdriveBar streak={arenaStreak} />
                    </div>

                    <h3 className="question-heading">{arenaQuestion.question}</h3>

                    <div className="stack-sm">
                      {arenaQuestion.options.map((opt, idx) => {
                        const isEliminated = arenaEliminatedOptions.has(idx);
                        let extra = '';
                        if (arenaSelected !== null) {
                          if (idx === arenaQuestion.correctIndex) extra = 'correct-opt';
                          else if (idx === arenaSelected) extra = 'wrong-opt';
                        }
                        if (isEliminated) extra += ' eliminated-opt';

                        return (
                          <button
                            key={opt}
                            type="button"
                            disabled={arenaSelected !== null || isEliminated}
                            onClick={(e) => answerAdaptive(idx, e)}
                            className={`option-btn animate-stagger ${extra}`}
                            style={{ animationDelay: `${idx * 45}ms` }}
                          >
                            <span className="opt-key">{idx + 1}</span>
                            <span style={{ flexGrow: 1 }}>
                              {opt} {isEliminated && <span className="eliminated-tag">[Eliminated]</span>}
                            </span>
                            {arenaSelected !== null && idx === arenaQuestion.correctIndex && (
                              <CheckCircle2 size={18} className="text-emerald" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {arenaSelected !== null && (
                      <div className="explanation-box animate-fade-up">
                        <p style={{ margin: '0 0 0.85rem' }}>
                          <strong>
                            {arenaSelected === arenaQuestion.correctIndex ? 'Correct!' : 'Incorrect:'}
                          </strong>{' '}
                          {arenaQuestion.explanation}
                        </p>
                        <button type="button" className="btn btn-primary" onClick={nextAdaptiveStep}>
                          {arenaRecords.length >= 10 ? 'Finish Adaptive Run' : 'Next Adaptive Question'}
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {!arenaRunning && arenaFinishedAttempt && (
                  <div className="report-hero hero-pass animate-fade-up" style={{ marginTop: '1rem' }}>
                    <div className="row-between">
                      <div>
                        <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                          <CheckCircle2 size={20} /> Adaptive Run Complete
                        </h3>
                        <p style={{ margin: '0.35rem 0 0', opacity: 0.92 }}>
                          Score: <strong>{arenaFinishedAttempt.score} pts</strong> • Accuracy:{' '}
                          <strong>
                            {arenaFinishedAttempt.correctCount}/{arenaFinishedAttempt.totalCount} (
                            {arenaFinishedAttempt.accuracyPercent}%)
                          </strong>{' '}
                          • Best Streak: <strong>{arenaFinishedAttempt.bestStreak}</strong>
                        </p>
                      </div>
                      <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                        {arenaFinishedAttempt.passed && (
                          <button
                            type="button"
                            className="btn btn-secondary btn-sm"
                            onClick={() => setCertificateAttempt(arenaFinishedAttempt)}
                          >
                            <Award size={14} /> Official Certificate
                          </button>
                        )}
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm"
                          onClick={() => exportAttemptPdf(arenaFinishedAttempt)}
                        >
                          <Download size={14} /> Download PDF
                        </button>
                        <button
                          type="button"
                          className="btn btn-primary btn-sm"
                          onClick={startAdaptiveArena}
                        >
                          <RotateCcw size={14} /> Run Again
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === 'assignment' && (
              <TopicAssignmentView
                questions={questions}
                history={history}
                onSaveAttempt={handleRecordAttempt}
                onAwardXp={(xp) => handleAwardXp(xp, 'Topic Drill Passed!')}
                onUnlockAchievement={handleTriggerAchievement}
                onGenerateCertificate={(att) => setCertificateAttempt(att)}
                defaultTopic={remediationTopic}
              />
            )}

            {tab === 'blitz' && (
              <SpeedBlitzView
                questions={questions}
                onAwardXp={handleAwardXp}
                onUnlockAchievement={handleTriggerAchievement}
              />
            )}

            {tab === 'complexity' && (
              <ComplexityStudio />
            )}

            {tab === 'algorithm' && (
              <AlgorithmVisualizer />
            )}

            {tab === 'flashcards' && (
              <FlashcardsDeck questions={questions} topics={topics} />
            )}

            {tab === 'diagnostics' && (
              <div className="card animate-stage">
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.5rem' }}>
                  <div className="icon-badge gradient-indigo">
                    <BarChart3 size={20} />
                  </div>
                  <div>
                    <h2 style={{ margin: 0 }}>Diagnostic Mastery &amp; Academic Analytics</h2>
                    <span className="muted" style={{ fontSize: '0.86rem' }}>
                      Skill radar, accuracy distribution, targeted remediation &amp; official verification
                    </span>
                  </div>
                </div>

                {/* Automated Weak-Spot Remediation Recommendation */}
                {weakestTopicStat && weakestTopicStat.pct < 75 && (
                  <div className="remediation-alert-box animate-fade-up">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                      <AlertTriangle size={20} className="text-amber" />
                      <div>
                        <strong>Targeted Remediation Opportunity Detected</strong>
                        <p style={{ margin: '0.2rem 0 0', fontSize: '0.85rem', color: '#cbd5e1' }}>
                          Your lowest competency topic is <strong>{weakestTopicStat.topic}</strong> ({weakestTopicStat.pct}% mastery).
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => handleLaunchRemediation(weakestTopicStat.topic)}
                    >
                      <Play size={13} /> Launch Remediation Drill
                    </button>
                  </div>
                )}

                {/* Interactive Chart.js Graphics */}
                <AnalyticsCharts topicStats={topicStats} history={history} />

                {/* Topic Breakdown Bars */}
                <div className="mastery-grid" style={{ marginTop: '1.6rem' }}>
                  {topicStats.map((st, i) => (
                    <div
                      key={st.topic}
                      className={`mastery-card animate-stagger ${getTopicThemeClass(st.topic)}`}
                      style={{ animationDelay: `${i * 60}ms` }}
                    >
                      <div className="row-between">
                        <strong>{st.topic}</strong>
                        <span className="mastery-pct">
                          {st.pct}% ({st.correct}/{st.total})
                        </span>
                      </div>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width: `${st.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </div>

                <h3 style={{ marginTop: '2rem' }}>All Saved Academic Attempts ({history.length})</h3>
                {history.length === 0 ? (
                  <p className="muted">No attempts recorded yet. Launch an Adaptive Run or Topic Assignment to generate analytics!</p>
                ) : (
                  <div className="stack-sm">
                    {history.map((att, idx) => (
                      <div
                        key={att.id}
                        className="history-item animate-stagger"
                        style={{ animationDelay: `${idx * 50}ms` }}
                      >
                        <div>
                          <strong>{att.title}</strong> • <span className="badge badge-indigo">{att.topicFilter}</span>
                          <div className="muted" style={{ fontSize: '0.82rem', marginTop: '0.2rem' }}>
                            {att.completedAt}
                          </div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                          <span>
                            <strong>{att.score} pts</strong> ({att.accuracyPercent}%)
                          </span>
                          {att.passed && (
                            <button
                              type="button"
                              className="btn btn-secondary btn-sm"
                              onClick={() => setCertificateAttempt(att)}
                              title="Generate Official Credential Certificate"
                            >
                              <Award size={14} /> Certificate
                            </button>
                          )}
                          <button
                            type="button"
                            className="btn btn-secondary btn-sm"
                            onClick={() => exportAttemptPdf(att)}
                          >
                            <Download size={14} /> PDF
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {tab === 'builder' && (
              <QuestionBankManager
                existingTopics={topics}
                allQuestions={questions}
                onAddQuestion={handleAddCustomQuestion}
                onImportQuestions={handleImportQuestions}
                onDeleteQuestion={handleDeleteQuestion}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
