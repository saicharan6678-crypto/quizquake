import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { INITIAL_ACHIEVEMENTS, loadUnlockedAchievements, unlockAchievement } from '../services/achievements';
import { installMemoryStorage } from './helpers';

describe('achievements', () => {
  beforeEach(() => {
    installMemoryStorage();
  });
  afterEach(() => vi.unstubAllGlobals());

  it('has unique ids', () => {
    const ids = INITIAL_ACHIEVEMENTS.map((a) => a.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('unlocks an achievement once and persists it', () => {
    const first = unlockAchievement('streak_3');
    expect(first.newlyUnlocked).toBe(true);
    expect(first.achievement?.title).toBe('Hot Streak');
    expect(unlockAchievement('streak_3').newlyUnlocked).toBe(false);
    expect(loadUnlockedAchievements()).toEqual(['streak_3']);
  });

  it('ignores corrupted storage and non-string entries', () => {
    localStorage.setItem('quizquake_unlocked_achievements_v1', '[1,"streak_5",null]');
    expect(loadUnlockedAchievements()).toEqual(['streak_5']);
    localStorage.setItem('quizquake_unlocked_achievements_v1', '{{{');
    expect(loadUnlockedAchievements()).toEqual([]);
  });
});
