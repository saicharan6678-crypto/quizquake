import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fetchAllQuestions, loadCustomQuestions, removeCustomQuestion, saveCustomQuestion, syncAttemptToServer } from '../api';
import { installMemoryStorage, makeAttempt, makeQuestion } from './helpers';

function mockFetch(impl: (url: string, init?: RequestInit) => Promise<Partial<Response>>) {
  const fn = vi.fn(impl as unknown as typeof fetch);
  vi.stubGlobal('fetch', fn);
  return fn;
}

describe('client API layer', () => {
  beforeEach(() => {
    installMemoryStorage();
    ['warn', 'info', 'error', 'debug'].forEach((m) => vi.spyOn(console, m as 'warn').mockImplementation(() => undefined));
  });
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  describe('fetchAllQuestions', () => {
    it('uses the server bank when reachable and merges custom questions first', async () => {
      saveCustomQuestionOffline(makeQuestion({ id: 'mine' }));
      mockFetch(async () => ({
        ok: true,
        json: async () => ({ questions: [makeQuestion({ id: 'srv-1' }), makeQuestion({ id: 'srv-2' })] }),
      }));
      const all = await fetchAllQuestions();
      expect(all.map((q) => q.id)).toEqual(['mine', 'srv-1', 'srv-2']);
    });

    it('falls back to the bundled bank when the server is down (no crash)', async () => {
      mockFetch(async () => {
        throw new Error('ECONNREFUSED');
      });
      const all = await fetchAllQuestions();
      expect(all.length).toBeGreaterThan(0);
    });

    it('falls back on HTTP errors and ignores malformed server payloads', async () => {
      mockFetch(async () => ({ ok: false, status: 500 }));
      expect((await fetchAllQuestions()).length).toBeGreaterThan(0);

      mockFetch(async () => ({ ok: true, json: async () => ({ questions: [{ broken: true }] }) }));
      const all = await fetchAllQuestions();
      expect(all.every((q) => typeof q.id === 'string' && q.options.length >= 2)).toBe(true);
    });

    it('de-duplicates when a custom question is also on the server', async () => {
      saveCustomQuestionOffline(makeQuestion({ id: 'dup' }));
      mockFetch(async () => ({ ok: true, json: async () => ({ questions: [makeQuestion({ id: 'dup' })] }) }));
      const all = await fetchAllQuestions();
      expect(all.filter((q) => q.id === 'dup')).toHaveLength(1);
    });
  });

  describe('saveCustomQuestion', () => {
    it('stores locally and mirrors to the server', async () => {
      const fetchMock = mockFetch(async () => ({ ok: true }));
      saveCustomQuestion(makeQuestion({ id: 'new' }));
      expect(loadCustomQuestions().map((q) => q.id)).toEqual(['new']);
      await Promise.resolve();
      expect(fetchMock).toHaveBeenCalledWith('/api/questions', expect.objectContaining({ method: 'POST' }));
    });

    it('refuses invalid questions', () => {
      const fetchMock = mockFetch(async () => ({ ok: true }));
      saveCustomQuestion({ ...makeQuestion(), options: ['only one'] });
      expect(loadCustomQuestions()).toEqual([]);
      expect(fetchMock).not.toHaveBeenCalled();
    });

    it('keeps the local copy when the server is unreachable', async () => {
      mockFetch(async () => {
        throw new Error('offline');
      });
      saveCustomQuestion(makeQuestion({ id: 'offline' }));
      await new Promise((r) => setTimeout(r, 0));
      expect(loadCustomQuestions()).toHaveLength(1);
    });

    it('replaces an existing question with the same id and supports removal', () => {
      mockFetch(async () => ({ ok: true }));
      saveCustomQuestion(makeQuestion({ id: 'x', question: 'v1' }));
      saveCustomQuestion(makeQuestion({ id: 'x', question: 'v2' }));
      expect(loadCustomQuestions()).toHaveLength(1);
      expect(loadCustomQuestions()[0].question).toBe('v2');
      removeCustomQuestion('x');
      expect(loadCustomQuestions()).toEqual([]);
    });
  });

  describe('loadCustomQuestions', () => {
    it('drops corrupted entries from localStorage', () => {
      localStorage.setItem('quizquake_custom_questions_v1', JSON.stringify([makeQuestion({ id: 'ok' }), { junk: 1 }]));
      expect(loadCustomQuestions().map((q) => q.id)).toEqual(['ok']);
    });
  });

  describe('syncAttemptToServer', () => {
    it('returns true on success, false on rejection or network failure', async () => {
      mockFetch(async () => ({ ok: true }));
      expect(await syncAttemptToServer(makeAttempt())).toBe(true);
      mockFetch(async () => ({ ok: false, status: 400 }));
      expect(await syncAttemptToServer(makeAttempt())).toBe(false);
      mockFetch(async () => {
        throw new Error('offline');
      });
      expect(await syncAttemptToServer(makeAttempt())).toBe(false);
    });
  });
});

function saveCustomQuestionOffline(q: ReturnType<typeof makeQuestion>) {
  mockFetch(async () => ({ ok: true }));
  saveCustomQuestion(q);
}
