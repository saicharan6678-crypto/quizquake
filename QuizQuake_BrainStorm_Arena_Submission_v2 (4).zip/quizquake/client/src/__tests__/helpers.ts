import { vi } from 'vitest';
import type { AttemptSummary, Question } from '../types';

/** Minimal in-memory localStorage replacement for the node test environment. */
export function installMemoryStorage(options: { throwOnWrite?: boolean; throwOnRead?: boolean } = {}) {
  const store = new Map<string, string>();
  const storage = {
    getItem: (k: string) => {
      if (options.throwOnRead) throw new Error('storage disabled');
      return store.has(k) ? (store.get(k) as string) : null;
    },
    setItem: (k: string, v: string) => {
      if (options.throwOnWrite) throw new Error('QuotaExceededError');
      store.set(k, String(v));
    },
    removeItem: (k: string) => void store.delete(k),
    clear: () => store.clear(),
  };
  vi.stubGlobal('localStorage', storage);
  return { store, storage };
}

export function makeQuestion(overrides: Partial<Question> = {}): Question {
  return {
    id: 'q-1',
    topic: 'Data Structures',
    subtopic: 'Stacks',
    difficulty: 'Easy',
    question: 'Which principle governs a stack?',
    options: ['LIFO', 'FIFO', 'Random', 'Priority'],
    correctIndex: 0,
    explanation: 'Last in, first out.',
    ...overrides,
  };
}

export function makeAttempt(overrides: Partial<AttemptSummary> = {}): AttemptSummary {
  return {
    id: 'att-1',
    mode: 'assignment',
    title: 'Stacks',
    topicFilter: 'Data Structures',
    completedAt: '2026-11-20T10:00:00.000Z',
    score: 100,
    correctCount: 1,
    totalCount: 1,
    accuracyPercent: 100,
    passed: true,
    bestStreak: 1,
    records: [],
    ...overrides,
  };
}
