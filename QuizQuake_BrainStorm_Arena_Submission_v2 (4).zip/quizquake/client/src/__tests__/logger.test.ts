import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { logger } from '../services/logger';

describe('client logger', () => {
  beforeEach(() => {
    logger.clear();
    vi.spyOn(console, 'warn').mockImplementation(() => undefined);
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    vi.spyOn(console, 'info').mockImplementation(() => undefined);
    vi.spyOn(console, 'debug').mockImplementation(() => undefined);
  });
  afterEach(() => vi.restoreAllMocks());

  it('records entries with scope, message and error detail', () => {
    logger.error('api', 'boom', new TypeError('bad'));
    const [entry] = logger.getRecent();
    expect(entry).toMatchObject({ level: 'error', scope: 'api', message: 'boom', detail: 'TypeError: bad' });
    expect(console.error).toHaveBeenCalled();
  });

  it('routes each level to the matching console method', () => {
    logger.warn('s', 'w');
    logger.info('s', 'i');
    logger.debug('s', 'd');
    expect(console.warn).toHaveBeenCalledTimes(1);
    expect(console.info).toHaveBeenCalledTimes(1);
    expect(console.debug).toHaveBeenCalledTimes(1);
  });

  it('keeps a bounded ring buffer', () => {
    for (let i = 0; i < 150; i++) logger.info('s', `m${i}`);
    const recent = logger.getRecent();
    expect(recent).toHaveLength(100);
    expect(recent[recent.length - 1].message).toBe('m149');
  });
});
