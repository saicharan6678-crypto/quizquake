import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { logger } from '../services/logger';
import { readItem, readJson, writeItem, writeJson } from '../services/safeStorage';
import { installMemoryStorage } from './helpers';

describe('safeStorage', () => {
  beforeEach(() => {
    logger.clear();
    vi.spyOn(console, 'warn').mockImplementation(() => undefined);
  });
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('reads and writes values when storage works', () => {
    installMemoryStorage();
    expect(writeItem('k', 'v')).toBe(true);
    expect(readItem('k')).toBe('v');
    expect(writeJson('j', { a: 1 })).toBe(true);
    expect(readJson('j', null)).toEqual({ a: 1 });
  });

  it('returns fallbacks and LOGS (never silently swallows) when storage throws', () => {
    installMemoryStorage({ throwOnRead: true, throwOnWrite: true });
    expect(readItem('k')).toBeNull();
    expect(writeItem('k', 'v')).toBe(false);
    expect(readJson('k', 'fallback')).toBe('fallback');
    const recent = logger.getRecent();
    expect(recent.length).toBeGreaterThanOrEqual(2);
    expect(recent.every((e) => e.level === 'warn' && e.scope === 'storage')).toBe(true);
  });

  it('falls back and logs on corrupted JSON', () => {
    installMemoryStorage();
    localStorage.setItem('bad', '{oops');
    expect(readJson('bad', [])).toEqual([]);
    expect(logger.getRecent().some((e) => e.message.includes('Corrupted JSON'))).toBe(true);
  });

  it('reports failure for unserialisable values', () => {
    installMemoryStorage();
    const circular: Record<string, unknown> = {};
    circular.self = circular;
    expect(writeJson('c', circular)).toBe(false);
  });
});
