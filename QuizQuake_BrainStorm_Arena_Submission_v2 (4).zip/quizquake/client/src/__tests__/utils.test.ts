import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  getDifficultyThemeClass,
  getTopicThemeClass,
  HISTORY_STORAGE_KEY,
  loadAttemptHistory,
  nextDifficulty,
  pickNextAdaptiveQuestion,
  saveAttempt,
} from '../utils';
import { installMemoryStorage, makeAttempt, makeQuestion } from './helpers';

describe('nextDifficulty (adaptive scaling)', () => {
  it.each([
    ['Easy', 0, false, 'Easy'],
    ['Medium', 0, false, 'Easy'],
    ['Hard', 0, false, 'Medium'],
    ['Easy', 1, true, 'Easy'],
    ['Medium', 1, true, 'Medium'],
    ['Hard', 1, true, 'Hard'],
    ['Easy', 2, true, 'Medium'],
    ['Medium', 2, true, 'Hard'],
    ['Hard', 3, true, 'Hard'],
  ] as const)('%s with streak %i (correct=%s) -> %s', (current, streak, correct, expected) => {
    expect(nextDifficulty(current, streak, correct)).toBe(expected);
  });
});

describe('pickNextAdaptiveQuestion', () => {
  const bank = [
    makeQuestion({ id: 'e-ds', difficulty: 'Easy', topic: 'Data Structures' }),
    makeQuestion({ id: 'e-os', difficulty: 'Easy', topic: 'Operating Systems' }),
    makeQuestion({ id: 'h-ds', difficulty: 'Hard', topic: 'Data Structures' }),
  ];

  beforeEach(() => {
    vi.spyOn(Math, 'random').mockReturnValue(0);
  });
  afterEach(() => vi.restoreAllMocks());

  it('returns null when the bank is exhausted or empty', () => {
    expect(pickNextAdaptiveQuestion([], new Set(), 'Easy')).toBeNull();
    expect(pickNextAdaptiveQuestion(bank, new Set(bank.map((q) => q.id)), 'Easy')).toBeNull();
  });

  it('prefers the exact difficulty + topic match', () => {
    expect(pickNextAdaptiveQuestion(bank, new Set(), 'Easy', 'Operating Systems')?.id).toBe('e-os');
  });

  it('falls back to the same difficulty when the topic has none', () => {
    expect(pickNextAdaptiveQuestion(bank, new Set(), 'Hard', 'Operating Systems')?.id).toBe('h-ds');
  });

  it('falls back to any unused question when the difficulty is exhausted', () => {
    expect(pickNextAdaptiveQuestion(bank, new Set(['h-ds']), 'Hard')?.id).toBe('e-ds');
  });

  it('never repeats a used question', () => {
    const used = new Set(['e-ds']);
    expect(pickNextAdaptiveQuestion(bank, used, 'Easy', 'Data Structures')?.id).not.toBe('e-ds');
  });
});

describe('theme helpers', () => {
  it('maps topics to theme classes', () => {
    expect(getTopicThemeClass('Data Structures')).toBe('topic-ds');
    expect(getTopicThemeClass('Algorithms')).toBe('topic-algo');
    expect(getTopicThemeClass('Operating Systems')).toBe('topic-os');
    expect(getTopicThemeClass('Computer Networks')).toBe('topic-net');
    expect(getTopicThemeClass('Databases')).toBe('topic-custom');
  });

  it('maps difficulties to theme classes', () => {
    expect(getDifficultyThemeClass('Easy')).toBe('diff-easy');
    expect(getDifficultyThemeClass('Medium')).toBe('diff-medium');
    expect(getDifficultyThemeClass('Hard')).toBe('diff-hard');
  });
});

describe('attempt history persistence', () => {
  beforeEach(() => {
    installMemoryStorage();
  });
  afterEach(() => vi.unstubAllGlobals());

  it('returns an empty list when nothing is stored', () => {
    expect(loadAttemptHistory()).toEqual([]);
  });

  it('saves newest first and caps history at 20 entries', () => {
    for (let i = 0; i < 25; i++) saveAttempt(makeAttempt({ id: `a${i}` }));
    const history = loadAttemptHistory();
    expect(history).toHaveLength(20);
    expect(history[0].id).toBe('a24');
  });

  it('recovers from corrupted storage instead of crashing', () => {
    localStorage.setItem(HISTORY_STORAGE_KEY, '{not valid json');
    expect(loadAttemptHistory()).toEqual([]);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify({ not: 'an array' }));
    expect(loadAttemptHistory()).toEqual([]);
  });
});
