import { describe, expect, it } from 'vitest';
import { isValidAttempt, isValidQuestion, partitionQuestions } from '../validation';
import { makeAttempt, makeQuestion } from './helpers';

describe('isValidQuestion', () => {
  it('accepts a well-formed question', () => {
    expect(isValidQuestion(makeQuestion())).toBe(true);
  });

  it.each([
    ['null', null],
    ['a string', 'question'],
    ['missing options', { ...makeQuestion(), options: undefined }],
    ['one option only', makeQuestion({ options: ['A'] })],
    ['correctIndex out of range', makeQuestion({ correctIndex: 4 })],
    ['negative correctIndex', makeQuestion({ correctIndex: -1 })],
    ['unknown difficulty', { ...makeQuestion(), difficulty: 'Brutal' }],
    ['blank question', makeQuestion({ question: '   ' })],
    ['non-string option', { ...makeQuestion(), options: ['A', 2, 'C'] }],
  ])('rejects %s', (_label, value) => {
    expect(isValidQuestion(value)).toBe(false);
  });
});

describe('partitionQuestions', () => {
  it('splits valid from rejected and drops duplicate ids', () => {
    const result = partitionQuestions([makeQuestion({ id: 'a' }), makeQuestion({ id: 'a' }), { nope: true }, makeQuestion({ id: 'b' })]);
    expect(result.valid.map((q) => q.id)).toEqual(['a', 'b']);
    expect(result.rejected).toBe(2);
  });

  it('handles non-array input safely', () => {
    expect(partitionQuestions({})).toEqual({ valid: [], rejected: 0 });
    expect(partitionQuestions(undefined)).toEqual({ valid: [], rejected: 0 });
  });
});

describe('isValidAttempt', () => {
  it('accepts a real attempt and rejects broken ones', () => {
    expect(isValidAttempt(makeAttempt())).toBe(true);
    expect(isValidAttempt({ ...makeAttempt(), mode: 'cheat' })).toBe(false);
    expect(isValidAttempt({ ...makeAttempt(), records: 'x' })).toBe(false);
    expect(isValidAttempt(undefined)).toBe(false);
  });
});
