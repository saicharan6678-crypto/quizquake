import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { awardXp, calculatePlayerStats, getPlayerXp, XP_STORAGE_KEY } from '../services/xpSystem';
import { installMemoryStorage } from './helpers';

describe('calculatePlayerStats', () => {
  it('starts at level 1 with zero progress', () => {
    expect(calculatePlayerStats(0)).toMatchObject({ level: 1, title: 'Script Novice', progressPercent: 0, nextLevelXp: 300 });
  });

  it('promotes exactly at each rank threshold', () => {
    expect(calculatePlayerStats(299).level).toBe(1);
    expect(calculatePlayerStats(300).level).toBe(2);
    expect(calculatePlayerStats(800).level).toBe(3);
    expect(calculatePlayerStats(8500).level).toBe(8);
  });

  it('reports mid-level progress as a percentage', () => {
    expect(calculatePlayerStats(150).progressPercent).toBe(50);
  });

  it('keeps working beyond the final rank and never exceeds 100%', () => {
    const stats = calculatePlayerStats(50_000);
    expect(stats.level).toBe(8);
    expect(stats.progressPercent).toBeLessThanOrEqual(100);
  });
});

describe('awardXp', () => {
  beforeEach(() => {
    installMemoryStorage();
  });
  afterEach(() => vi.unstubAllGlobals());

  it('accumulates and persists XP', () => {
    awardXp(100);
    const res = awardXp(50);
    expect(res.newTotal).toBe(150);
    expect(getPlayerXp()).toBe(150);
  });

  it('flags a level-up when a threshold is crossed', () => {
    expect(awardXp(299).leveledUp).toBe(false);
    expect(awardXp(1).leveledUp).toBe(true);
  });

  it('ignores negative awards', () => {
    awardXp(100);
    expect(awardXp(-500).newTotal).toBe(100);
  });

  it('treats corrupted stored values as zero', () => {
    localStorage.setItem(XP_STORAGE_KEY, 'banana');
    expect(getPlayerXp()).toBe(0);
  });
});

describe('awardXp when storage is unavailable', () => {
  afterEach(() => vi.unstubAllGlobals());

  it('does not throw and still reports the computed result', () => {
    installMemoryStorage({ throwOnRead: true, throwOnWrite: true });
    expect(() => awardXp(10)).not.toThrow();
    expect(awardXp(10).newTotal).toBe(10);
  });
});
