import { AttemptSummary, Question } from './types';
import fallbackQuestions from '../../server/data/questions.json';
import { logger } from './services/logger';
import { readJson, writeJson } from './services/safeStorage';
import { isValidQuestion, partitionQuestions } from './validation';

const CUSTOM_QUESTIONS_KEY = 'quizquake_custom_questions_v1';
const REQUEST_TIMEOUT_MS = 5000;

async function request(path: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(path, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

export function loadCustomQuestions(): Question[] {
  const raw = readJson<unknown>(CUSTOM_QUESTIONS_KEY, []);
  const { valid, rejected } = partitionQuestions(raw);
  if (rejected > 0) logger.warn('api', `Dropped ${rejected} invalid custom question(s) from local storage`);
  return valid;
}

/** Persists locally first (works offline) and then mirrors to the server on a best-effort basis. */
export function saveCustomQuestion(q: Question): Question[] {
  if (!isValidQuestion(q)) {
    logger.warn('api', 'Refused to save an invalid question');
    return loadCustomQuestions();
  }
  const next = [q, ...loadCustomQuestions().filter((x) => x.id !== q.id)];
  writeJson(CUSTOM_QUESTIONS_KEY, next);
  void syncQuestionToServer(q);
  return next;
}

export function removeCustomQuestion(id: string): Question[] {
  const next = loadCustomQuestions().filter((q) => q.id !== id);
  writeJson(CUSTOM_QUESTIONS_KEY, next);
  return next;
}

export async function syncQuestionToServer(q: Question): Promise<boolean> {
  try {
    const res = await request('/api/questions', { method: 'POST', body: JSON.stringify(q) });
    if (!res.ok) {
      logger.warn('api', `Server rejected question "${q.id}" (HTTP ${res.status})`);
      return false;
    }
    return true;
  } catch (err) {
    logger.info('api', 'Server unreachable — question kept in local storage only', err);
    return false;
  }
}

export async function deleteQuestionOnServer(id: string): Promise<boolean> {
  try {
    const res = await request(`/api/questions/${encodeURIComponent(id)}`, { method: 'DELETE' });
    return res.ok;
  } catch (err) {
    logger.info('api', 'Server unreachable — delete applied locally only', err);
    return false;
  }
}

export async function syncAttemptToServer(attempt: AttemptSummary): Promise<boolean> {
  try {
    const res = await request('/api/attempts', { method: 'POST', body: JSON.stringify(attempt) });
    if (!res.ok) {
      logger.warn('api', `Server rejected attempt "${attempt.id}" (HTTP ${res.status})`);
      return false;
    }
    return true;
  } catch (err) {
    logger.info('api', 'Server unreachable — attempt kept in local history only', err);
    return false;
  }
}

export async function fetchAllQuestions(): Promise<Question[]> {
  let base: Question[] = fallbackQuestions as Question[];
  try {
    const res = await request('/api/questions');
    if (res.ok) {
      const data = await res.json();
      const { valid, rejected } = partitionQuestions(data?.questions);
      if (rejected > 0) logger.warn('api', `Ignored ${rejected} malformed question(s) from server`);
      if (valid.length > 0) base = valid;
    } else {
      logger.warn('api', `Question request failed (HTTP ${res.status}) — using bundled questions`);
    }
  } catch (err) {
    logger.info('api', 'Server not reachable — using bundled questions', err);
  }
  const custom = loadCustomQuestions();
  const customIds = new Set(custom.map((c) => c.id));
  return [...custom, ...base.filter((q) => !customIds.has(q.id))];
}
