import React, { useState } from 'react';
import { Award, CheckCircle2, Lock, Sparkles, Trophy, X } from 'lucide-react';
import { Achievement, INITIAL_ACHIEVEMENTS } from '../services/achievements';
import { soundFX } from '../services/soundFX';

interface Props {
  unlockedIds: string[];
  isOpen: boolean;
  onClose: () => void;
}

export const AchievementsModal: React.FC<Props> = ({ unlockedIds, isOpen, onClose }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'All Trophies' },
    { id: 'streak', label: 'Streak' },
    { id: 'accuracy', label: 'Accuracy' },
    { id: 'mastery', label: 'Mastery' },
    { id: 'xp', label: 'XP & Rank' },
  ];

  const filtered = INITIAL_ACHIEVEMENTS.filter(
    (a) => activeCategory === 'all' || a.category === activeCategory
  );

  const unlockedCount = unlockedIds.length;
  const totalCount = INITIAL_ACHIEVEMENTS.length;
  const progressPct = Math.round((unlockedCount / totalCount) * 100);

  return (
    <div className="modal-backdrop animate-fade-up" onClick={onClose}>
      <div className="achievements-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div className="modal-icon-badge">
              <Trophy size={24} className="text-amber" />
            </div>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.4rem' }}>Trophy Room &amp; Achievements</h2>
              <span className="muted" style={{ fontSize: '0.85rem' }}>
                Complete milestone challenges to earn honors and bonus prestige
              </span>
            </div>
          </div>
          <button type="button" className="btn-close-modal" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        {/* Progress Summary Card */}
        <div className="trophy-summary-strip">
          <div className="trophy-stat">
            <span className="trophy-stat-val">
              {unlockedCount} / {totalCount}
            </span>
            <span className="trophy-stat-label">Trophies Claimed</span>
          </div>
          <div className="trophy-progress-wrap">
            <div className="row-between" style={{ marginBottom: '0.35rem' }}>
              <span style={{ fontSize: '0.84rem', fontWeight: 600 }}>Mastery Completion</span>
              <span style={{ fontSize: '0.84rem', fontWeight: 800, color: '#34d399' }}>{progressPct}%</span>
            </div>
            <div className="trophy-track">
              <div className="trophy-fill" style={{ width: `${progressPct}%` }} />
            </div>
          </div>
        </div>

        {/* Filter Categories */}
        <div className="trophy-filter-row">
          {categories.map((c) => (
            <button
              key={c.id}
              type="button"
              className={`trophy-tab-btn ${activeCategory === c.id ? 'active' : ''}`}
              onClick={() => {
                soundFX.playClick();
                setActiveCategory(c.id);
              }}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Achievements Grid */}
        <div className="achievements-grid">
          {filtered.map((item: Achievement) => {
            const isUnlocked = unlockedIds.includes(item.id);
            return (
              <div
                key={item.id}
                className={`achievement-card ${isUnlocked ? 'unlocked' : 'locked'}`}
                onClick={() => {
                  if (isUnlocked) soundFX.playVictory();
                  else soundFX.playIncorrect();
                }}
              >
                <div className="achievement-icon-box">
                  <span className="emoji-icon">{item.icon}</span>
                  {isUnlocked ? (
                    <div className="check-badge">
                      <CheckCircle2 size={13} color="#10b981" />
                    </div>
                  ) : (
                    <div className="lock-badge">
                      <Lock size={12} color="#94a3b8" />
                    </div>
                  )}
                </div>

                <div className="achievement-meta">
                  <div className="achievement-title-row">
                    <strong>{item.title}</strong>
                    {isUnlocked && <span className="unlocked-chip">UNLOCKED</span>}
                  </div>
                  <p className="achievement-desc">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
