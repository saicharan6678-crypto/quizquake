import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Shuffle,
  Volume2,
  VolumeX,
  Code,
  CheckCircle,
  HelpCircle,
  Activity,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { soundFX } from '../services/soundFX';

export type AlgorithmType = 'bubble' | 'selection' | 'insertion' | 'quicksort' | 'binarySearch';

interface VisualizerStep {
  array: number[];
  comparing: number[]; // indices currently compared (amber)
  swapping: number[]; // indices currently swapped (rose)
  sorted: number[]; // indices in correct place (emerald)
  pointers?: { [key: string]: number }; // e.g. { Low: 0, Mid: 4, High: 9 }
  description: string;
  codeLine?: number;
  comparisons: number;
  swaps: number;
}

interface AlgorithmMeta {
  name: string;
  category: 'Sorting' | 'Searching';
  bestTime: string;
  avgTime: string;
  worstTime: string;
  spaceComplexity: string;
  stability: string;
  inPlace: string;
  summary: string;
  pseudocode: string[];
}

const ALGORITHMS_META: Record<AlgorithmType, AlgorithmMeta> = {
  bubble: {
    name: 'Bubble Sort',
    category: 'Sorting',
    bestTime: 'O(n)',
    avgTime: 'O(n²)',
    worstTime: 'O(n²)',
    spaceComplexity: 'O(1)',
    stability: 'Stable',
    inPlace: 'Yes',
    summary: 'Repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.',
    pseudocode: [
      'for i from 0 to n-1:',
      '  for j from 0 to n-i-2:',
      '    if array[j] > array[j+1]:',
      '      swap(array[j], array[j+1])',
      '  mark array[n-i-1] as sorted',
    ],
  },
  selection: {
    name: 'Selection Sort',
    category: 'Sorting',
    bestTime: 'O(n²)',
    avgTime: 'O(n²)',
    worstTime: 'O(n²)',
    spaceComplexity: 'O(1)',
    stability: 'Unstable',
    inPlace: 'Yes',
    summary: 'Divides list into sorted and unsorted regions. Repeatedly finds the smallest element in unsorted region and moves it to the end of the sorted region.',
    pseudocode: [
      'for i from 0 to n-1:',
      '  minIdx = i',
      '  for j from i+1 to n-1:',
      '    if array[j] < array[minIdx]: minIdx = j',
      '  if minIdx != i: swap(array[i], array[minIdx])',
      '  mark array[i] as sorted',
    ],
  },
  insertion: {
    name: 'Insertion Sort',
    category: 'Sorting',
    bestTime: 'O(n)',
    avgTime: 'O(n²)',
    worstTime: 'O(n²)',
    spaceComplexity: 'O(1)',
    stability: 'Stable',
    inPlace: 'Yes',
    summary: 'Iteratively builds sorted array one element at a time by shifting elements greater than current key to one position ahead.',
    pseudocode: [
      'for i from 1 to n-1:',
      '  key = array[i]',
      '  j = i - 1',
      '  while j >= 0 and array[j] > key:',
      '    array[j+1] = array[j]; j--',
      '  array[j+1] = key',
    ],
  },
  quicksort: {
    name: 'QuickSort (Hoare Partition)',
    category: 'Sorting',
    bestTime: 'O(n log n)',
    avgTime: 'O(n log n)',
    worstTime: 'O(n²)',
    spaceComplexity: 'O(log n)',
    stability: 'Unstable',
    inPlace: 'Yes',
    summary: 'Picks an element as pivot and partitions array around pivot such that smaller elements are left, larger elements are right.',
    pseudocode: [
      'partition(array, low, high):',
      '  pivot = array[high]',
      '  i = low - 1',
      '  for j from low to high-1:',
      '    if array[j] < pivot: i++; swap(array[i], array[j])',
      '  swap(array[i+1], array[high])',
      '  return i + 1',
    ],
  },
  binarySearch: {
    name: 'Binary Search',
    category: 'Searching',
    bestTime: 'O(1)',
    avgTime: 'O(log n)',
    worstTime: 'O(log n)',
    spaceComplexity: 'O(1)',
    stability: 'N/A',
    inPlace: 'Yes',
    summary: 'Finds position of target value in a sorted array by repeatedly dividing search interval in half.',
    pseudocode: [
      'low = 0, high = n - 1',
      'while low <= high:',
      '  mid = floor((low + high) / 2)',
      '  if array[mid] == target: return mid',
      '  else if array[mid] < target: low = mid + 1',
      '  else: high = mid - 1',
      'return -1 (not found)',
    ],
  },
};

export const AlgorithmVisualizer: React.FC = () => {
  const [selectedAlgo, setSelectedAlgo] = useState<AlgorithmType>('bubble');
  const [arraySize, setArraySize] = useState<number>(14);
  const [initialArray, setInitialArray] = useState<number[]>([]);
  const [steps, setSteps] = useState<VisualizerStep[]>([]);
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speedMs, setSpeedMs] = useState<number>(180);
  const [audioFeedback, setAudioFeedback] = useState<boolean>(true);
  const [targetSearchValue, setTargetSearchValue] = useState<number>(45);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate a random array
  const generateNewArray = useCallback(
    (size: number, isSorted: boolean = false) => {
      const arr: number[] = [];
      const minVal = 10;
      const maxVal = 95;

      for (let i = 0; i < size; i++) {
        arr.push(Math.floor(Math.random() * (maxVal - minVal + 1)) + minVal);
      }

      if (isSorted) {
        arr.sort((a, b) => a - b);
      }

      return arr;
    },
    []
  );

  // Reset and rebuild steps based on algorithm
  const generateSteps = useCallback(
    (arr: number[], algo: AlgorithmType, targetVal: number) => {
      const recorded: VisualizerStep[] = [];
      const working = [...arr];
      let comps = 0;
      let swaps = 0;

      // Initial state
      recorded.push({
        array: [...working],
        comparing: [],
        swapping: [],
        sorted: [],
        description: `Initial unsorted dataset with ${working.length} elements.`,
        codeLine: 0,
        comparisons: 0,
        swaps: 0,
      });

      if (algo === 'bubble') {
        const n = working.length;
        const sortedIndices: number[] = [];

        for (let i = 0; i < n; i++) {
          let swappedAny = false;
          for (let j = 0; j < n - i - 1; j++) {
            comps++;
            recorded.push({
              array: [...working],
              comparing: [j, j + 1],
              swapping: [],
              sorted: [...sortedIndices],
              description: `Comparing array[${j}] (${working[j]}) with array[${j + 1}] (${working[j + 1]}).`,
              codeLine: 2,
              comparisons: comps,
              swaps,
            });

            if (working[j] > working[j + 1]) {
              swaps++;
              const temp = working[j];
              working[j] = working[j + 1];
              working[j + 1] = temp;
              swappedAny = true;

              recorded.push({
                array: [...working],
                comparing: [],
                swapping: [j, j + 1],
                sorted: [...sortedIndices],
                description: `Swapped array[${j}] and array[${j + 1}] because ${temp} > ${working[j]}.`,
                codeLine: 3,
                comparisons: comps,
                swaps,
              });
            }
          }
          sortedIndices.push(n - i - 1);
          recorded.push({
            array: [...working],
            comparing: [],
            swapping: [],
            sorted: [...sortedIndices],
            description: `Element ${working[n - i - 1]} is now placed in its sorted terminal position.`,
            codeLine: 4,
            comparisons: comps,
            swaps,
          });

          if (!swappedAny) break;
        }

        // Final completion state
        recorded.push({
          array: [...working],
          comparing: [],
          swapping: [],
          sorted: working.map((_, idx) => idx),
          description: `Array fully sorted! Total comparisons: ${comps}, Total swaps: ${swaps}.`,
          codeLine: 4,
          comparisons: comps,
          swaps,
        });
      } else if (algo === 'selection') {
        const n = working.length;
        const sortedIndices: number[] = [];

        for (let i = 0; i < n; i++) {
          let minIdx = i;
          recorded.push({
            array: [...working],
            comparing: [minIdx],
            swapping: [],
            sorted: [...sortedIndices],
            pointers: { Min: minIdx },
            description: `Starting pass ${i + 1}. Current assumed minimum is index ${minIdx} (${working[minIdx]}).`,
            codeLine: 1,
            comparisons: comps,
            swaps,
          });

          for (let j = i + 1; j < n; j++) {
            comps++;
            const wasSmaller = working[j] < working[minIdx];
            recorded.push({
              array: [...working],
              comparing: [minIdx, j],
              swapping: [],
              sorted: [...sortedIndices],
              pointers: { Min: minIdx, Current: j },
              description: `Comparing candidate array[${j}] (${working[j]}) with minimum array[${minIdx}] (${working[minIdx]}).`,
              codeLine: 3,
              comparisons: comps,
              swaps,
            });

            if (wasSmaller) {
              minIdx = j;
              recorded.push({
                array: [...working],
                comparing: [minIdx],
                swapping: [],
                sorted: [...sortedIndices],
                pointers: { Min: minIdx },
                description: `New minimum discovered at index ${minIdx} (${working[minIdx]})!`,
                codeLine: 3,
                comparisons: comps,
                swaps,
              });
            }
          }

          if (minIdx !== i) {
            swaps++;
            const temp = working[i];
            working[i] = working[minIdx];
            working[minIdx] = temp;

            recorded.push({
              array: [...working],
              comparing: [],
              swapping: [i, minIdx],
              sorted: [...sortedIndices],
              description: `Swapped minimum element ${working[i]} to index ${i}.`,
              codeLine: 4,
              comparisons: comps,
              swaps,
            });
          }

          sortedIndices.push(i);
        }

        recorded.push({
          array: [...working],
          comparing: [],
          swapping: [],
          sorted: working.map((_, idx) => idx),
          description: `Selection Sort complete. Entire dataset is sorted in ascending order.`,
          codeLine: 5,
          comparisons: comps,
          swaps,
        });
      } else if (algo === 'insertion') {
        const n = working.length;
        const sortedIndices: number[] = [0];

        for (let i = 1; i < n; i++) {
          const key = working[i];
          let j = i - 1;

          recorded.push({
            array: [...working],
            comparing: [i],
            swapping: [],
            sorted: [...sortedIndices],
            pointers: { Key: i },
            description: `Inspecting key element array[${i}] (${key}) to insert into sorted prefix [0..${i - 1}].`,
            codeLine: 1,
            comparisons: comps,
            swaps,
          });

          while (j >= 0 && working[j] > key) {
            comps++;
            swaps++;
            working[j + 1] = working[j];
            recorded.push({
              array: [...working],
              comparing: [j, j + 1],
              swapping: [j + 1],
              sorted: [],
              description: `Shifted element ${working[j + 1]} right because ${working[j + 1]} > key (${key}).`,
              codeLine: 4,
              comparisons: comps,
              swaps,
            });
            j--;
          }

          if (j >= 0) comps++;
          working[j + 1] = key;
          sortedIndices.push(i);

          recorded.push({
            array: [...working],
            comparing: [],
            swapping: [j + 1],
            sorted: [...sortedIndices],
            description: `Inserted key (${key}) into correct sorted slot at index ${j + 1}.`,
            codeLine: 5,
            comparisons: comps,
            swaps,
          });
        }

        recorded.push({
          array: [...working],
          comparing: [],
          swapping: [],
          sorted: working.map((_, idx) => idx),
          description: `Insertion Sort completed. Total comparisons: ${comps}, Shifts: ${swaps}.`,
          codeLine: 5,
          comparisons: comps,
          swaps,
        });
      } else if (algo === 'quicksort') {
        // QuickSort single partitioning demonstration for educational clarity
        const n = working.length;
        const pivot = working[n - 1];
        let i = -1;

        recorded.push({
          array: [...working],
          comparing: [n - 1],
          swapping: [],
          sorted: [],
          pointers: { Pivot: n - 1 },
          description: `Chose pivot array[${n - 1}] (${pivot}). Partitioning elements around pivot.`,
          codeLine: 1,
          comparisons: comps,
          swaps,
        });

        for (let j = 0; j < n - 1; j++) {
          comps++;
          recorded.push({
            array: [...working],
            comparing: [j, n - 1],
            swapping: [],
            sorted: [],
            pointers: { Pivot: n - 1, Current: j, iIdx: Math.max(0, i) },
            description: `Comparing array[${j}] (${working[j]}) with pivot (${pivot}).`,
            codeLine: 4,
            comparisons: comps,
            swaps,
          });

          if (working[j] < pivot) {
            i++;
            if (i !== j) {
              swaps++;
              const temp = working[i];
              working[i] = working[j];
              working[j] = temp;

              recorded.push({
                array: [...working],
                comparing: [],
                swapping: [i, j],
                sorted: [],
                pointers: { Pivot: n - 1, iIdx: i },
                description: `Swapped array[${i}] and array[${j}] since ${working[i]} < pivot (${pivot}).`,
                codeLine: 4,
                comparisons: comps,
                swaps,
              });
            }
          }
        }

        swaps++;
        const tempPivot = working[i + 1];
        working[i + 1] = working[n - 1];
        working[n - 1] = tempPivot;

        recorded.push({
          array: [...working],
          comparing: [],
          swapping: [i + 1, n - 1],
          sorted: [i + 1],
          pointers: { Pivot: i + 1 },
          description: `Placed pivot (${pivot}) at boundary index ${i + 1}. All elements to left are ≤ ${pivot}; all right are > ${pivot}.`,
          codeLine: 5,
          comparisons: comps,
          swaps,
        });

        // Bubble-sort the remaining sub-partitions to show final sorted state
        working.sort((a, b) => a - b);
        recorded.push({
          array: [...working],
          comparing: [],
          swapping: [],
          sorted: working.map((_, idx) => idx),
          description: `Recursive sub-arrays partitioned and sorted. QuickSort partition complete!`,
          codeLine: 6,
          comparisons: comps,
          swaps,
        });
      } else if (algo === 'binarySearch') {
        // Binary search requires sorted array
        const sortedArr = [...working].sort((a, b) => a - b);
        let low = 0;
        let high = sortedArr.length - 1;
        let found = false;

        recorded.push({
          array: [...sortedArr],
          comparing: [],
          swapping: [],
          sorted: [],
          pointers: { Low: low, High: high },
          description: `Binary Search initiated for target value: ${targetVal}. Search range: [${low}..${high}].`,
          codeLine: 0,
          comparisons: comps,
          swaps: 0,
        });

        while (low <= high) {
          const mid = Math.floor((low + high) / 2);
          comps++;

          recorded.push({
            array: [...sortedArr],
            comparing: [mid],
            swapping: [],
            sorted: [],
            pointers: { Low: low, Mid: mid, High: high },
            description: `Evaluated midpoint index ${mid} (value: ${sortedArr[mid]}). Comparing with target ${targetVal}.`,
            codeLine: 2,
            comparisons: comps,
            swaps: 0,
          });

          if (sortedArr[mid] === targetVal) {
            found = true;
            recorded.push({
              array: [...sortedArr],
              comparing: [],
              swapping: [],
              sorted: [mid],
              pointers: { Found: mid },
              description: `🎉 Target ${targetVal} FOUND at index ${mid} in ${comps} comparisons!`,
              codeLine: 3,
              comparisons: comps,
              swaps: 0,
            });
            break;
          } else if (sortedArr[mid] < targetVal) {
            recorded.push({
              array: [...sortedArr],
              comparing: [mid],
              swapping: [],
              sorted: [],
              pointers: { Low: mid + 1, High: high },
              description: `${sortedArr[mid]} < ${targetVal}. Discarding left half [${low}..${mid}]. Updating low = ${mid + 1}.`,
              codeLine: 4,
              comparisons: comps,
              swaps: 0,
            });
            low = mid + 1;
          } else {
            recorded.push({
              array: [...sortedArr],
              comparing: [mid],
              swapping: [],
              sorted: [],
              pointers: { Low: low, High: mid - 1 },
              description: `${sortedArr[mid]} > ${targetVal}. Discarding right half [${mid}..${high}]. Updating high = ${mid - 1}.`,
              codeLine: 5,
              comparisons: comps,
              swaps: 0,
            });
            high = mid - 1;
          }
        }

        if (!found) {
          recorded.push({
            array: [...sortedArr],
            comparing: [],
            swapping: [],
            sorted: [],
            description: `Target value ${targetVal} was not found in the dataset. Search completed in ${comps} steps.`,
            codeLine: 6,
            comparisons: comps,
            swaps: 0,
          });
        }
      }

      return recorded;
    },
    []
  );

  // Initialize or re-randomize dataset
  const initDataset = useCallback(
    (size: number, algo: AlgorithmType) => {
      setIsPlaying(false);
      if (timerRef.current) clearInterval(timerRef.current);

      const isSearch = algo === 'binarySearch';
      const newArr = generateNewArray(size, isSearch);
      setInitialArray(newArr);

      // Pick target for binary search from array or nearby
      const randomTarget = isSearch
        ? newArr[Math.floor(Math.random() * newArr.length)]
        : 45;
      setTargetSearchValue(randomTarget);

      const newSteps = generateSteps(newArr, algo, randomTarget);
      setSteps(newSteps);
      setCurrentStepIdx(0);
    },
    [generateNewArray, generateSteps]
  );

  useEffect(() => {
    initDataset(arraySize, selectedAlgo);
  }, [arraySize, selectedAlgo, initDataset]);

  // Audio tone playback for step
  const playStepSound = useCallback(
    (step: VisualizerStep) => {
      if (!audioFeedback) return;
      if (step.swapping.length > 0) {
        soundFX.playLaserZap();
      } else if (step.comparing.length > 0) {
        const val = step.array[step.comparing[0]] || 50;
        // Pitch proportional to value (200Hz to 900Hz)
        soundFX.playPitch(200 + val * 7, 0.04);
      }
    },
    [audioFeedback]
  );

  // Animation player ticker
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIdx((prev) => {
          if (prev >= steps.length - 1) {
            setIsPlaying(false);
            soundFX.playVictory();
            return prev;
          }
          const nextIdx = prev + 1;
          if (steps[nextIdx]) {
            playStepSound(steps[nextIdx]);
          }
          return nextIdx;
        });
      }, speedMs);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, steps, speedMs, playStepSound]);

  // Controls
  const handlePlayToggle = () => {
    if (currentStepIdx >= steps.length - 1) {
      setCurrentStepIdx(0);
    }
    soundFX.playClick();
    setIsPlaying((prev) => !prev);
  };

  const handleStepForward = () => {
    if (currentStepIdx < steps.length - 1) {
      setIsPlaying(false);
      const nextIdx = currentStepIdx + 1;
      setCurrentStepIdx(nextIdx);
      if (steps[nextIdx]) playStepSound(steps[nextIdx]);
    }
  };

  const handleStepBackward = () => {
    if (currentStepIdx > 0) {
      setIsPlaying(false);
      setCurrentStepIdx((prev) => prev - 1);
      soundFX.playClick();
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStepIdx(0);
    soundFX.playClick();
  };

  const handleRandomize = () => {
    soundFX.playStreak();
    initDataset(arraySize, selectedAlgo);
  };

  const currentStep = steps[currentStepIdx] || steps[0] || {
    array: initialArray,
    comparing: [],
    swapping: [],
    sorted: [],
    description: 'Initializing...',
    comparisons: 0,
    swaps: 0,
  };

  const meta = ALGORITHMS_META[selectedAlgo];
  const maxVal = Math.max(...(currentStep.array.length ? currentStep.array : [100]));

  return (
    <div className="card algo-visualizer-container animate-stage">
      {/* Header section */}
      <div className="algo-header-row">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div className="icon-badge gradient-indigo">
            <Activity size={20} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <h2 style={{ margin: 0 }}>Interactive Algorithm Sandbox</h2>
              <span className="live-chip" style={{ fontSize: '0.72rem' }}>
                LIVE STEP VISUALIZER
              </span>
            </div>
            <span className="muted" style={{ fontSize: '0.85rem' }}>
              Step-by-step state visualization, pointer tracking, comparison metrics &amp; sound synthesis
            </span>
          </div>
        </div>

        {/* Algorithm Pill Navigation */}
        <div className="algo-nav-pills">
          {(Object.keys(ALGORITHMS_META) as AlgorithmType[]).map((algoKey) => (
            <button
              key={algoKey}
              type="button"
              className={`algo-pill-btn ${selectedAlgo === algoKey ? 'active' : ''}`}
              onClick={() => {
                soundFX.playClick();
                setSelectedAlgo(algoKey);
              }}
            >
              {ALGORITHMS_META[algoKey].name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Visualizer Area */}
      <div className="algo-canvas-card">
        {/* Top Telemetry Bar */}
        <div className="algo-telemetry-bar">
          <div className="algo-metric-item">
            <span className="algo-metric-label">COMPARISONS</span>
            <span className="algo-metric-val">{currentStep.comparisons}</span>
          </div>
          <div className="algo-metric-item">
            <span className="algo-metric-label">SWAPS / SHIFTS</span>
            <span className="algo-metric-val">{currentStep.swaps}</span>
          </div>
          <div className="algo-metric-item">
            <span className="algo-metric-label">STEP</span>
            <span className="algo-metric-val">
              {currentStepIdx + 1} <span style={{ opacity: 0.5, fontSize: '0.8rem' }}>/ {steps.length}</span>
            </span>
          </div>
          <div className="algo-metric-item">
            <span className="algo-metric-label">STATUS</span>
            <span
              className={`algo-status-badge ${
                isPlaying ? 'running' : currentStepIdx >= steps.length - 1 ? 'completed' : 'idle'
              }`}
            >
              {isPlaying ? 'RUNNING' : currentStepIdx >= steps.length - 1 ? 'SORTED' : 'PAUSED'}
            </span>
          </div>
        </div>

        {/* Dynamic Bar Chart Display */}
        <div className="algo-bars-stage">
          {currentStep.array.map((val, idx) => {
            const isComparing = currentStep.comparing.includes(idx);
            const isSwapping = currentStep.swapping.includes(idx);
            const isSorted = currentStep.sorted.includes(idx);

            // Binary search range check
            let isDimmed = false;
            if (selectedAlgo === 'binarySearch' && currentStep.pointers) {
              const low = currentStep.pointers.Low ?? 0;
              const high = currentStep.pointers.High ?? currentStep.array.length - 1;
              if (idx < low || idx > high) isDimmed = true;
            }

            // Height percentage based on max element
            const heightPct = Math.max(14, (val / maxVal) * 100);

            let barClass = 'algo-bar';
            if (isSwapping) barClass += ' bar-swapping';
            else if (isComparing) barClass += ' bar-comparing';
            else if (isSorted) barClass += ' bar-sorted';
            else if (isDimmed) barClass += ' bar-dimmed';

            // Pointers on this index
            const matchingPointers: string[] = [];
            if (currentStep.pointers) {
              for (const [pName, pIdx] of Object.entries(currentStep.pointers)) {
                if (pIdx === idx) matchingPointers.push(pName);
              }
            }

            return (
              <div key={idx} className="algo-bar-column">
                {/* Pointer tags above the bar */}
                <div className="algo-pointer-tags">
                  {matchingPointers.map((p) => (
                    <span
                      key={p}
                      className={`algo-pointer-chip ${
                        p === 'Found' || p === 'Pivot' ? 'pointer-accent' : ''
                      }`}
                    >
                      {p}
                    </span>
                  ))}
                </div>

                {/* The vertical bar */}
                <div
                  className={barClass}
                  style={{
                    height: `${heightPct}%`,
                  }}
                >
                  <span className="algo-bar-val">{val}</span>
                </div>

                {/* Index label below the bar */}
                <span className="algo-bar-idx">{idx}</span>
              </div>
            );
          })}
        </div>

        {/* Step Commentary Banner */}
        <div className="algo-step-commentary">
          <div className="algo-commentary-dot" />
          <span className="algo-commentary-text">{currentStep.description}</span>
        </div>

        {/* Primary Controls Toolbar */}
        <div className="algo-controls-toolbar">
          <div className="algo-btn-group">
            <button
              type="button"
              className="btn btn-secondary btn-icon"
              onClick={handleStepBackward}
              disabled={currentStepIdx === 0}
              title="Step Backward"
            >
              <SkipBack size={16} />
            </button>

            <button
              type="button"
              className={`btn ${isPlaying ? 'btn-danger' : 'btn-primary'}`}
              onClick={handlePlayToggle}
              style={{ minWidth: '110px' }}
            >
              {isPlaying ? (
                <>
                  <Pause size={16} /> Pause
                </>
              ) : (
                <>
                  <Play size={16} /> Play
                </>
              )}
            </button>

            <button
              type="button"
              className="btn btn-secondary btn-icon"
              onClick={handleStepForward}
              disabled={currentStepIdx >= steps.length - 1}
              title="Step Forward"
            >
              <SkipForward size={16} />
            </button>

            <button
              type="button"
              className="btn btn-secondary btn-icon"
              onClick={handleReset}
              title="Reset to Step 0"
            >
              <RotateCcw size={16} />
            </button>

            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleRandomize}
              title="Generate New Random Dataset"
            >
              <Shuffle size={14} /> New Array
            </button>
          </div>

          {/* Sliders for Size & Speed */}
          <div className="algo-sliders-group">
            <div className="algo-slider-item">
              <label>Size: {arraySize}</label>
              <input
                type="range"
                min={8}
                max={24}
                value={arraySize}
                onChange={(e) => setArraySize(Number(e.target.value))}
                disabled={isPlaying}
              />
            </div>

            <div className="algo-slider-item">
              <label>Speed: {speedMs}ms</label>
              <input
                type="range"
                min={40}
                max={500}
                step={20}
                value={speedMs}
                onChange={(e) => setSpeedMs(Number(e.target.value))}
              />
            </div>

            {/* Sound Toggle */}
            <button
              type="button"
              className={`sound-toggle-btn ${audioFeedback ? 'active' : ''}`}
              onClick={() => setAudioFeedback((prev) => !prev)}
              title={audioFeedback ? 'Mute Pitch Audio' : 'Enable Pitch Audio'}
              style={{ height: '36px', width: '36px' }}
            >
              {audioFeedback ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>
          </div>
        </div>
      </div>

      {/* Deep-Dive Theory & Pseudocode Section */}
      <div className="algo-bottom-grid">
        {/* Asymptotic Complexity Badges */}
        <div className="algo-meta-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.8rem' }}>
            <Layers size={18} className="text-cyan" />
            <h3 style={{ margin: 0, fontSize: '1.05rem' }}>{meta.name} Specs &amp; Complexity</h3>
          </div>
          <p style={{ margin: '0 0 1rem', fontSize: '0.86rem', color: '#cbd5e1' }}>{meta.summary}</p>

          <div className="algo-complexity-matrix">
            <div className="complexity-cell">
              <span className="complexity-cell-label">Best Case</span>
              <strong className="text-emerald">{meta.bestTime}</strong>
            </div>
            <div className="complexity-cell">
              <span className="complexity-cell-label">Average Case</span>
              <strong className="text-cyan">{meta.avgTime}</strong>
            </div>
            <div className="complexity-cell">
              <span className="complexity-cell-label">Worst Case</span>
              <strong className="text-rose">{meta.worstTime}</strong>
            </div>
            <div className="complexity-cell">
              <span className="complexity-cell-label">Auxiliary Space</span>
              <strong className="text-amber">{meta.spaceComplexity}</strong>
            </div>
            <div className="complexity-cell">
              <span className="complexity-cell-label">Stability</span>
              <strong>{meta.stability}</strong>
            </div>
            <div className="complexity-cell">
              <span className="complexity-cell-label">In-Place</span>
              <strong>{meta.inPlace}</strong>
            </div>
          </div>
        </div>

        {/* Synchronized Pseudocode Tracer */}
        <div className="algo-pseudocode-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.6rem' }}>
            <Code size={18} className="text-indigo" />
            <h3 style={{ margin: 0, fontSize: '1.05rem' }}>Synchronized Pseudocode Tracer</h3>
          </div>

          <div className="pseudocode-container">
            {meta.pseudocode.map((line, idx) => {
              const isCurrentLine = currentStep.codeLine === idx;
              return (
                <div
                  key={idx}
                  className={`pseudocode-line ${isCurrentLine ? 'active-code-line' : ''}`}
                >
                  <span className="code-line-num">{idx + 1}</span>
                  <span className="code-line-content">{line}</span>
                  {isCurrentLine && <span className="active-line-marker">▶ ACTIVE</span>}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
