import React from 'react';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from 'chart.js';
import { Radar, Doughnut, Bar } from 'react-chartjs-2';
import { AttemptSummary } from '../types';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title
);

interface TopicStat {
  topic: string;
  correct: number;
  total: number;
  pct: number;
}

interface Props {
  topicStats: TopicStat[];
  history: AttemptSummary[];
}

export const AnalyticsCharts: React.FC<Props> = ({ topicStats, history }) => {
  // 1. Radar Chart Data for Topic Mastery
  const radarLabels = topicStats.map((s) => s.topic);
  const radarDataValues = topicStats.map((s) => s.pct);

  const radarData = {
    labels: radarLabels.length > 0 ? radarLabels : ['Data Structures', 'Algorithms', 'Operating Systems', 'Computer Networks'],
    datasets: [
      {
        label: 'Topic Mastery %',
        data: radarDataValues.length > 0 ? radarDataValues : [75, 80, 70, 85],
        backgroundColor: 'rgba(99, 102, 241, 0.35)',
        borderColor: '#a855f7',
        borderWidth: 2.5,
        pointBackgroundColor: '#ec4899',
        pointBorderColor: '#ffffff',
        pointHoverBackgroundColor: '#ffffff',
        pointHoverBorderColor: '#ec4899',
        pointRadius: 4.5,
      },
    ],
  };

  const radarOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      r: {
        angleLines: {
          color: 'rgba(255, 255, 255, 0.15)',
        },
        grid: {
          color: 'rgba(255, 255, 255, 0.12)',
        },
        pointLabels: {
          color: '#cbd5e1',
          font: {
            size: 11,
            family: "'Plus Jakarta Sans', sans-serif",
            weight: 600 as const,
          },
        },
        ticks: {
          backdropColor: 'transparent',
          color: '#94a3b8',
          stepSize: 20,
        },
        suggestedMin: 0,
        suggestedMax: 100,
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        titleColor: '#f8fafc',
        bodyColor: '#e2e8f0',
        borderColor: 'rgba(99, 102, 241, 0.5)',
        borderWidth: 1,
        padding: 10,
        callbacks: {
          label: (context: { raw: unknown }) => `Mastery: ${context.raw}%`,
        },
      },
    },
  };

  // 2. Accuracy Doughnut Chart Data
  let totalCorrect = 0;
  let totalIncorrect = 0;
  history.forEach((att) => {
    totalCorrect += att.correctCount;
    totalIncorrect += Math.max(0, att.totalCount - att.correctCount);
  });

  const doughnutData = {
    labels: ['Correct Answers', 'Incorrect Answers'],
    datasets: [
      {
        data: totalCorrect + totalIncorrect > 0 ? [totalCorrect, totalIncorrect] : [1, 0],
        backgroundColor: ['#10b981', '#f43f5e'],
        borderColor: 'rgba(15, 23, 42, 0.8)',
        borderWidth: 2,
        hoverOffset: 6,
      },
    ],
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '72%',
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: '#cbd5e1',
          font: {
            family: "'Plus Jakarta Sans', sans-serif",
            weight: 600 as const,
          },
          padding: 12,
        },
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        borderColor: 'rgba(255, 255, 255, 0.2)',
        borderWidth: 1,
      },
    },
  };

  // 3. Score Progression Bar Chart
  const recentAttempts = [...history].reverse().slice(-7);
  const barData = {
    labels: recentAttempts.map((a, i) => `#${i + 1} ${a.mode === 'adaptive' ? 'Arena' : 'Topic'}`),
    datasets: [
      {
        label: 'Score (pts)',
        data: recentAttempts.map((a) => a.score),
        backgroundColor: 'rgba(6, 182, 212, 0.7)',
        borderRadius: 8,
        borderColor: '#06b6d4',
        borderWidth: 1.5,
      },
    ],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.08)' },
        ticks: { color: '#94a3b8' },
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.08)' },
        ticks: { color: '#94a3b8' },
        suggestedMin: 0,
      },
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        borderColor: 'rgba(6, 182, 212, 0.4)',
        borderWidth: 1,
      },
    },
  };

  return (
    <div className="analytics-motion-grid">
      {/* Radar Chart Card */}
      <div className="chart-card">
        <div className="chart-header">
          <span className="chart-title">Topic Mastery Matrix</span>
          <span className="chart-tag">Skill Radar</span>
        </div>
        <div className="chart-canvas-wrap">
          <Radar data={radarData} options={radarOptions} />
        </div>
      </div>

      {/* Doughnut Chart Card */}
      <div className="chart-card">
        <div className="chart-header">
          <span className="chart-title">Overall Accuracy Ratio</span>
          <span className="chart-tag">Hit / Miss</span>
        </div>
        <div className="chart-canvas-wrap doughnut-wrap">
          <Doughnut data={doughnutData} options={doughnutOptions} />
          <div className="doughnut-center-stat">
            <span className="doughnut-stat-number">
              {totalCorrect + totalIncorrect > 0
                ? `${Math.round((totalCorrect / (totalCorrect + totalIncorrect)) * 100)}%`
                : '100%'}
            </span>
            <span className="doughnut-stat-label">Accuracy</span>
          </div>
        </div>
      </div>

      {/* Score Progression Card */}
      <div className="chart-card full-width-chart">
        <div className="chart-header">
          <span className="chart-title">Score Progression (Recent Runs)</span>
          <span className="chart-tag">Performance Trajectory</span>
        </div>
        <div className="chart-canvas-wrap bar-wrap">
          {recentAttempts.length > 0 ? (
            <Bar data={barData} options={barOptions} />
          ) : (
            <div className="no-data-notice">
              <span>Complete your first quiz to generate score progression trends!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
