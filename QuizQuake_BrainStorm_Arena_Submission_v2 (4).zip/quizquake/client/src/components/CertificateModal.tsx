import React, { useState } from 'react';
import { Award, CheckCircle2, Download, Printer, ShieldCheck, X } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { AttemptSummary } from '../types';
import { soundFX } from '../services/soundFX';
import { readItem, writeItem } from '../services/safeStorage';

interface Props {
  attempt: AttemptSummary;
  isOpen: boolean;
  onClose: () => void;
}

export const CertificateModal: React.FC<Props> = ({ attempt, isOpen, onClose }) => {
  const [studentName, setStudentName] = useState(() => {
    return readItem('quizquake_student_name') || 'Candidate';
  });

  if (!isOpen) return null;

  const handleNameChange = (name: string) => {
    setStudentName(name);
    writeItem('quizquake_student_name', name);
  };

  const getHonorTitle = (pct: number) => {
    if (pct >= 90) return 'Distinction Honors';
    if (pct >= 80) return 'Excellence Honors';
    if (pct >= 70) return 'Proficiency Certificate';
    return 'Certificate of Completion';
  };

  const credentialId = `QQ-CS-${attempt.id.slice(-6).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const downloadPdfCertificate = () => {
    soundFX.playVictory();
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
    });

    const width = doc.internal.pageSize.getWidth();
    const height = doc.internal.pageSize.getHeight();

    // Background fill & elegant border
    doc.setFillColor(11, 15, 28);
    doc.rect(0, 0, width, height, 'F');

    // Outer and Inner Gold/Indigo Borders
    doc.setDrawColor(99, 102, 241);
    doc.setLineWidth(2);
    doc.rect(10, 10, width - 20, height - 20);

    doc.setDrawColor(245, 158, 11);
    doc.setLineWidth(0.6);
    doc.rect(14, 14, width - 28, height - 28);

    // Header Branding
    doc.setTextColor(245, 158, 11);
    doc.setFontSize(14);
    doc.text('QUIZQUAKE — BRAINSTORM ARENA', width / 2, 32, { align: 'center' });

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(26);
    doc.text('CERTIFICATE OF ACADEMIC ACHIEVEMENT', width / 2, 46, { align: 'center' });

    doc.setTextColor(148, 163, 235);
    doc.setFontSize(11);
    doc.text('COMPUTER SCIENCE KNOWLEDGE & PROBLEM SOLVING ASSESSMENT', width / 2, 54, { align: 'center' });

    // Certificate Body Text
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(12);
    doc.text('This is to certify that', width / 2, 70, { align: 'center' });

    // Student Name
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text(studentName.trim() || 'Candidate', width / 2, 85, { align: 'center' });

    doc.setDrawColor(148, 163, 235);
    doc.setLineWidth(0.4);
    doc.line(width / 2 - 60, 89, width / 2 + 60, 89);

    // Achievement text
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(12);
    doc.text(
      `has successfully passed the comprehensive Computer Science assessment in`,
      width / 2,
      100,
      { align: 'center' }
    );

    // Subject/Topic
    doc.setTextColor(165, 180, 252);
    doc.setFontSize(16);
    doc.text(`${attempt.title} — ${attempt.topicFilter}`, width / 2, 112, { align: 'center' });

    // Stats Grid
    doc.setTextColor(203, 213, 225);
    doc.setFontSize(11);
    doc.text(
      `Accuracy: ${attempt.accuracyPercent}%  |  Score: ${attempt.score} pts  |  Grade: ${getHonorTitle(attempt.accuracyPercent)}`,
      width / 2,
      126,
      { align: 'center' }
    );

    // Bottom signatures & verification
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 235);
    doc.text(`Completed on: ${attempt.completedAt}`, 26, 170);
    doc.text(`Credential ID: ${credentialId}`, 26, 176);
    doc.text(`Verification Protocol: SHA-256 Validated Academic Record`, 26, 182);

    doc.text('Academic Committee Lead', width - 75, 170);
    doc.setDrawColor(148, 163, 235);
    doc.line(width - 75, 165, width - 25, 165);
    doc.text('QuizQuake Assessment Board', width - 75, 176);

    doc.save(`QuizQuake_Certificate_${studentName.replace(/\s+/g, '_')}.pdf`);
  };

  return (
    <div className="modal-backdrop animate-fade-up" onClick={onClose}>
      <div className="certificate-modal-wrapper" onClick={(e) => e.stopPropagation()}>
        <div className="certificate-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <Award size={22} className="text-amber" />
            <h3 style={{ margin: 0 }}>Academic Certificate Generator</h3>
          </div>
          <button type="button" className="btn-close-modal" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        {/* Candidate Input */}
        <div className="certificate-name-row">
          <label className="field" style={{ flexGrow: 1 }}>
            <span>Recipient Full Name</span>
            <input
              type="text"
              value={studentName}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Alex Johnson"
            />
          </label>
        </div>

        {/* Visual Certificate Frame */}
        <div className="certificate-frame">
          <div className="certificate-inner-border">
            <div className="cert-top-badge">
              <ShieldCheck size={18} />
              <span>OFFICIAL ACADEMIC CREDENTIAL</span>
            </div>

            <h2 className="cert-main-title">Certificate of Achievement</h2>
            <p className="cert-sub">QuizQuake: BrainStorm Arena Academic Assessment</p>

            <span className="cert-awarded-text">Proudly presented to</span>
            <h1 className="cert-candidate-name">{studentName.trim() || 'Candidate'}</h1>

            <p className="cert-body-p">
              For demonstrating conceptual mastery and problem-solving excellence in
            </p>
            <div className="cert-topic-badge">{attempt.title} ({attempt.topicFilter})</div>

            <div className="cert-metrics-row">
              <div className="cert-metric-box">
                <span className="cert-metric-val">{attempt.accuracyPercent}%</span>
                <span className="cert-metric-lbl">Accuracy</span>
              </div>
              <div className="cert-metric-box">
                <span className="cert-metric-val">{attempt.score}</span>
                <span className="cert-metric-lbl">Total Points</span>
              </div>
              <div className="cert-metric-box">
                <span className="cert-metric-val">{getHonorTitle(attempt.accuracyPercent)}</span>
                <span className="cert-metric-lbl">Award Tier</span>
              </div>
            </div>

            <div className="cert-footer-row">
              <div className="cert-meta-col">
                <span>Date: {attempt.completedAt}</span>
                <span>Credential: {credentialId}</span>
              </div>
              <div className="cert-seal-col">
                <div className="cert-seal">
                  <CheckCircle2 size={16} />
                  <span>VERIFIED</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="certificate-actions-row">
          <button type="button" className="btn btn-secondary" onClick={() => window.print()}>
            <Printer size={16} /> Print
          </button>
          <button type="button" className="btn btn-primary" onClick={downloadPdfCertificate}>
            <Download size={16} /> Download Official PDF
          </button>
        </div>
      </div>
    </div>
  );
};
