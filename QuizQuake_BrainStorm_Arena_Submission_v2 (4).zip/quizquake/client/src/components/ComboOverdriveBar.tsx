import React from 'react';
import { Flame, Zap } from 'lucide-react';

interface Props {
  streak: number;
}

export const ComboOverdriveBar: React.FC<Props> = ({ streak }) => {
  const maxStreak = 5;
  const progressPercent = Math.min(100, (streak / maxStreak) * 100);
  const isOverdrive = streak >= 5;

  let multiplier = '1.0x';
  let tierLabel = 'Normal Power';
  let tierClass = 'tier-normal';

  if (streak === 1) {
    multiplier = '1.2x';
    tierLabel = 'Boost Active';
    tierClass = 'tier-boost';
  } else if (streak === 2) {
    multiplier = '1.5x';
    tierLabel = 'Tier Surge';
    tierClass = 'tier-surge';
  } else if (streak === 3) {
    multiplier = '2.0x';
    tierLabel = 'Hot Flame 🔥';
    tierClass = 'tier-hot';
  } else if (streak === 4) {
    multiplier = '2.5x';
    tierLabel = 'Hyper Charge ⚡';
    tierClass = 'tier-hyper';
  } else if (streak >= 5) {
    multiplier = '3.0x';
    tierLabel = 'MAX OVERDRIVE! 🚀';
    tierClass = 'tier-overdrive';
  }

  return (
    <div className={`combo-gauge-container ${tierClass} ${isOverdrive ? 'active-overdrive' : ''}`}>
      <div className="combo-top-row">
        <div className="combo-badge">
          {isOverdrive ? <Zap size={14} className="combo-zap-icon" /> : <Flame size={14} />}
          <span>{tierLabel}</span>
        </div>
        <div className="combo-multiplier-val">{multiplier} Combo Multiplier</div>
      </div>

      <div className="combo-track">
        <div
          className="combo-fill"
          style={{ width: `${progressPercent}%` }}
        >
          {isOverdrive && <div className="overdrive-spark-sheen" />}
        </div>
        <div className="combo-pips">
          {[1, 2, 3, 4, 5].map((pip) => (
            <div
              key={pip}
              className={`combo-pip ${streak >= pip ? 'filled' : ''}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
