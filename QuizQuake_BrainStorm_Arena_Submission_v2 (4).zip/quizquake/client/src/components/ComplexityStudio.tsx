import React, { useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { BookOpen, Cpu, Info, Sliders, Sparkles } from 'lucide-react';
import { soundFX } from '../services/soundFX';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export const ComplexityStudio: React.FC = () => {
  const [inputN, setInputN] = useState<number>(16);
  const [activeTab, setActiveTab] = useState<'chart' | 'ds' | 'sort'>('chart');

  // Generate chart data up to inputN
  const stepCount = Math.max(5, Math.min(25, inputN));
  const stepSize = Math.max(1, Math.floor(inputN / stepCount));
  const labels: number[] = [];
  for (let i = 1; i <= inputN; i += stepSize) {
    labels.push(i);
  }
  if (!labels.includes(inputN)) labels.push(inputN);

  const chartData = {
    labels: labels.map((n) => `n=${n}`),
    datasets: [
      {
        label: 'O(1) Constant',
        data: labels.map(() => 1),
        borderColor: '#10b981',
        backgroundColor: '#10b981',
        borderWidth: 2,
        pointRadius: 2,
      },
      {
        label: 'O(log n) Logarithmic',
        data: labels.map((n) => Math.round(Math.log2(n) * 10) / 10),
        borderColor: '#06b6d4',
        backgroundColor: '#06b6d4',
        borderWidth: 2,
        pointRadius: 2,
      },
      {
        label: 'O(n) Linear',
        data: labels.map((n) => n),
        borderColor: '#3b82f6',
        backgroundColor: '#3b82f6',
        borderWidth: 2,
        pointRadius: 2,
      },
      {
        label: 'O(n log n) Linearithmic',
        data: labels.map((n) => Math.round(n * Math.log2(Math.max(1, n)))),
        borderColor: '#818cf8',
        backgroundColor: '#818cf8',
        borderWidth: 2,
        pointRadius: 2,
      },
      {
        label: 'O(n^2) Quadratic',
        data: labels.map((n) => Math.min(2000, n * n)),
        borderColor: '#f59e0b',
        backgroundColor: '#f59e0b',
        borderWidth: 2,
        pointRadius: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.06)' },
        ticks: { color: '#94a3b8' },
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.06)' },
        ticks: { color: '#94a3b8' },
        suggestedMin: 0,
        suggestedMax: Math.min(1200, inputN * inputN),
      },
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#cbd5e1',
          font: { family: "'Plus Jakarta Sans', sans-serif", weight: 600 as const },
          boxWidth: 12,
        },
      },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(99, 102, 241, 0.4)',
        borderWidth: 1,
      },
    },
  };

  // Complexity calculation for the exact N
  const opO1 = 1;
  const opLogN = Math.round(Math.log2(Math.max(1, inputN)) * 10) / 10;
  const opN = inputN;
  const opNLogN = Math.round(inputN * Math.log2(Math.max(1, inputN)));
  const opN2 = inputN * inputN;
  const op2N = inputN <= 30 ? Math.pow(2, inputN).toLocaleString() : 'Explosive (>10^9)';

  const dsData = [
    { name: 'Array / Vector', access: 'O(1)', search: 'O(n)', insert: 'O(n)', delete: 'O(n)', space: 'O(n)' },
    { name: 'Singly Linked List', access: 'O(n)', search: 'O(n)', insert: 'O(1)', delete: 'O(1)', space: 'O(n)' },
    { name: 'Hash Table / Map', access: 'N/A', search: 'O(1) avg', insert: 'O(1) avg', delete: 'O(1) avg', space: 'O(n)' },
    { name: 'Binary Search Tree', access: 'O(log n)', search: 'O(log n)', insert: 'O(log n)', delete: 'O(log n)', space: 'O(n)' },
    { name: 'Binary Heap (Priority Queue)', access: 'O(1) min/max', search: 'O(n)', insert: 'O(log n)', delete: 'O(log n)', space: 'O(n)' },
    { name: 'Stack / Queue', access: 'O(n)', search: 'O(n)', insert: 'O(1)', delete: 'O(1)', space: 'O(n)' },
  ];

  const sortData = [
    { name: 'Quick Sort', best: 'O(n log n)', avg: 'O(n log n)', worst: 'O(n^2)', space: 'O(log n)', stable: 'No' },
    { name: 'Merge Sort', best: 'O(n log n)', avg: 'O(n log n)', worst: 'O(n log n)', space: 'O(n)', stable: 'Yes' },
    { name: 'Heap Sort', best: 'O(n log n)', avg: 'O(n log n)', worst: 'O(n log n)', space: 'O(1)', stable: 'No' },
    { name: 'Insertion Sort', best: 'O(n)', avg: 'O(n^2)', worst: 'O(n^2)', space: 'O(1)', stable: 'Yes' },
    { name: 'Bubble Sort', best: 'O(n)', avg: 'O(n^2)', worst: 'O(n^2)', space: 'O(1)', stable: 'Yes' },
  ];

  return (
    <div className="card animate-stage">
      <div className="row-between" style={{ marginBottom: '1.25rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-indigo">
            <Cpu size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Big-O Complexity Studio &amp; Reference Lab</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Interactive asymptotic growth simulator, operations estimator, and algorithm benchmarks
            </span>
          </div>
        </div>

        {/* View Tabs */}
        <div className="complexity-subtabs">
          <button
            type="button"
            className={`subtab-btn ${activeTab === 'chart' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setActiveTab('chart');
            }}
          >
            <Sliders size={14} /> Growth Simulator
          </button>
          <button
            type="button"
            className={`subtab-btn ${activeTab === 'ds' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setActiveTab('ds');
            }}
          >
            <BookOpen size={14} /> Data Structures
          </button>
          <button
            type="button"
            className={`subtab-btn ${activeTab === 'sort' ? 'active' : ''}`}
            onClick={() => {
              soundFX.playClick();
              setActiveTab('sort');
            }}
          >
            <Sparkles size={14} /> Sorting Benchmarks
          </button>
        </div>
      </div>

      {activeTab === 'chart' && (
        <div className="animate-fade-up">
          {/* Interactive N Slider */}
          <div className="complexity-slider-strip">
            <div className="row-between" style={{ marginBottom: '0.5rem' }}>
              <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>
                Simulated Input Size (n): <strong className="text-indigo" style={{ fontSize: '1.15rem' }}>{inputN}</strong> elements
              </span>
              <span className="muted" style={{ fontSize: '0.82rem' }}>
                Drag slider to simulate asymptotic divergence
              </span>
            </div>
            <input
              type="range"
              min={2}
              max={64}
              value={inputN}
              onChange={(e) => setInputN(Number(e.target.value))}
              className="complexity-range-slider"
            />
          </div>

          {/* Real-time Operation Counts */}
          <div className="ops-grid">
            <div className="op-card op-o1">
              <span className="op-class">O(1)</span>
              <span className="op-val">{opO1} ops</span>
              <span className="op-label">Constant (Hash Lookup)</span>
            </div>
            <div className="op-card op-log">
              <span className="op-class">O(log n)</span>
              <span className="op-val">{opLogN} ops</span>
              <span className="op-label">Logarithmic (Binary Search)</span>
            </div>
            <div className="op-card op-n">
              <span className="op-class">O(n)</span>
              <span className="op-val">{opN} ops</span>
              <span className="op-label">Linear (Array Scan)</span>
            </div>
            <div className="op-card op-nlog">
              <span className="op-class">O(n log n)</span>
              <span className="op-val">{opNLogN} ops</span>
              <span className="op-label">Linearithmic (Merge Sort)</span>
            </div>
            <div className="op-card op-n2">
              <span className="op-class">O(n²)</span>
              <span className="op-val">{opN2.toLocaleString()} ops</span>
              <span className="op-label">Quadratic (Nested Loops)</span>
            </div>
            <div className="op-card op-2n">
              <span className="op-class">O(2ⁿ)</span>
              <span className="op-val">{op2N} ops</span>
              <span className="op-label">Exponential (Brute Force)</span>
            </div>
          </div>

          {/* Dynamic Graph */}
          <div className="complexity-chart-canvas">
            <Line data={chartData} options={chartOptions} />
          </div>
        </div>
      )}

      {activeTab === 'ds' && (
        <div className="animate-fade-up table-responsive">
          <table className="complexity-table">
            <thead>
              <tr>
                <th>Data Structure</th>
                <th>Access</th>
                <th>Search</th>
                <th>Insertion</th>
                <th>Deletion</th>
                <th>Space Complexity</th>
              </tr>
            </thead>
            <tbody>
              {dsData.map((row) => (
                <tr key={row.name}>
                  <td><strong>{row.name}</strong></td>
                  <td><span className="code-chip">{row.access}</span></td>
                  <td><span className="code-chip">{row.search}</span></td>
                  <td><span className="code-chip">{row.insert}</span></td>
                  <td><span className="code-chip">{row.delete}</span></td>
                  <td><span className="code-chip">{row.space}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'sort' && (
        <div className="animate-fade-up table-responsive">
          <table className="complexity-table">
            <thead>
              <tr>
                <th>Algorithm</th>
                <th>Best Time</th>
                <th>Average Time</th>
                <th>Worst Time</th>
                <th>Space Complexity</th>
                <th>Stable</th>
              </tr>
            </thead>
            <tbody>
              {sortData.map((row) => (
                <tr key={row.name}>
                  <td><strong>{row.name}</strong></td>
                  <td><span className="code-chip">{row.best}</span></td>
                  <td><span className="code-chip">{row.avg}</span></td>
                  <td><span className="code-chip">{row.worst}</span></td>
                  <td><span className="code-chip">{row.space}</span></td>
                  <td>
                    <span className={row.stable === 'Yes' ? 'text-emerald' : 'text-amber'} style={{ fontWeight: 700 }}>
                      {row.stable}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
