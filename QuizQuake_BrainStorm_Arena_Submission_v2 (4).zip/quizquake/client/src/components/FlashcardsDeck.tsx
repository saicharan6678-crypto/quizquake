import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Eye, RefreshCw, Sparkles } from 'lucide-react';
import { Question } from '../types';
import { getDifficultyThemeClass, getTopicThemeClass } from '../utils';
import { soundFX } from '../services/soundFX';

interface Props {
  questions: Question[];
  topics: string[];
}

export const FlashcardsDeck: React.FC<Props> = ({ questions, topics }) => {
  const [selectedTopic, setSelectedTopic] = useState<string>('All');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const filtered = questions.filter((q) => selectedTopic === 'All' || q.topic === selectedTopic);
  const currentQ = filtered[currentIndex] || filtered[0];

  const handleFlip = () => {
    soundFX.playClick();
    setIsFlipped(!isFlipped);
  };

  const handleNext = () => {
    soundFX.playClick();
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % filtered.length);
  };

  const handlePrev = () => {
    soundFX.playClick();
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + filtered.length) % filtered.length);
  };

  const handleTopicChange = (topic: string) => {
    soundFX.playClick();
    setSelectedTopic(topic);
    setCurrentIndex(0);
    setIsFlipped(false);
  };

  if (!currentQ) return null;

  return (
    <div className="card animate-stage flashcards-container">
      <div className="row-between" style={{ marginBottom: '1.2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-fuchsia">
            <Sparkles size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Rapid Flashcards Practice</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Flip cards in 3D space to test your recall before graded assessments
            </span>
          </div>
        </div>

        <div className="flashcard-counter">
          Card <strong>{currentIndex + 1}</strong> of <strong>{filtered.length}</strong>
        </div>
      </div>

      {/* Topic selection chips */}
      <div className="topic-chip-row" style={{ marginBottom: '1.25rem' }}>
        <button
          type="button"
          className={`topic-chip ${selectedTopic === 'All' ? 'active topic-custom' : ''}`}
          onClick={() => handleTopicChange('All')}
        >
          All Topics ({questions.length})
        </button>
        {topics.map((t) => (
          <button
            key={t}
            type="button"
            className={`topic-chip ${getTopicThemeClass(t)} ${selectedTopic === t ? 'active' : ''}`}
            onClick={() => handleTopicChange(t)}
          >
            {t}
          </button>
        ))}
      </div>

      {/* 3D Flip Card Container */}
      <div className="flashcard-scene" onClick={handleFlip}>
        <div className={`flashcard-3d ${isFlipped ? 'flipped' : ''}`}>
          {/* Card Front */}
          <div className="flashcard-face flashcard-front">
            <div className="flashcard-top-row">
              <span className={`badge ${getTopicThemeClass(currentQ.topic)}`}>{currentQ.topic}</span>
              <span className={`badge ${getDifficultyThemeClass(currentQ.difficulty)}`}>
                {currentQ.difficulty}
              </span>
            </div>

            <div className="flashcard-body">
              <span className="flashcard-hint-label">Question:</span>
              <h3 className="flashcard-prompt">{currentQ.question}</h3>
              <div className="flashcard-options-preview">
                {currentQ.options.map((opt, i) => (
                  <div key={opt} className="opt-preview-item">
                    <span className="opt-pill-key">{i + 1}</span> {opt}
                  </div>
                ))}
              </div>
            </div>

            <div className="flashcard-footer">
              <span className="flip-prompt">
                <Eye size={15} /> Click card to reveal answer &amp; explanation
              </span>
            </div>
          </div>

          {/* Card Back */}
          <div className="flashcard-face flashcard-back">
            <div className="flashcard-top-row">
              <span className="badge badge-emerald">CORRECT ANSWER</span>
              <span className={`badge ${getTopicThemeClass(currentQ.topic)}`}>{currentQ.subtopic}</span>
            </div>

            <div className="flashcard-body">
              <div className="correct-answer-banner">
                <span className="banner-title">Answer:</span>
                <span className="banner-value">{currentQ.options[currentQ.correctIndex]}</span>
              </div>

              <div className="explanation-section">
                <strong>Why?</strong>
                <p>{currentQ.explanation}</p>
              </div>
            </div>

            <div className="flashcard-footer">
              <span className="flip-prompt">
                <RefreshCw size={14} /> Click again to flip back
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom navigation controls */}
      <div className="flashcard-nav-controls">
        <button type="button" className="btn btn-secondary" onClick={handlePrev}>
          <ChevronLeft size={16} /> Previous Card
        </button>
        <button type="button" className="btn btn-primary btn-glow" onClick={handleNext}>
          Next Card <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
};
