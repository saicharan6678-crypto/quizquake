import React from 'react';
import { Brain, Flame, Sparkles, Trophy, Zap } from 'lucide-react';
import { PlayerStats } from '../services/xpSystem';

interface Props {
  playerStats: PlayerStats;
  questionCount: number;
  onLaunchArena: () => void;
  onLaunchAssignment: () => void;
}

export const HeroArenaBanner: React.FC<Props> = ({
  playerStats,
  questionCount,
  onLaunchArena,
  onLaunchAssignment,
}) => {
  return (
    <div className="hero-motion-card">
      <div className="hero-ambient-glow" />

      {/* Holographic Motion Rings Graphic (Clean slate-indigo orbital design) */}
      <div className="hologram-wrap">
        <div className="holo-ring holo-ring-1" />
        <div className="holo-ring holo-ring-2" />
        <div className="holo-ring holo-ring-3" />
        <div className="holo-brain-core">
          <Brain size={40} className="holo-brain-icon" />
          <div className="holo-scanner-beam" />
        </div>
      </div>

      <div className="hero-content">
        <div className="hero-badge-row">
          <span className="cyber-pill">
            <Sparkles size={13} /> BrainStorm Arena v2.0
          </span>
          <span className="cyber-pill">
            <Zap size={13} /> {questionCount} Curated MCQs
          </span>
          <span className="cyber-pill">
            <Flame size={13} /> Adaptive Tier Scaling
          </span>
        </div>

        <h1 className="hero-title">
          Master Computer Science through <span className="hero-title-accent">Adaptive Speed Battles</span>
        </h1>
        <p className="hero-subtitle">
          Engineered for rapid conceptual mastery across Data Structures, Algorithms, OS, and Networks with real-time feedback, analytics, and instant PDF transcripts.
        </p>

        {/* Player Level & XP Progression Strip */}
        <div className="hero-xp-strip">
          <div className="xp-info">
            <div className="xp-avatar">
              <Trophy size={16} />
            </div>
            <div>
              <span className="xp-rank-title">Level {playerStats.level} • {playerStats.title}</span>
              <span className="xp-numbers">
                {playerStats.currentLevelXp} / {playerStats.nextLevelXp} XP to Level {playerStats.level + 1}
              </span>
            </div>
          </div>
          <div className="hero-xp-bar-track">
            <div
              className="hero-xp-bar-fill"
              style={{ width: `${playerStats.progressPercent}%` }}
            />
          </div>
        </div>

        <div className="hero-actions">
          <button type="button" className="btn btn-primary hero-btn" onClick={onLaunchArena}>
            <Zap size={17} /> Launch Adaptive Arena
          </button>
          <button type="button" className="btn btn-secondary hero-btn" onClick={onLaunchAssignment}>
            Custom Topic Drills
          </button>
        </div>
      </div>
    </div>
  );
};
