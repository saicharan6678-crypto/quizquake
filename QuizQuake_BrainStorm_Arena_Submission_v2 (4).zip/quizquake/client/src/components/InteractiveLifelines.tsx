import React from 'react';
import { HelpCircle, Scissors, Snowflake } from 'lucide-react';
import { soundFX } from '../services/soundFX';
import { particleEngine } from '../services/particleExplosion';

interface Props {
  used5050: boolean;
  usedFreeze: boolean;
  usedClue: boolean;
  clueText?: string;
  showClue: boolean;
  onUse5050: () => void;
  onUseFreeze: () => void;
  onToggleClue: () => void;
}

export const InteractiveLifelines: React.FC<Props> = ({
  used5050,
  usedFreeze,
  usedClue,
  clueText,
  showClue,
  onUse5050,
  onUseFreeze,
  onToggleClue,
}) => {
  const handle5050Click = (e: React.MouseEvent) => {
    if (used5050) return;
    soundFX.playLaserZap();
    particleEngine.burstAt(e.clientX, e.clientY, true);
    onUse5050();
  };

  const handleFreezeClick = (e: React.MouseEvent) => {
    if (usedFreeze) return;
    soundFX.playFreeze();
    particleEngine.burstAt(e.clientX, e.clientY, true);
    onUseFreeze();
  };

  const handleClueClick = () => {
    soundFX.playClick();
    onToggleClue();
  };

  return (
    <div className="lifelines-strip">
      <span className="lifelines-title">⚡ Tactical Lifelines:</span>

      <button
        type="button"
        disabled={used5050}
        onClick={handle5050Click}
        className={`lifeline-btn ${used5050 ? 'used' : 'ready'}`}
        title="Eliminate two incorrect options"
      >
        <Scissors size={14} className="lifeline-icon" />
        <span>50:50 {used5050 ? '(Used)' : ''}</span>
      </button>

      <button
        type="button"
        disabled={usedFreeze}
        onClick={handleFreezeClick}
        className={`lifeline-btn freeze-btn ${usedFreeze ? 'used' : 'ready'}`}
        title="Add +30 seconds to the timer"
      >
        <Snowflake size={14} className="lifeline-icon" />
        <span>+30s Freeze {usedFreeze ? '(Used)' : ''}</span>
      </button>

      <button
        type="button"
        disabled={usedClue}
        onClick={handleClueClick}
        className={`lifeline-btn clue-btn ${usedClue && !showClue ? 'used' : 'ready'}`}
        title="Reveal subtopic concept clue"
      >
        <HelpCircle size={14} className="lifeline-icon" />
        <span>Concept Clue</span>
      </button>

      {showClue && clueText && (
        <div className="concept-clue-popover animate-fade-up">
          <span className="clue-tag">💡 SUBTOPIC INTEL:</span>
          <p className="clue-body">{clueText}</p>
        </div>
      )}
    </div>
  );
};
