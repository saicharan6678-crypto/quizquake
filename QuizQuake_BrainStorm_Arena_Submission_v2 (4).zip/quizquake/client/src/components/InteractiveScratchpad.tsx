import React, { useEffect, useState } from 'react';
import { Check, Copy, Edit3, Trash2, X } from 'lucide-react';
import { soundFX } from '../services/soundFX';
import { readItem, writeItem } from '../services/safeStorage';

const SCRATCHPAD_KEY = 'quizquake_student_scratchpad_v1';

export const InteractiveScratchpad: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notes, setNotes] = useState(() => {
    return readItem(SCRATCHPAD_KEY) || '// Scratchpad for Algorithm Tracing, Complexity Notes & Logic\n\n';
  });
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    writeItem(SCRATCHPAD_KEY, notes);
  }, [notes]);

  const handleToggle = () => {
    soundFX.playClick();
    setIsOpen(!isOpen);
  };

  const handleCopy = () => {
    soundFX.playClick();
    navigator.clipboard.writeText(notes);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClear = () => {
    soundFX.playClick();
    if (window.confirm('Clear all scratchpad notes?')) {
      setNotes('');
    }
  };

  const insertSnippet = (snippet: string) => {
    soundFX.playClick();
    setNotes((prev) => `${prev}\n${snippet}\n`);
  };

  return (
    <>
      {/* Floating launcher pill in bottom corner */}
      <button
        type="button"
        className={`floating-scratchpad-btn ${isOpen ? 'active' : ''}`}
        onClick={handleToggle}
        title="Open CS Logic Scratchpad"
      >
        <Edit3 size={17} />
        <span>Scratchpad</span>
      </button>

      {/* Slide-out Scratchpad Drawer */}
      {isOpen && (
        <div className="scratchpad-drawer animate-fade-up">
          <div className="scratchpad-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Edit3 size={16} className="text-cyan" />
              <strong>CS Logic &amp; Code Scratchpad</strong>
            </div>
            <div style={{ display: 'flex', gap: '0.4rem' }}>
              <button
                type="button"
                className="btn-scratch-icon"
                onClick={handleCopy}
                title="Copy to clipboard"
              >
                {copied ? <Check size={14} color="#10b981" /> : <Copy size={14} />}
              </button>
              <button
                type="button"
                className="btn-scratch-icon"
                onClick={handleClear}
                title="Clear notes"
              >
                <Trash2 size={14} />
              </button>
              <button
                type="button"
                className="btn-scratch-icon"
                onClick={handleToggle}
                title="Close scratchpad"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          <div className="scratchpad-snippets">
            <span style={{ fontSize: '0.74rem', color: '#94a3b8' }}>Snippets:</span>
            <button
              type="button"
              className="snippet-chip"
              onClick={() => insertSnippet('O(1) < O(log n) < O(n) < O(n log n) < O(n^2)')}
            >
              Big-O
            </button>
            <button
              type="button"
              className="snippet-chip"
              onClick={() => insertSnippet('Queue: FIFO | Stack: LIFO | Tree: Hierarchical')}
            >
              DS Rules
            </button>
            <button
              type="button"
              className="snippet-chip"
              onClick={() => insertSnippet('TCP 3-Way Handshake: SYN -> SYN-ACK -> ACK')}
            >
              TCP
            </button>
          </div>

          <textarea
            className="scratchpad-textarea"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Type code, tree diagrams, or runtime notes here..."
            rows={10}
          />

          <div className="scratchpad-footer">
            <span style={{ fontSize: '0.74rem', color: '#94a3b8' }}>
              {notes.length} chars • Auto-saved in browser
            </span>
          </div>
        </div>
      )}
    </>
  );
};
