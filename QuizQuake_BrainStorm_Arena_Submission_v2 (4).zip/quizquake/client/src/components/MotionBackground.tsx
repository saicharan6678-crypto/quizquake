import React, { useEffect, useRef } from 'react';
import { particleEngine } from '../services/particleExplosion';

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
}

export const MotionBackground: React.FC = () => {
  const meshCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fxCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    // Initialize Confetti / FX Canvas
    if (fxCanvasRef.current) {
      particleEngine.init(fxCanvasRef.current);
    }
    return () => {
      particleEngine.destroy();
    };
  }, []);

  useEffect(() => {
    // Elegant constellation / neural network canvas in clean indigo-slate palette
    const canvas = meshCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const colors = ['#818cf8', '#6366f1', '#a5b4fc', '#4f46e5', '#94a3b8'];
    const nodeCount = Math.min(60, Math.floor((width * height) / 24000));
    const nodes: Node[] = [];

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.6,
        vy: (Math.random() - 0.5) * 0.6,
        radius: 1.5 + Math.random() * 2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    let mouseX = -9999;
    let mouseY = -9999;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };
    window.addEventListener('mousemove', handleMouseMove);

    const maxDist = 120;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Update and draw nodes
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.vx;
        n.y += n.vy;

        // Bounce off walls
        if (n.x < 0 || n.x > width) n.vx *= -1;
        if (n.y < 0 || n.y > height) n.vy *= -1;

        // Subtle mouse repulsion
        const dx = n.x - mouseX;
        const dy = n.y - mouseY;
        const distToMouse = Math.sqrt(dx * dx + dy * dy);
        if (distToMouse < 130) {
          const force = (130 - distToMouse) / 130;
          n.x += (dx / distToMouse) * force * 2;
          n.y += (dy / distToMouse) * force * 2;
        }

        // Draw connections
        for (let j = i + 1; j < nodes.length; j++) {
          const n2 = nodes[j];
          const dist = Math.hypot(n.x - n2.x, n.y - n2.y);
          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.18;
            ctx.beginPath();
            ctx.moveTo(n.x, n.y);
            ctx.lineTo(n2.x, n2.y);
            ctx.strokeStyle = `rgba(148, 163, 235, ${alpha})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }

        // Draw node
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
        ctx.fillStyle = n.color;
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="bg-aurora-interactive" aria-hidden="true">
      {/* Dynamic Mesh & Neural Constellation Canvas */}
      <canvas ref={meshCanvasRef} className="motion-mesh-canvas" />

      {/* Subtle Deep Navy Ambient Lighting (No RGB rainbow halos) */}
      <span className="ambient-glow glow-1" />
      <span className="ambient-glow glow-2" />

      {/* Subtle Grid Overlay */}
      <div className="cyber-grid" />

      {/* Subtle Tech Glyphs */}
      <div className="floating-glyphs">
        <span className="glyph g1">{'</>'}</span>
        <span className="glyph g2">{'{ }'}</span>
        <span className="glyph g3">O(1)</span>
        <span className="glyph g4">0110</span>
        <span className="glyph g5">λ</span>
        <span className="glyph g6">CPU</span>
        <span className="glyph g7">ACK</span>
        <span className="glyph g8">O(n log n)</span>
        <span className="glyph g9">0x7F</span>
      </div>

      {/* Confetti & Particle Explosion FX Canvas */}
      <canvas ref={fxCanvasRef} className="fx-particles-canvas" />
    </div>
  );
};
