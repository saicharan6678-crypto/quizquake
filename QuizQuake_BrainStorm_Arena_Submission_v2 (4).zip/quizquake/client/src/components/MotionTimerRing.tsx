import React, { useEffect } from 'react';
import { soundFX } from '../services/soundFX';

interface Props {
  secondsLeft: number;
  totalSeconds: number;
}

export const MotionTimerRing: React.FC<Props> = ({ secondsLeft, totalSeconds }) => {
  const radius = 22;
  const stroke = 3.5;
  const normalizedRadius = radius - stroke * 0.5;
  const circumference = normalizedRadius * 2 * Math.PI;

  const validTotal = Math.max(1, totalSeconds);
  const ratio = Math.max(0, Math.min(1, secondsLeft / validTotal));
  const strokeDashoffset = circumference - ratio * circumference;

  const isUrgent = secondsLeft <= 30 && secondsLeft > 0;
  const isCritical = secondsLeft <= 10 && secondsLeft > 0;

  // Sound ticking on final 10 seconds
  useEffect(() => {
    if (isCritical) {
      soundFX.playUrgentTick();
    }
  }, [secondsLeft, isCritical]);

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${minutes}:${seconds.toString().padStart(2, '0')}`;

  let strokeColor = '#06b6d4'; // Cyan
  if (ratio < 0.25) {
    strokeColor = '#ef4444'; // Red
  } else if (ratio < 0.5) {
    strokeColor = '#f59e0b'; // Amber
  }

  return (
    <div className={`motion-timer-container ${isUrgent ? 'urgent' : ''} ${isCritical ? 'critical' : ''}`}>
      <svg height={radius * 2} width={radius * 2} className="timer-svg">
        <circle
          stroke="rgba(255, 255, 255, 0.15)"
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          stroke={strokeColor}
          fill="transparent"
          strokeWidth={stroke}
          strokeDasharray={`${circumference} ${circumference}`}
          style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.85s linear, stroke 0.3s ease' }}
          strokeLinecap="round"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          className="timer-progress-ring"
        />
      </svg>
      <div className="timer-text-wrap">
        <span className="timer-digits">{formattedTime}</span>
      </div>
    </div>
  );
};
