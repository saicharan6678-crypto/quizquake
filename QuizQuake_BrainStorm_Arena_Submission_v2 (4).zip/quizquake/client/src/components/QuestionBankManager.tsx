import React, { useRef, useState } from 'react';
import { Download, PlusCircle, Search, Sparkles, Trash2, Upload } from 'lucide-react';
import { Difficulty, Question } from '../types';
import { getDifficultyThemeClass, getTopicThemeClass } from '../utils';
import { soundFX } from '../services/soundFX';
import { particleEngine } from '../services/particleExplosion';
import { logger } from '../services/logger';
import { partitionQuestions } from '../validation';

interface Props {
  existingTopics: string[];
  allQuestions: Question[];
  onAddQuestion: (q: Question) => void;
  onImportQuestions?: (qs: Question[]) => void;
  onDeleteQuestion?: (id: string) => void;
}

export const QuestionBankManager: React.FC<Props> = ({
  existingTopics,
  allQuestions,
  onAddQuestion,
  onImportQuestions,
  onDeleteQuestion,
}) => {
  const [topic, setTopic] = useState(existingTopics[0] || 'Data Structures');
  const [customTopic, setCustomTopic] = useState('');
  const [subtopic, setSubtopic] = useState('Core Concepts');
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [prompt, setPrompt] = useState('');
  const [opt0, setOpt0] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [correctIndex, setCorrectIndex] = useState(0);
  const [explanation, setExplanation] = useState('');
  const [savedBanner, setSavedBanner] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedTopic = customTopic.trim() || topic;
    const options = [opt0.trim(), opt1.trim(), opt2.trim(), opt3.trim()];
    if (!resolvedTopic || !prompt.trim() || options.some((o) => !o)) return;

    const newQuestion: Question = {
      id: `custom-${Date.now()}`,
      topic: resolvedTopic,
      subtopic: subtopic.trim() || 'General',
      difficulty,
      question: prompt.trim(),
      options,
      correctIndex,
      explanation: explanation.trim() || 'Custom question added to your QuizQuake bank.',
    };

    soundFX.playCorrect();
    particleEngine.fireConfetti(35);
    onAddQuestion(newQuestion);

    setPrompt('');
    setOpt0('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setExplanation('');
    setSavedBanner(true);
    window.setTimeout(() => setSavedBanner(false), 3200);
  };

  const exportToJson = () => {
    soundFX.playClick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(allQuestions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `quizquake-question-bank-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed: unknown = JSON.parse(event.target?.result as string);
        const { valid, rejected } = partitionQuestions(parsed);
        if (valid.length === 0) {
          alert('No valid questions found. Each question needs id, topic, subtopic, difficulty, question, options (2-6) and a valid correctIndex.');
          return;
        }
        if (onImportQuestions) {
          onImportQuestions(valid);
        } else {
          valid.forEach((q) => onAddQuestion(q));
        }
        soundFX.playVictory();
        particleEngine.fireConfetti(60);
        alert(
          `Imported ${valid.length} question(s) into QuizQuake!` +
            (rejected > 0 ? ` ${rejected} invalid entr${rejected === 1 ? 'y was' : 'ies were'} skipped.` : '')
        );
      } catch (err) {
        logger.warn('import', 'Question file could not be parsed', err);
        alert('Invalid JSON file. Please ensure it follows the Question schema.');
      }
    };
    reader.readAsText(file);
  };

  const filteredQuestions = allQuestions.filter((q) => {
    const matchesSearch =
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.subtopic.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="card animate-stage">
      <div className="row-between" style={{ marginBottom: '1.2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-emerald">
            <PlusCircle size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Question Bank Manager &amp; Studio</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Create, import, and export custom topic questions for assignments
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.55rem', flexWrap: 'wrap' }}>
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: 'none' }}
            accept=".json"
            onChange={handleFileUpload}
          />
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload size={14} /> Import JSON
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={exportToJson}>
            <Download size={14} /> Export Bank ({allQuestions.length})
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="animate-fade-up">
        <div className="form-grid">
          <label className="field">
            <span>Existing Topic</span>
            <select value={topic} onChange={(e) => setTopic(e.target.value)}>
              {existingTopics.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </label>

          <label className="field">
            <span>Or New Topic Name (Optional)</span>
            <input
              type="text"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              placeholder="e.g. Database Systems"
            />
          </label>

          <label className="field">
            <span>Subtopic</span>
            <input
              type="text"
              value={subtopic}
              onChange={(e) => setSubtopic(e.target.value)}
              placeholder="e.g. Indexing & SQL"
            />
          </label>

          <label className="field">
            <span>Difficulty Tier</span>
            <select value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)}>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </label>
        </div>

        <label className="field" style={{ marginTop: '0.95rem' }}>
          <span>Question Prompt</span>
          <input
            type="text"
            required
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Enter the question text..."
          />
        </label>

        <div className="form-grid" style={{ marginTop: '0.95rem' }}>
          <label className="field">
            <span>Option 1</span>
            <input type="text" required value={opt0} onChange={(e) => setOpt0(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 2</span>
            <input type="text" required value={opt1} onChange={(e) => setOpt1(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 3</span>
            <input type="text" required value={opt2} onChange={(e) => setOpt2(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 4</span>
            <input type="text" required value={opt3} onChange={(e) => setOpt3(e.target.value)} />
          </label>
        </div>

        <div className="form-grid" style={{ marginTop: '0.95rem' }}>
          <label className="field">
            <span>Correct Option</span>
            <select value={correctIndex} onChange={(e) => setCorrectIndex(Number(e.target.value))}>
              <option value={0}>Option 1</option>
              <option value={1}>Option 2</option>
              <option value={2}>Option 3</option>
              <option value={3}>Option 4</option>
            </select>
          </label>

          <label className="field">
            <span>Explanation &amp; Concept Note</span>
            <input
              type="text"
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              placeholder="Why is this answer correct?"
            />
          </label>
        </div>

        <div style={{ marginTop: '1.2rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <button type="submit" className="btn btn-primary btn-glow">
            <Sparkles size={16} /> Save Question to Repository
          </button>
          {savedBanner && (
            <span className="toast-pill">Added! Question is now live across Arena &amp; Assignments.</span>
          )}
        </div>
      </form>

      {/* Repository Browser with Live Search */}
      <div style={{ marginTop: '2.4rem' }}>
        <div className="row-between" style={{ marginBottom: '1rem' }}>
          <h3 style={{ margin: 0 }}>
            Live Question Repository ({filteredQuestions.length})
          </h3>
          <div className="search-bar-wrap">
            <Search size={15} className="search-icon" />
            <input
              type="text"
              className="search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search questions or topics..."
            />
          </div>
        </div>

        <div className="question-repo-list stack-sm">
          {filteredQuestions.slice(0, 15).map((q) => (
            <div key={q.id} className="repo-question-item">
              <div className="repo-q-meta">
                <span className={`badge ${getTopicThemeClass(q.topic)}`}>{q.topic}</span>
                <span className={`badge ${getDifficultyThemeClass(q.difficulty)}`}>{q.difficulty}</span>
                <span className="muted" style={{ fontSize: '0.78rem' }}>
                  {q.subtopic}
                </span>
              </div>
              <div className="repo-q-title">{q.question}</div>
              <div className="repo-q-correct">
                Correct: <strong>{q.options[q.correctIndex]}</strong>
              </div>
              {onDeleteQuestion && q.id.startsWith('custom-') && (
                <button
                  type="button"
                  className="btn-icon-danger"
                  title="Delete Custom Question"
                  onClick={() => onDeleteQuestion(q.id)}
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          ))}
          {filteredQuestions.length > 15 && (
            <div className="muted" style={{ textAlign: 'center', padding: '0.5rem 0', fontSize: '0.88rem' }}>
              Showing 15 of {filteredQuestions.length} questions. Use search to filter specific topics.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
