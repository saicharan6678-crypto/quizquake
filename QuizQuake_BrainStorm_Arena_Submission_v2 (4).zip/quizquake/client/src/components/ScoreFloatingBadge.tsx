import React, { useEffect, useState } from 'react';

export interface FloatingNotification {
  id: string;
  text: string;
  type: 'points' | 'streak' | 'combo' | 'bonus';
  x?: number;
  y?: number;
}

interface Props {
  notification: FloatingNotification | null;
}

export const ScoreFloatingBadge: React.FC<Props> = ({ notification }) => {
  const [activeItem, setActiveItem] = useState<FloatingNotification | null>(null);

  useEffect(() => {
    if (!notification) return;
    setActiveItem(notification);
    const timer = setTimeout(() => {
      setActiveItem(null);
    }, 1400);
    return () => clearTimeout(timer);
  }, [notification]);

  if (!activeItem) return null;

  return (
    <div
      className={`floating-popup-badge type-${activeItem.type}`}
      style={
        activeItem.x && activeItem.y
          ? { left: `${activeItem.x}px`, top: `${activeItem.y}px`, position: 'fixed' }
          : undefined
      }
    >
      <span className="floating-text">{activeItem.text}</span>
    </div>
  );
};
