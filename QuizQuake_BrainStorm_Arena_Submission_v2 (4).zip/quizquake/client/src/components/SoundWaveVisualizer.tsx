import React from 'react';
import { soundFX } from '../services/soundFX';

interface Props {
  isActive: boolean;
}

export const SoundWaveVisualizer: React.FC<Props> = ({ isActive }) => {
  const handlePlayTone = () => {
    soundFX.playCorrect();
  };

  return (
    <div
      className={`sound-wave-eq ${isActive ? 'playing' : 'idle'}`}
      onClick={handlePlayTone}
      title="Interactive Audio Frequency Waveform — Click to test sound!"
    >
      <span className="eq-bar bar-1" />
      <span className="eq-bar bar-2" />
      <span className="eq-bar bar-3" />
      <span className="eq-bar bar-4" />
      <span className="eq-bar bar-5" />
    </div>
  );
};
