import React, { useEffect, useState } from 'react';
import { Award, CheckCircle2, Clock, Flame, Play, RotateCcw, Zap } from 'lucide-react';
import { Question } from '../types';
import { soundFX } from '../services/soundFX';
import { particleEngine } from '../services/particleExplosion';
import { getDifficultyThemeClass, getTopicThemeClass } from '../utils';
import { readItem, writeItem } from '../services/safeStorage';

interface Props {
  questions: Question[];
  onAwardXp: (amount: number, reason: string) => void;
  onUnlockAchievement: (id: string) => void;
}

const BLITZ_BEST_KEY = 'quizquake_speed_blitz_highscore_v1';

export const SpeedBlitzView: React.FC<Props> = ({
  questions,
  onAwardXp,
  onUnlockAchievement,
}) => {
  const [running, setRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [currentQ, setCurrentQ] = useState<Question | null>(null);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [highScore, setHighScore] = useState<number>(() => {
    return Number(readItem(BLITZ_BEST_KEY)) || 0;
  });
  const [finished, setFinished] = useState(false);

  const startBlitz = () => {
    soundFX.playClick();
    const shuffled = [...questions].sort(() => Math.random() - 0.5);
    setCurrentQ(shuffled[0] || null);
    setSecondsLeft(60);
    setScore(0);
    setStreak(0);
    setCorrectCount(0);
    setTotalAnswered(0);
    setSelectedOpt(null);
    setFinished(false);
    setRunning(true);
  };

  const endBlitz = () => {
    setRunning(false);
    setFinished(true);

    if (score > highScore) {
      setHighScore(score);
      writeItem(BLITZ_BEST_KEY, String(score));
      soundFX.playVictory();
      particleEngine.fireConfetti(120);
    } else if (correctCount > 0) {
      soundFX.playVictory();
    }

    if (score > 0) {
      onAwardXp(score, '60-Second Blitz Score');
    }
    if (correctCount >= 8) {
      onUnlockAchievement('speed_demon');
    }
  };

  useEffect(() => {
    if (!running) return;
    if (secondsLeft <= 0) {
      endBlitz();
      return;
    }
    const timer = window.setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearInterval(timer);
  }, [running, secondsLeft]);

  const handlePickAnswer = (idx: number, e?: React.MouseEvent) => {
    if (!currentQ || selectedOpt !== null) return;
    setSelectedOpt(idx);

    const isCorrect = idx === currentQ.correctIndex;
    const newStreak = isCorrect ? streak + 1 : 0;
    const gained = isCorrect ? 100 + (newStreak - 1) * 20 : 0;

    if (e) {
      particleEngine.burstAt(e.clientX, e.clientY, isCorrect);
    }

    if (isCorrect) {
      soundFX.playCorrect();
      setCorrectCount((c) => c + 1);
      setScore((s) => s + gained);
      setStreak(newStreak);
      if (newStreak >= 3) onUnlockAchievement('streak_3');
    } else {
      soundFX.playIncorrect();
      setStreak(0);
    }

    setTotalAnswered((t) => t + 1);

    // Rapid transition to next question in 400ms
    window.setTimeout(() => {
      const nextQ = questions[Math.floor(Math.random() * questions.length)];
      setCurrentQ(nextQ);
      setSelectedOpt(null);
    }, 450);
  };

  return (
    <div className="card animate-stage">
      <div className="row-between" style={{ marginBottom: '1.25rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-indigo">
            <Zap size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>60-Second Speed Blitz Challenge</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Rapid-fire CS recall — answer as many questions as you can before the clock hits zero!
            </span>
          </div>
        </div>

        <div className="blitz-highscore-pill">
          <Award size={15} /> All-Time Blitz Record: <strong>{highScore} pts</strong>
        </div>
      </div>

      {!running && !finished && (
        <div className="blitz-hero-intro animate-fade-up">
          <div className="blitz-intro-content">
            <h3 style={{ fontSize: '1.4rem', margin: '0 0 0.5rem' }}>Test Your Instantaneous CS Intuition</h3>
            <p className="muted" style={{ maxWidth: '580px', margin: '0 0 1.25rem', lineHeight: 1.55 }}>
              60 seconds on the clock. Continuous questions from Data Structures, Algorithms, OS, and Networks. Fast correct answers ramp up streak multipliers!
            </p>
            <button type="button" className="btn btn-primary" onClick={startBlitz} style={{ padding: '0.8rem 1.6rem', fontSize: '1rem' }}>
              <Play size={18} /> Launch 60-Second Blitz
            </button>
          </div>
        </div>
      )}

      {running && currentQ && (
        <div className="animate-fade-up">
          <div className="row-between" style={{ marginBottom: '0.85rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <span className={`badge ${getTopicThemeClass(currentQ.topic)}`}>{currentQ.topic}</span>
              <span className={`badge ${getDifficultyThemeClass(currentQ.difficulty)}`}>{currentQ.difficulty}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div className={`blitz-timer-pill ${secondsLeft <= 15 ? 'urgent' : ''}`}>
                <Clock size={16} /> <strong>{secondsLeft}s</strong> remaining
              </div>
              <span className={`streak-pill ${streak >= 2 ? 'streak-hot' : ''}`}>
                <Flame size={15} /> Streak: <strong>{streak}</strong>
              </span>
              <span className="score-pill">
                Score: <strong>{score} pts</strong>
              </span>
            </div>
          </div>

          <h3 className="question-heading">{currentQ.question}</h3>

          <div className="stack-sm">
            {currentQ.options.map((opt, idx) => {
              let extra = '';
              if (selectedOpt !== null) {
                if (idx === currentQ.correctIndex) extra = 'correct-opt';
                else if (idx === selectedOpt) extra = 'wrong-opt';
              }

              return (
                <button
                  key={opt}
                  type="button"
                  disabled={selectedOpt !== null}
                  onClick={(e) => handlePickAnswer(idx, e)}
                  className={`option-btn ${extra}`}
                >
                  <span className="opt-key">{idx + 1}</span>
                  <span style={{ flexGrow: 1 }}>{opt}</span>
                  {selectedOpt !== null && idx === currentQ.correctIndex && (
                    <CheckCircle2 size={18} className="text-emerald" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {finished && (
        <div className="animate-fade-up">
          <div className="report-hero hero-pass">
            <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Award size={22} /> Speed Blitz Complete!
            </h3>
            <p style={{ margin: '0.4rem 0 0', opacity: 0.95 }}>
              Final Score: <strong>{score} pts</strong> • Correct Answers:{' '}
              <strong>
                {correctCount}/{totalAnswered} ({totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0}%)
              </strong>{' '}
              {score >= highScore && score > 0 && <span style={{ fontWeight: 800 }}>★ NEW ALL-TIME RECORD!</span>}
            </p>
          </div>

          <div style={{ marginTop: '1.25rem', display: 'flex', gap: '0.75rem' }}>
            <button type="button" className="btn btn-primary" onClick={startBlitz}>
              <RotateCcw size={16} /> Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
