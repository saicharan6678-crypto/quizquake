import React, { useEffect, useMemo, useState } from 'react';
import {
  Award,
  Bookmark,
  CheckCircle2,
  Download,
  FileText,
  Play,
  RotateCcw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { AttemptSummary, Difficulty, Question, QuizAnswerRecord } from '../types';
import { getDifficultyThemeClass, getTopicThemeClass } from '../utils';
import { exportAttemptPdf } from '../services/pdfExport';
import { soundFX } from '../services/soundFX';
import { particleEngine } from '../services/particleExplosion';
import { MotionTimerRing } from './MotionTimerRing';
import { ComboOverdriveBar } from './ComboOverdriveBar';
import { InteractiveLifelines } from './InteractiveLifelines';

interface Props {
  questions: Question[];
  history: AttemptSummary[];
  onSaveAttempt: (attempt: AttemptSummary) => void;
  onAwardXp?: (amount: number) => void;
  onUnlockAchievement?: (id: string) => void;
  onGenerateCertificate?: (attempt: AttemptSummary) => void;
  defaultTopic?: string;
}

type Stage = 'builder' | 'active' | 'report';

export const TopicAssignmentView: React.FC<Props> = ({
  questions,
  history,
  onSaveAttempt,
  onAwardXp,
  onUnlockAchievement,
  onGenerateCertificate,
  defaultTopic,
}) => {
  const topics = useMemo(() => {
    return Array.from(new Set(questions.map((q) => q.topic)));
  }, [questions]);

  const [title, setTitle] = useState('Topic Mastery Assignment');
  const [selectedTopic, setSelectedTopic] = useState<string>(defaultTopic || topics[0] || 'Data Structures');
  const [selectedTier, setSelectedTier] = useState<'All' | Difficulty>('All');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [minutes, setMinutes] = useState<number>(5);

  useEffect(() => {
    if (defaultTopic) {
      setSelectedTopic(defaultTopic);
    }
  }, [defaultTopic]);

  useEffect(() => {
    if (topics.length > 0 && !topics.includes(selectedTopic) && selectedTopic !== 'All') {
      setSelectedTopic(topics[0]);
    }
  }, [topics, selectedTopic]);

  const [stage, setStage] = useState<Stage>('builder');
  const [deck, setDeck] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedMap, setSelectedMap] = useState<Record<string, number>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(300);
  const [totalSeconds, setTotalSeconds] = useState(300);
  const [latestReport, setLatestReport] = useState<AttemptSummary | null>(null);
  const [onlyFlagged, setOnlyFlagged] = useState(false);

  // Lifelines & Streak state
  const [used5050, setUsed5050] = useState(false);
  const [usedFreeze, setUsedFreeze] = useState(false);
  const [usedClue, setUsedClue] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<Set<number>>(new Set());
  const [showClue, setShowClue] = useState(false);
  const [currentStreak, setCurrentStreak] = useState(0);

  const matchingPool = useMemo(() => {
    return questions.filter((q) => {
      const tOk = selectedTopic === 'All' || q.topic === selectedTopic;
      const dOk = selectedTier === 'All' || q.difficulty === selectedTier;
      return tOk && dOk;
    });
  }, [questions, selectedTopic, selectedTier]);

  const startAssignment = () => {
    soundFX.playClick();
    let pool = [...matchingPool];
    if (pool.length === 0 && selectedTopic !== 'All') {
      pool = questions.filter((q) => q.topic === selectedTopic);
    }
    if (pool.length === 0) {
      pool = [...questions];
    }

    const shuffled = pool.sort(() => Math.random() - 0.5);
    const chosen = shuffled.slice(0, Math.max(1, Math.min(questionCount, shuffled.length)));

    const dur = Math.max(30, minutes * 60);
    setDeck(chosen);
    setCurrentIdx(0);
    setSelectedMap({});
    setBookmarkedIds([]);
    setSecondsLeft(dur);
    setTotalSeconds(dur);
    setOnlyFlagged(false);
    setUsed5050(false);
    setUsedFreeze(false);
    setUsedClue(false);
    setEliminatedOptions(new Set());
    setShowClue(false);
    setCurrentStreak(0);
    setStage('active');
  };

  const currentQuestion = deck[currentIdx];

  // Reset 5050 eliminated choices and clue when switching questions
  useEffect(() => {
    setEliminatedOptions(new Set());
    setShowClue(false);
  }, [currentIdx]);

  const handleUse5050 = () => {
    if (used5050 || !currentQuestion) return;
    setUsed5050(true);
    if (onUnlockAchievement) onUnlockAchievement('lifeline_user');

    const wrongIndices = currentQuestion.options
      .map((_, idx) => idx)
      .filter((idx) => idx !== currentQuestion.correctIndex);

    const shuffledWrongs = wrongIndices.sort(() => Math.random() - 0.5);
    const toEliminate = new Set(shuffledWrongs.slice(0, 2));
    setEliminatedOptions(toEliminate);
  };

  const handleUseFreeze = () => {
    if (usedFreeze) return;
    setUsedFreeze(true);
    setSecondsLeft((s) => s + 30);
    setTotalSeconds((t) => t + 30);
    if (onUnlockAchievement) onUnlockAchievement('lifeline_user');
  };

  const submitAssignment = () => {
    let streak = 0;
    let bestStreak = 0;
    let score = 0;
    let earnedXp = 0;

    const records: QuizAnswerRecord[] = deck.map((q) => {
      const picked = selectedMap[q.id] ?? null;
      const isCorrect = picked === q.correctIndex;
      if (isCorrect) {
        streak += 1;
        bestStreak = Math.max(bestStreak, streak);
        const tierMult = q.difficulty === 'Hard' ? 1.5 : q.difficulty === 'Medium' ? 1.25 : 1;
        const pts = Math.round(100 * tierMult + (streak - 1) * 20);
        score += pts;
        earnedXp += pts;
      } else {
        streak = 0;
      }

      return {
        questionId: q.id,
        topic: q.topic,
        subtopic: q.subtopic,
        difficulty: q.difficulty,
        question: q.question,
        options: q.options,
        selectedIndex: picked,
        correctIndex: q.correctIndex,
        isCorrect,
        explanation: q.explanation,
        timeSpentSec: 0,
      };
    });

    const correctCount = records.filter((r) => r.isCorrect).length;
    const totalCount = records.length;
    const accuracyPercent = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;
    const passed = accuracyPercent >= 70;

    const attempt: AttemptSummary = {
      id: `assign-${Date.now()}`,
      mode: 'assignment',
      title: title.trim() || `${selectedTopic} Assignment`,
      topicFilter: selectedTopic === 'All' ? 'All Topics' : `${selectedTopic} (${selectedTier})`,
      completedAt: new Date().toLocaleString(),
      score,
      correctCount,
      totalCount,
      accuracyPercent,
      passed,
      bestStreak,
      bookmarkedIds,
      records,
    };

    setLatestReport(attempt);
    onSaveAttempt(attempt);

    if (onAwardXp && earnedXp > 0) {
      onAwardXp(earnedXp);
    }

    if (onUnlockAchievement) {
      if (correctCount > 0) onUnlockAchievement('first_blood');
      if (bestStreak >= 3) onUnlockAchievement('streak_3');
      if (bestStreak >= 5) onUnlockAchievement('streak_5');
      if (accuracyPercent >= 90) onUnlockAchievement('perfect_pass');
    }

    if (passed) {
      soundFX.playVictory();
      particleEngine.fireConfetti(100);
    } else {
      soundFX.playIncorrect();
    }

    setStage('report');
  };

  useEffect(() => {
    if (stage !== 'active') return;
    if (secondsLeft <= 0) {
      submitAssignment();
      return;
    }
    const timer = window.setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearInterval(timer);
  }, [stage, secondsLeft]);

  const handleSelectOption = (optIdx: number, e?: React.MouseEvent) => {
    if (!currentQuestion || eliminatedOptions.has(optIdx)) return;
    soundFX.playClick();
    setSelectedMap((prev) => ({ ...prev, [currentQuestion.id]: optIdx }));

    const isRight = optIdx === currentQuestion.correctIndex;
    if (isRight) {
      setCurrentStreak((s) => s + 1);
      if (onUnlockAchievement && currentStreak + 1 >= 3) onUnlockAchievement('streak_3');
    } else {
      setCurrentStreak(0);
    }

    if (e) {
      particleEngine.burstAt(e.clientX, e.clientY, isRight);
    }
  };

  useEffect(() => {
    if (stage !== 'active' || !currentQuestion) return;
    const onKey = (e: KeyboardEvent) => {
      const n = Number(e.key);
      if (n >= 1 && n <= currentQuestion.options.length) {
        handleSelectOption(n - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [stage, currentQuestion, eliminatedOptions]);

  const toggleBookmark = (id: string) => {
    soundFX.playClick();
    setBookmarkedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const assignmentHistory = history.filter((h) => h.mode === 'assignment');
  const answeredCount = Object.keys(selectedMap).length;

  return (
    <div className="card animate-stage">
      <div className="row-between" style={{ marginBottom: '1.2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-violet">
            <FileText size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Topic Assignment Studio</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Curated topic drills with tactical lifelines, combo gauge &amp; official certificate generator
            </span>
          </div>
        </div>
        {stage !== 'builder' && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              soundFX.playClick();
              setStage('builder');
            }}
          >
            Configure New Assignment
          </button>
        )}
      </div>

      {stage === 'builder' && (
        <div className="animate-fade-up">
          <div className="topic-chip-row">
            <button
              type="button"
              className={`topic-chip ${selectedTopic === 'All' ? 'active' : ''}`}
              onClick={() => {
                soundFX.playClick();
                setSelectedTopic('All');
              }}
            >
              <Sparkles size={14} /> All Topics ({questions.length})
            </button>
            {topics.map((t) => {
              const count = questions.filter((q) => q.topic === t).length;
              return (
                <button
                  key={t}
                  type="button"
                  className={`topic-chip ${selectedTopic === t ? 'active' : ''}`}
                  onClick={() => {
                    soundFX.playClick();
                    setSelectedTopic(t);
                  }}
                >
                  {t} ({count})
                </button>
              );
            })}
          </div>

          <div className="form-grid" style={{ marginTop: '1.1rem' }}>
            <label className="field">
              <span>Assignment Title</span>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Operating Systems Midterm Practice"
              />
            </label>

            <label className="field">
              <span>Selected Topic</span>
              <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}>
                <option value="All">All Topics (Mixed)</option>
                {topics.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </label>

            <label className="field">
              <span>Difficulty Tier</span>
              <select
                value={selectedTier}
                onChange={(e) => setSelectedTier(e.target.value as 'All' | Difficulty)}
              >
                <option value="All">All Tiers (Easy, Medium, Hard)</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </label>

            <label className="field">
              <span>Questions ({matchingPool.length} available)</span>
              <input
                type="number"
                min={1}
                max={Math.max(1, questions.length)}
                value={questionCount}
                onChange={(e) => setQuestionCount(Math.max(1, Number(e.target.value)))}
              />
            </label>

            <label className="field">
              <span>Time Limit (Minutes)</span>
              <input
                type="number"
                min={1}
                max={60}
                value={minutes}
                onChange={(e) => setMinutes(Math.max(1, Number(e.target.value)))}
              />
            </label>
          </div>

          <div style={{ marginTop: '1.4rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <button type="button" className="btn btn-primary" onClick={startAssignment}>
              <Play size={16} /> Start Topic Assignment
            </button>
            <span className="muted" style={{ fontSize: '0.9rem' }}>
              Pass threshold: <strong>70%</strong> • Keyboard shortcuts: <strong>1–4</strong>
            </span>
          </div>

          {assignmentHistory.length > 0 && (
            <div style={{ marginTop: '2.4rem' }}>
              <h3>Past Topic Assignments</h3>
              <div className="stack-sm">
                {assignmentHistory.map((item, idx) => (
                  <div
                    key={item.id}
                    className="history-item animate-stagger"
                    style={{ animationDelay: `${idx * 50}ms` }}
                  >
                    <div>
                      <strong>{item.title}</strong> — <span className="badge badge-indigo">{item.topicFilter}</span>
                      <div className="muted" style={{ fontSize: '0.82rem', marginTop: '0.2rem' }}>
                        {item.completedAt}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span>
                        <strong>{item.accuracyPercent}%</strong> ({item.correctCount}/{item.totalCount}) •{' '}
                        <span className={item.passed ? 'status-pass' : 'status-review'}>
                          {item.passed ? 'Passed' : 'Needs Review'}
                        </span>
                      </span>
                      {onGenerateCertificate && item.passed && (
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm"
                          onClick={() => onGenerateCertificate(item)}
                        >
                          <Award size={14} /> Certificate
                        </button>
                      )}
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={() => exportAttemptPdf(item)}
                      >
                        <Download size={14} /> PDF
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {stage === 'active' && currentQuestion && (
        <div key={currentQuestion.id} className="animate-question-swap">
          <div className="row-between" style={{ marginBottom: '0.85rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
              <strong>{title}</strong>
              <span className={`badge ${getTopicThemeClass(currentQuestion.topic)}`}>
                {currentQuestion.topic}
              </span>
              <span className={`badge ${getDifficultyThemeClass(currentQuestion.difficulty)}`}>
                {currentQuestion.difficulty}
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
              <MotionTimerRing secondsLeft={secondsLeft} totalSeconds={totalSeconds} />
              <button
                type="button"
                className={`btn btn-sm ${bookmarkedIds.includes(currentQuestion.id) ? 'btn-warn' : 'btn-secondary'}`}
                onClick={() => toggleBookmark(currentQuestion.id)}
              >
                <Bookmark size={14} />
                {bookmarkedIds.includes(currentQuestion.id) ? 'Flagged' : 'Flag'}
              </button>
            </div>
          </div>

          {/* Interactive Lifelines */}
          <InteractiveLifelines
            used5050={used5050}
            usedFreeze={usedFreeze}
            usedClue={usedClue}
            clueText={`Key subtopic: ${currentQuestion.subtopic}. Focus on foundational principles.`}
            showClue={showClue}
            onUse5050={handleUse5050}
            onUseFreeze={handleUseFreeze}
            onToggleClue={() => {
              setUsedClue(true);
              setShowClue(!showClue);
              if (onUnlockAchievement) onUnlockAchievement('lifeline_user');
            }}
          />

          {/* Combo Overdrive Meter */}
          <div style={{ margin: '0.85rem 0' }}>
            <ComboOverdriveBar streak={currentStreak} />
          </div>

          <div className="live-progress-bar">
            <div
              className="live-progress-fill"
              style={{ width: `${Math.round((answeredCount / Math.max(1, deck.length)) * 100)}%` }}
            />
          </div>

          <div className="pill-nav">
            {deck.map((q, i) => {
              const answered = selectedMap[q.id] !== undefined;
              const flagged = bookmarkedIds.includes(q.id);
              return (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => {
                    soundFX.playClick();
                    setCurrentIdx(i);
                  }}
                  className={`nav-pill ${i === currentIdx ? 'active' : ''} ${answered ? 'answered' : ''} ${flagged ? 'flagged' : ''}`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          <h3 className="question-heading">
            <span className="q-num">Q{currentIdx + 1}</span> {currentQuestion.question}
          </h3>

          <div className="stack-sm">
            {currentQuestion.options.map((opt, idx) => {
              const chosen = selectedMap[currentQuestion.id] === idx;
              const isEliminated = eliminatedOptions.has(idx);

              return (
                <button
                  key={opt}
                  type="button"
                  disabled={isEliminated}
                  onClick={(e) => handleSelectOption(idx, e)}
                  className={`option-btn animate-stagger ${chosen ? 'selected' : ''} ${isEliminated ? 'eliminated-opt' : ''}`}
                  style={{ animationDelay: `${idx * 45}ms` }}
                >
                  <span className="opt-key">{idx + 1}</span>
                  <span style={{ flexGrow: 1 }}>
                    {opt} {isEliminated && <span className="eliminated-tag">[Eliminated]</span>}
                  </span>
                  {chosen && <CheckCircle2 size={18} className="text-emerald" />}
                </button>
              );
            })}
          </div>

          <div className="row-between" style={{ marginTop: '1.4rem' }}>
            <button
              type="button"
              className="btn btn-secondary"
              disabled={currentIdx === 0}
              onClick={() => {
                soundFX.playClick();
                setCurrentIdx((i) => Math.max(0, i - 1));
              }}
            >
              Previous
            </button>

            <div style={{ display: 'flex', gap: '0.6rem' }}>
              {currentIdx + 1 < deck.length && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    soundFX.playClick();
                    setCurrentIdx((i) => Math.min(deck.length - 1, i + 1));
                  }}
                >
                  Next
                </button>
              )}
              <button type="button" className="btn btn-success" onClick={submitAssignment}>
                Submit Assignment
              </button>
            </div>
          </div>
        </div>
      )}

      {stage === 'report' && latestReport && (
        <div className="animate-fade-up">
          <div className={`report-hero ${latestReport.passed ? 'hero-pass' : 'hero-review'}`}>
            <div className="row-between">
              <div>
                <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Award size={22} /> {latestReport.title} — Evaluation Report
                </h3>
                <p style={{ margin: '0.4rem 0 0', opacity: 0.95 }}>
                  Topic: <strong>{latestReport.topicFilter}</strong> • Score: <strong>{latestReport.score} pts</strong> • Accuracy:{' '}
                  <strong>
                    {latestReport.correctCount}/{latestReport.totalCount} ({latestReport.accuracyPercent}%)
                  </strong>{' '}
                  • Status: <strong>{latestReport.passed ? 'PASSED' : 'NEEDS REVIEW'}</strong>
                </p>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {onGenerateCertificate && (
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => onGenerateCertificate(latestReport)}
                  >
                    <Award size={14} /> Official Certificate
                  </button>
                )}
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setOnlyFlagged((f) => !f)}
                >
                  {onlyFlagged ? 'Show All' : `Flagged (${latestReport.bookmarkedIds?.length || 0})`}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => exportAttemptPdf(latestReport)}
                >
                  <Download size={14} /> Export PDF
                </button>
                <button type="button" className="btn btn-primary btn-sm" onClick={startAssignment}>
                  <RotateCcw size={14} /> Retry
                </button>
              </div>
            </div>
          </div>

          <div className="stack-sm" style={{ marginTop: '1.1rem' }}>
            {latestReport.records
              .filter((r) => !onlyFlagged || latestReport.bookmarkedIds?.includes(r.questionId))
              .map((rec, i) => (
                <div
                  key={rec.questionId}
                  className={`review-card animate-stagger ${rec.isCorrect ? 'correct' : 'incorrect'}`}
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <div className="row-between">
                    <strong>
                      {i + 1}. {rec.question}
                    </strong>
                    {rec.isCorrect ? (
                      <CheckCircle2 size={19} color="#10b981" />
                    ) : (
                      <XCircle size={19} color="#f43f5e" />
                    )}
                  </div>
                  <p style={{ margin: '0.4rem 0 0.2rem', fontSize: '0.92rem' }}>
                    Your Answer:{' '}
                    <strong>{rec.selectedIndex !== null ? rec.options[rec.selectedIndex] : 'Unanswered'}</strong> | Correct:{' '}
                    <strong>{rec.options[rec.correctIndex]}</strong>
                  </p>
                  <p className="muted" style={{ margin: 0, fontSize: '0.88rem' }}>
                    {rec.explanation}
                  </p>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};
