// Interactive Gamified Achievement System for QuizQuake
import { readJson, writeJson } from './safeStorage';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'streak' | 'accuracy' | 'speed' | 'mastery' | 'xp';
  unlockedAt?: string;
}

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_blood',
    title: 'First Contact',
    description: 'Answer your first question correctly in any mode.',
    icon: '⚡',
    category: 'xp',
  },
  {
    id: 'streak_3',
    title: 'Hot Streak',
    description: 'Achieve a 3x consecutive answer streak.',
    icon: '🔥',
    category: 'streak',
  },
  {
    id: 'streak_5',
    title: 'Unstoppable Flow',
    description: 'Hit a 5x consecutive answer streak in Adaptive Arena.',
    icon: '☄️',
    category: 'streak',
  },
  {
    id: 'speed_demon',
    title: 'Lightning Reflexes',
    description: 'Answer a question correctly in under 5 seconds.',
    icon: '⏱️',
    category: 'speed',
  },
  {
    id: 'lifeline_user',
    title: 'Tactical Mind',
    description: 'Use a 50:50 or Time Freeze lifeline to survive.',
    icon: '🛡️',
    category: 'mastery',
  },
  {
    id: 'perfect_pass',
    title: 'Flawless Victory',
    description: 'Complete an assignment or arena run with 90%+ accuracy.',
    icon: '👑',
    category: 'accuracy',
  },
  {
    id: 'high_roller',
    title: 'Overdrive Master',
    description: 'Reach Level 3 (Byte Buster) or higher in XP progression.',
    icon: '🏆',
    category: 'xp',
  },
  {
    id: 'curator',
    title: 'Repository Architect',
    description: 'Add or import custom questions into the Question Bank.',
    icon: '💎',
    category: 'mastery',
  },
];

const STORAGE_KEY = 'quizquake_unlocked_achievements_v1';

export function loadUnlockedAchievements(): string[] {
  const data = readJson<unknown>(STORAGE_KEY, []);
  return Array.isArray(data) ? data.filter((x): x is string => typeof x === 'string') : [];
}

export function unlockAchievement(id: string): { newlyUnlocked: boolean; achievement: Achievement | null } {
  const current = loadUnlockedAchievements();
  if (current.includes(id)) {
    return { newlyUnlocked: false, achievement: null };
  }

  const updated = [...current, id];
  writeJson(STORAGE_KEY, updated);

  const achievement = INITIAL_ACHIEVEMENTS.find((a) => a.id === id) || null;
  return { newlyUnlocked: true, achievement };
}
