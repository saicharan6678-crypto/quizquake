// Lightweight structured logger for the client.
// Replaces silent `catch {}` blocks so runtime problems are always observable
// (browser console in dev, and an in-memory ring buffer that tests/UI can inspect).

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  level: LogLevel;
  scope: string;
  message: string;
  detail?: string;
  at: string;
}

const MAX_BUFFER = 100;
const buffer: LogEntry[] = [];

function describe(error: unknown): string | undefined {
  if (error === undefined || error === null) return undefined;
  if (error instanceof Error) return `${error.name}: ${error.message}`;
  return String(error);
}

function write(level: LogLevel, scope: string, message: string, error?: unknown): void {
  const entry: LogEntry = {
    level,
    scope,
    message,
    detail: describe(error),
    at: new Date().toISOString(),
  };
  buffer.push(entry);
  if (buffer.length > MAX_BUFFER) buffer.shift();

  const line = `[QuizQuake:${scope}] ${message}${entry.detail ? ` — ${entry.detail}` : ''}`;
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else if (level === 'info') console.info(line);
  else console.debug(line);
}

export const logger = {
  debug: (scope: string, message: string, error?: unknown) => write('debug', scope, message, error),
  info: (scope: string, message: string, error?: unknown) => write('info', scope, message, error),
  warn: (scope: string, message: string, error?: unknown) => write('warn', scope, message, error),
  error: (scope: string, message: string, error?: unknown) => write('error', scope, message, error),
  getRecent: (): readonly LogEntry[] => buffer.slice(),
  clear: (): void => {
    buffer.length = 0;
  },
};
