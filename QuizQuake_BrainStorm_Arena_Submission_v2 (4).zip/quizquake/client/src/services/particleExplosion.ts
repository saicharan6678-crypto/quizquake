// High-performance Canvas Particle & Confetti Engine for QuizQuake
// Lightweight, responsive, zero-dependency, 60 FPS physics
// Clean, sophisticated celebration palette (no jarring RGB effect)

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  rotation: number;
  vRot: number;
  shape: 'rect' | 'circle' | 'star';
  gravity: number;
}

class ParticleEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private particles: Particle[] = [];
  private animationId: number | null = null;

  // Clean, elegant celebration palette
  private colors = [
    '#f59e0b', // Gold / Amber
    '#fbbf24', // Warm Gold
    '#10b981', // Emerald
    '#6366f1', // Indigo
    '#e2e8f0', // Crisp White / Silver
  ];

  public init(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.resize();
    window.addEventListener('resize', this.handleResize);
  }

  public destroy() {
    window.removeEventListener('resize', this.handleResize);
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
    this.particles = [];
  }

  private handleResize = () => {
    this.resize();
  };

  private resize() {
    if (!this.canvas) return;
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  // Celebratory confetti burst from multiple origins
  public fireConfetti(count: number = 80) {
    if (!this.canvas) return;
    const origins = [
      { x: this.canvas.width * 0.25, y: this.canvas.height * 0.75 },
      { x: this.canvas.width * 0.5, y: this.canvas.height * 0.65 },
      { x: this.canvas.width * 0.75, y: this.canvas.height * 0.75 },
    ];

    origins.forEach((origin) => {
      for (let i = 0; i < count / origins.length; i++) {
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.5;
        const speed = 10 + Math.random() * 16;
        this.particles.push({
          x: origin.x,
          y: origin.y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 6 + Math.random() * 6,
          color: this.colors[Math.floor(Math.random() * this.colors.length)],
          alpha: 1,
          decay: 0.008 + Math.random() * 0.008,
          rotation: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 0.2,
          shape: Math.random() > 0.4 ? 'rect' : 'circle',
          gravity: 0.35,
        });
      }
    });

    this.startLoop();
  }

  // Localized starburst at button click coordinates
  public burstAt(x: number, y: number, isSuccess: boolean = true) {
    if (!this.canvas) return;
    const count = isSuccess ? 24 : 12;
    const palette = isSuccess
      ? ['#10b981', '#34d399', '#6366f1', '#f59e0b']
      : ['#ef4444', '#f87171'];

    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
      const speed = 3 + Math.random() * 8;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 3 + Math.random() * 4,
        color: palette[Math.floor(Math.random() * palette.length)],
        alpha: 1,
        decay: 0.025 + Math.random() * 0.02,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.25,
        shape: Math.random() > 0.5 ? 'circle' : 'star',
        gravity: 0.18,
      });
    }

    this.startLoop();
  }

  private startLoop() {
    if (!this.animationId) {
      this.loop();
    }
  }

  private loop = () => {
    if (!this.ctx || !this.canvas) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.gravity;
      p.vx *= 0.985;
      p.rotation += p.vRot;
      p.alpha -= p.decay;

      if (p.alpha <= 0 || p.y > this.canvas.height + 50) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.globalAlpha = Math.max(0, p.alpha);
      this.ctx.translate(p.x, p.y);
      this.ctx.rotate(p.rotation);
      this.ctx.fillStyle = p.color;

      if (p.shape === 'rect') {
        this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.65);
      } else if (p.shape === 'circle') {
        this.ctx.beginPath();
        this.ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
        this.ctx.fill();
      } else {
        // Draw miniature 4-point star
        this.ctx.beginPath();
        for (let j = 0; j < 4; j++) {
          this.ctx.rotate(Math.PI / 4);
          this.ctx.lineTo(p.size, 0);
          this.ctx.rotate(Math.PI / 4);
          this.ctx.lineTo(p.size * 0.35, 0);
        }
        this.ctx.closePath();
        this.ctx.fill();
      }

      this.ctx.restore();
    }

    if (this.particles.length > 0) {
      this.animationId = requestAnimationFrame(this.loop);
    } else {
      this.animationId = null;
    }
  };
}

export const particleEngine = new ParticleEngine();
