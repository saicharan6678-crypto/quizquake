// PDF export service — separated from generic utilities (single responsibility).

import { jsPDF } from 'jspdf';
import { AttemptSummary } from '../types';
import { logger } from './logger';

export function exportAttemptPdf(attempt: AttemptSummary): boolean {
  try {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('QuizQuake — BrainStorm Arena Report', 14, 18);

    doc.setFontSize(11);
    doc.text(`Title: ${attempt.title} (${attempt.mode.toUpperCase()})`, 14, 28);
    doc.text(`Topic: ${attempt.topicFilter} | Completed: ${attempt.completedAt}`, 14, 35);
    doc.text(
      `Score: ${attempt.score} pts | Accuracy: ${attempt.correctCount}/${attempt.totalCount} (${attempt.accuracyPercent}%) — ${attempt.passed ? 'PASSED' : 'NEEDS REVIEW'}`,
      14,
      42
    );

    let y = 54;
    attempt.records.forEach((rec, i) => {
      if (y > 265) {
        doc.addPage();
        y = 20;
      }
      const tag = rec.isCorrect ? '[CORRECT]' : '[INCORRECT]';
      const userAns = rec.selectedIndex !== null ? rec.options[rec.selectedIndex] : 'Unanswered';
      const rightAns = rec.options[rec.correctIndex];

      doc.setFontSize(10);
      const lines = doc.splitTextToSize(`${i + 1}. ${tag} (${rec.topic} - ${rec.difficulty}) ${rec.question}`, 180);
      doc.text(lines, 14, y);
      y += lines.length * 5;

      doc.text(`   Your Answer: ${userAns} | Correct: ${rightAns}`, 14, y);
      y += 8;
    });

    doc.save(`quizquake-${attempt.mode}-report.pdf`);
    return true;
  } catch (err) {
    logger.error('pdf', 'Failed to export attempt report', err);
    return false;
  }
}
