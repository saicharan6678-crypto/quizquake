// Safe wrapper around localStorage. Storage can throw (private mode, quota exceeded,
// disabled cookies), so every access is guarded AND reported via the logger instead of
// being silently swallowed.

import { logger } from './logger';

export function readItem(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch (err) {
    logger.warn('storage', `Could not read "${key}"`, err);
    return null;
  }
}

export function writeItem(key: string, value: string): boolean {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch (err) {
    logger.warn('storage', `Could not write "${key}" (quota or access denied)`, err);
    return false;
  }
}

export function readJson<T>(key: string, fallback: T): T {
  const raw = readItem(key);
  if (raw === null) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch (err) {
    logger.warn('storage', `Corrupted JSON in "${key}", using fallback`, err);
    return fallback;
  }
}

export function writeJson(key: string, value: unknown): boolean {
  try {
    return writeItem(key, JSON.stringify(value));
  } catch (err) {
    logger.warn('storage', `Could not serialise value for "${key}"`, err);
    return false;
  }
}
