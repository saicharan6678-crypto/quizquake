// Gamified XP, Rank and Level Progression System for QuizQuake
import { readItem, writeItem } from './safeStorage';

export interface PlayerStats {
  xp: number;
  level: number;
  title: string;
  currentLevelXp: number;
  nextLevelXp: number;
  progressPercent: number;
}

const RANKS = [
  { minXp: 0, level: 1, title: 'Script Novice' },
  { minXp: 300, level: 2, title: 'Code Sprinter' },
  { minXp: 800, level: 3, title: 'Byte Buster' },
  { minXp: 1500, level: 4, title: 'Algorithm Ace' },
  { minXp: 2500, level: 5, title: 'Kernel Knight' },
  { minXp: 4000, level: 6, title: 'Cyber Architect' },
  { minXp: 6000, level: 7, title: 'Quantum Grandmaster' },
  { minXp: 8500, level: 8, title: 'Legendary AI Overlord' },
];

export const XP_STORAGE_KEY = 'quizquake_player_xp_v1';

export function getPlayerXp(): number {
  const raw = readItem(XP_STORAGE_KEY);
  return raw ? parseInt(raw, 10) || 0 : 0;
}

export function calculatePlayerStats(totalXp: number): PlayerStats {
  let currentRank = RANKS[0];
  let nextRank = RANKS[1];

  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (totalXp >= RANKS[i].minXp) {
      currentRank = RANKS[i];
      nextRank = RANKS[i + 1] || { minXp: currentRank.minXp + 3000, level: currentRank.level + 1, title: currentRank.title };
      break;
    }
  }

  const range = nextRank.minXp - currentRank.minXp;
  const progressInLevel = Math.max(0, totalXp - currentRank.minXp);
  const progressPercent = Math.min(100, Math.round((progressInLevel / range) * 100));

  return {
    xp: totalXp,
    level: currentRank.level,
    title: currentRank.title,
    currentLevelXp: progressInLevel,
    nextLevelXp: range,
    progressPercent,
  };
}

export function awardXp(amount: number): { newTotal: number; leveledUp: boolean; stats: PlayerStats } {
  const prevXp = getPlayerXp();
  const prevStats = calculatePlayerStats(prevXp);
  const newTotal = prevXp + Math.max(0, amount);

  writeItem(XP_STORAGE_KEY, String(newTotal));

  const stats = calculatePlayerStats(newTotal);
  const leveledUp = stats.level > prevStats.level;

  return {
    newTotal,
    leveledUp,
    stats,
  };
}
