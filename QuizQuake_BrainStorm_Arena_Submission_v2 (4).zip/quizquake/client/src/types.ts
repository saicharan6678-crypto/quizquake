export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface Question {
  id: string;
  topic: string;
  subtopic: string;
  difficulty: Difficulty;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizAnswerRecord {
  questionId: string;
  topic: string;
  subtopic: string;
  difficulty: Difficulty;
  question: string;
  options: string[];
  selectedIndex: number | null;
  correctIndex: number;
  isCorrect: boolean;
  explanation: string;
  timeSpentSec: number;
}

export interface AttemptSummary {
  id: string;
  mode: 'adaptive' | 'assignment';
  title: string;
  topicFilter: string;
  completedAt: string;
  score: number;
  correctCount: number;
  totalCount: number;
  accuracyPercent: number;
  passed: boolean;
  bestStreak: number;
  bookmarkedIds?: string[];
  records: QuizAnswerRecord[];
}
