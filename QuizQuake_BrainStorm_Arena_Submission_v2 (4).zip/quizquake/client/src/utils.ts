import { readJson, writeJson } from './services/safeStorage';
import { AttemptSummary, Difficulty, Question } from './types';

export const HISTORY_STORAGE_KEY = 'quizquake_attempt_history_v1';

export function loadAttemptHistory(): AttemptSummary[] {
  const data = readJson<unknown>(HISTORY_STORAGE_KEY, []);
  return Array.isArray(data) ? (data as AttemptSummary[]) : [];
}

export function saveAttempt(attempt: AttemptSummary): AttemptSummary[] {
  const updated = [attempt, ...loadAttemptHistory()].slice(0, 20);
  writeJson(HISTORY_STORAGE_KEY, updated);
  return updated;
}

export function nextDifficulty(
  current: Difficulty,
  consecutiveCorrect: number,
  wasCorrect: boolean
): Difficulty {
  if (!wasCorrect) {
    if (current === 'Hard') return 'Medium';
    return 'Easy';
  }
  if (consecutiveCorrect >= 2) {
    if (current === 'Easy') return 'Medium';
    return 'Hard';
  }
  return current;
}

export function pickNextAdaptiveQuestion(
  all: Question[],
  usedIds: Set<string>,
  targetDifficulty: Difficulty,
  preferredTopic?: string
): Question | null {
  const unused = all.filter((q) => !usedIds.has(q.id));
  if (unused.length === 0) return null;

  const exact = unused.filter(
    (q) => q.difficulty === targetDifficulty && (!preferredTopic || q.topic === preferredTopic)
  );
  if (exact.length > 0) return exact[Math.floor(Math.random() * exact.length)];

  const diffOnly = unused.filter((q) => q.difficulty === targetDifficulty);
  if (diffOnly.length > 0) return diffOnly[Math.floor(Math.random() * diffOnly.length)];

  return unused[Math.floor(Math.random() * unused.length)];
}

export function getTopicThemeClass(topic: string): string {
  const t = topic.toLowerCase();
  // Word-aware matching: a bare includes('data') / includes('os') would misclassify
  // custom topics such as "Databases" or "Protocols".
  if (/\bdata\s*structures?\b|\bds\b/.test(t)) return 'topic-ds';
  if (t.includes('algo')) return 'topic-algo';
  if (/\boperating\b|\bos\b/.test(t)) return 'topic-os';
  if (t.includes('network')) return 'topic-net';
  return 'topic-custom';
}

export function getDifficultyThemeClass(diff: Difficulty): string {
  if (diff === 'Easy') return 'diff-easy';
  if (diff === 'Medium') return 'diff-medium';
  return 'diff-hard';
}
