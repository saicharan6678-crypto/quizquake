// Runtime validation for data that crosses a trust boundary on the client
// (localStorage, imported JSON files, server responses). TypeScript types alone
// are erased at runtime, so untrusted data must be checked explicitly.

import { AttemptSummary, Difficulty, Question } from './types';

const DIFFICULTIES: readonly Difficulty[] = ['Easy', 'Medium', 'Hard'];

function isNonEmptyString(v: unknown, max = 2000): v is string {
  return typeof v === 'string' && v.trim().length > 0 && v.length <= max;
}

export function isValidQuestion(value: unknown): value is Question {
  if (typeof value !== 'object' || value === null) return false;
  const q = value as Record<string, unknown>;
  return (
    isNonEmptyString(q.id, 100) &&
    isNonEmptyString(q.topic, 100) &&
    isNonEmptyString(q.subtopic, 100) &&
    DIFFICULTIES.includes(q.difficulty as Difficulty) &&
    isNonEmptyString(q.question) &&
    Array.isArray(q.options) &&
    q.options.length >= 2 &&
    q.options.length <= 6 &&
    q.options.every((o) => isNonEmptyString(o, 500)) &&
    Number.isInteger(q.correctIndex) &&
    (q.correctIndex as number) >= 0 &&
    (q.correctIndex as number) < q.options.length &&
    typeof q.explanation === 'string'
  );
}

export interface QuestionValidationResult {
  valid: Question[];
  rejected: number;
}

export function partitionQuestions(values: unknown): QuestionValidationResult {
  if (!Array.isArray(values)) return { valid: [], rejected: 0 };
  const valid: Question[] = [];
  let rejected = 0;
  const seen = new Set<string>();
  for (const v of values) {
    if (isValidQuestion(v) && !seen.has(v.id)) {
      seen.add(v.id);
      valid.push(v);
    } else {
      rejected += 1;
    }
  }
  return { valid, rejected };
}

export function isValidAttempt(value: unknown): value is AttemptSummary {
  if (typeof value !== 'object' || value === null) return false;
  const a = value as Record<string, unknown>;
  return (
    isNonEmptyString(a.id, 100) &&
    (a.mode === 'adaptive' || a.mode === 'assignment') &&
    typeof a.title === 'string' &&
    typeof a.topicFilter === 'string' &&
    typeof a.completedAt === 'string' &&
    typeof a.score === 'number' &&
    typeof a.correctCount === 'number' &&
    typeof a.totalCount === 'number' &&
    typeof a.accuracyPercent === 'number' &&
    typeof a.passed === 'boolean' &&
    Array.isArray(a.records)
  );
}
