import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/__tests__/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      include: ['src/utils.ts', 'src/api.ts', 'src/validation.ts', 'src/services/**/*.ts'],
      exclude: ['src/services/soundFX.ts', 'src/services/particleExplosion.ts', 'src/services/pdfExport.ts'],
    },
  },
});
