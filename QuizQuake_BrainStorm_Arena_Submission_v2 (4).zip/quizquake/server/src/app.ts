import cors from 'cors';
import express from 'express';
import type { Express } from 'express';
import rateLimit from 'express-rate-limit';
import fs from 'fs';
import helmet from 'helmet';
import path from 'path';
import type { AppConfig } from './config';
import type { Logger } from './logger';
import { apiNotFound, createErrorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import type { AttemptRepository } from './repositories/attemptRepository';
import type { QuestionRepository } from './repositories/questionRepository';
import { attemptRoutes } from './routes/attempts';
import { healthRoutes } from './routes/health';
import { questionRoutes } from './routes/questions';

export interface AppDependencies {
  config: AppConfig;
  logger: Logger;
  questions: QuestionRepository;
  attempts: AttemptRepository;
}

/** Builds the Express app. Kept separate from `listen()` so tests can run it in-process. */
export function createApp({ config, logger, questions, attempts }: AppDependencies): Express {
  const app = express();
  app.disable('x-powered-by');

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
          imgSrc: ["'self'", 'data:', 'blob:'],
          connectSrc: ["'self'"],
        },
      },
    })
  );

  app.use(
    cors({
      origin(origin, callback) {
        // Same-origin / curl requests have no Origin header; browsers must be on the allow-list.
        if (!origin || config.corsOrigins.includes(origin)) return callback(null, true);
        callback(null, false);
      },
      methods: ['GET', 'POST', 'DELETE'],
    })
  );

  app.use(requestLogger(logger));
  app.use(express.json({ limit: '1mb' }));

  const limiterOptions = { windowMs: 60_000, standardHeaders: 'draft-7' as const, legacyHeaders: false };
  const apiLimiter = rateLimit({ ...limiterOptions, limit: config.rateLimitMax });
  const writeLimiter = rateLimit({ ...limiterOptions, limit: config.writeRateLimitMax });

  const api = express.Router();
  api.use(healthRoutes(questions, attempts));
  api.use(questionRoutes(questions, writeLimiter));
  api.use(attemptRoutes(attempts, writeLimiter));
  api.use(apiNotFound);
  app.use('/api', apiLimiter, api);

  if (fs.existsSync(config.clientDist)) {
    app.use(express.static(config.clientDist));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(config.clientDist, 'index.html'));
    });
  }

  app.use(createErrorHandler(logger));
  return app;
}
