import path from 'path';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'silent';

export interface AppConfig {
  port: number;
  dbPath: string;
  seedPath: string;
  clientDist: string;
  corsOrigins: string[];
  logLevel: LogLevel;
  /** Max API requests per IP per minute. */
  rateLimitMax: number;
  /** Max write (POST/DELETE) requests per IP per minute. */
  writeRateLimitMax: number;
  isProduction: boolean;
}

const LOG_LEVELS: readonly LogLevel[] = ['debug', 'info', 'warn', 'error', 'silent'];

function readInt(name: string, raw: string | undefined, fallback: number, min: number, max: number): number {
  if (raw === undefined || raw.trim() === '') return fallback;
  const value = Number(raw);
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new Error(`Invalid ${name}="${raw}": expected an integer between ${min} and ${max}`);
  }
  return value;
}

/** Builds a validated configuration object from environment variables. */
export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const dataDir = path.join(__dirname, '..', 'data');
  const logLevel = (env.LOG_LEVEL ?? 'info') as LogLevel;
  if (!LOG_LEVELS.includes(logLevel)) {
    throw new Error(`Invalid LOG_LEVEL="${env.LOG_LEVEL}": expected one of ${LOG_LEVELS.join(', ')}`);
  }

  return {
    port: readInt('PORT', env.PORT, 4000, 1, 65535),
    dbPath: env.DB_PATH ?? path.join(dataDir, 'quizquake.db'),
    seedPath: env.SEED_PATH ?? path.join(dataDir, 'questions.json'),
    clientDist: path.join(__dirname, '..', '..', 'client', 'dist'),
    corsOrigins: (env.CORS_ORIGINS ?? 'http://localhost:5173,http://127.0.0.1:5173')
      .split(',')
      .map((o) => o.trim())
      .filter(Boolean),
    logLevel,
    rateLimitMax: readInt('RATE_LIMIT_MAX', env.RATE_LIMIT_MAX, 300, 1, 100000),
    writeRateLimitMax: readInt('WRITE_RATE_LIMIT_MAX', env.WRITE_RATE_LIMIT_MAX, 60, 1, 100000),
    isProduction: env.NODE_ENV === 'production',
  };
}
