import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import type { Logger } from '../logger';
import { serializeError } from '../logger';
import { questionSchema } from '../validation/schemas';
import { QuestionRepository } from '../repositories/questionRepository';

export type Db = Database.Database;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS questions (
  id            TEXT PRIMARY KEY,
  topic         TEXT NOT NULL,
  subtopic      TEXT NOT NULL,
  difficulty    TEXT NOT NULL CHECK (difficulty IN ('Easy','Medium','Hard')),
  question      TEXT NOT NULL,
  options       TEXT NOT NULL,
  correct_index INTEGER NOT NULL CHECK (correct_index >= 0),
  explanation   TEXT NOT NULL DEFAULT '',
  source        TEXT NOT NULL DEFAULT 'custom' CHECK (source IN ('seed','custom')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_questions_topic_difficulty ON questions (topic, difficulty);

CREATE TABLE IF NOT EXISTS attempts (
  id               TEXT PRIMARY KEY,
  mode             TEXT NOT NULL CHECK (mode IN ('adaptive','assignment')),
  title            TEXT NOT NULL,
  topic_filter     TEXT NOT NULL,
  completed_at     TEXT NOT NULL,
  score            REAL NOT NULL,
  correct_count    INTEGER NOT NULL,
  total_count      INTEGER NOT NULL,
  accuracy_percent REAL NOT NULL,
  passed           INTEGER NOT NULL CHECK (passed IN (0,1)),
  best_streak      INTEGER NOT NULL DEFAULT 0,
  payload          TEXT NOT NULL,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_attempts_created ON attempts (created_at DESC);
`;

/** Opens (and creates, if needed) the SQLite database and applies the schema. */
export function openDatabase(dbPath: string): Db {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new Database(dbPath);
  // WAL lets readers and a writer work concurrently; foreign keys/busy timeout add safety.
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  db.exec(SCHEMA);
  return db;
}

/** Imports the bundled JSON question set into an empty database (idempotent). */
export function seedIfEmpty(repo: QuestionRepository, seedPath: string, logger: Logger): number {
  if (repo.count() > 0) return 0;

  let raw: unknown;
  try {
    raw = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));
  } catch (err) {
    logger.error('Seed file could not be read; starting with an empty question bank', { seedPath, ...serializeError(err) });
    return 0;
  }
  if (!Array.isArray(raw)) {
    logger.error('Seed file must contain a JSON array', { seedPath });
    return 0;
  }

  const valid = [];
  let skipped = 0;
  for (const item of raw) {
    const parsed = questionSchema.safeParse(item);
    if (parsed.success) valid.push(parsed.data);
    else skipped += 1;
  }
  if (skipped > 0) logger.warn('Some seed questions failed validation and were skipped', { skipped });

  repo.upsertMany(valid, 'seed');
  logger.info('Seeded question bank', { inserted: valid.length });
  return valid.length;
}
