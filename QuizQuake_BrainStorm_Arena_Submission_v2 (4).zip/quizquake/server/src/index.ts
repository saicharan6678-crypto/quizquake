import { createApp } from './app';
import { loadConfig } from './config';
import { openDatabase, seedIfEmpty } from './db/database';
import { createLogger, serializeError } from './logger';
import { AttemptRepository } from './repositories/attemptRepository';
import { QuestionRepository } from './repositories/questionRepository';

function main(): void {
  const config = loadConfig();
  const logger = createLogger(config.logLevel);

  const db = openDatabase(config.dbPath);
  const questions = new QuestionRepository(db);
  const attempts = new AttemptRepository(db);
  seedIfEmpty(questions, config.seedPath, logger);

  const app = createApp({ config, logger, questions, attempts });
  const server = app.listen(config.port, () => {
    logger.info(`QuizQuake server listening on http://localhost:${config.port}`, { db: config.dbPath });
  });

  server.on('error', (err) => {
    logger.error('Server failed to start', serializeError(err));
    db.close();
    process.exit(1);
  });

  const shutdown = (signal: string) => {
    logger.info('Shutting down', { signal });
    server.close(() => {
      db.close();
      process.exit(0);
    });
    // Force-exit if connections refuse to close.
    setTimeout(() => process.exit(1), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

try {
  main();
} catch (err) {
  console.error(JSON.stringify({ level: 'error', msg: 'Fatal startup error', ...serializeError(err) }));
  process.exit(1);
}
