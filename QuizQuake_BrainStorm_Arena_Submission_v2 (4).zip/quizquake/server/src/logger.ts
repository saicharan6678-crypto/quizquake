// Structured (JSON-lines) logger. One object per line makes logs easy to grep,
// ship to a log aggregator, and correlate by request id.

import type { LogLevel } from './config';

const ORDER: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 };

export type LogMeta = Record<string, unknown>;

export interface Logger {
  debug(msg: string, meta?: LogMeta): void;
  info(msg: string, meta?: LogMeta): void;
  warn(msg: string, meta?: LogMeta): void;
  error(msg: string, meta?: LogMeta): void;
  child(bindings: LogMeta): Logger;
}

export function serializeError(err: unknown): LogMeta {
  if (err instanceof Error) return { errorName: err.name, errorMessage: err.message, stack: err.stack };
  return { errorMessage: String(err) };
}

export function createLogger(level: LogLevel = 'info', bindings: LogMeta = {}, sink: (line: string) => void = console.log): Logger {
  const threshold = ORDER[level];
  const emit = (lvl: Exclude<LogLevel, 'silent'>, msg: string, meta?: LogMeta) => {
    if (ORDER[lvl] < threshold) return;
    sink(JSON.stringify({ ts: new Date().toISOString(), level: lvl, msg, ...bindings, ...meta }));
  };
  return {
    debug: (m, meta) => emit('debug', m, meta),
    info: (m, meta) => emit('info', m, meta),
    warn: (m, meta) => emit('warn', m, meta),
    error: (m, meta) => emit('error', m, meta),
    child: (extra) => createLogger(level, { ...bindings, ...extra }, sink),
  };
}
