import type { ErrorRequestHandler, RequestHandler } from 'express';
import type { Logger } from '../logger';
import { serializeError } from '../logger';
import { HttpError } from '../errors';

export const apiNotFound: RequestHandler = (req, res) => {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: `No route for ${req.method} ${req.path}` } });
};

interface BodyParserError extends Error {
  status?: number;
  type?: string;
}

/** Central error handler: consistent JSON envelope, no stack traces leaked to clients. */
export function createErrorHandler(logger: Logger): ErrorRequestHandler {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  return (err, req, res, _next) => {
    if (err instanceof HttpError) {
      res.status(err.status).json({ error: { code: err.code, message: err.message, details: err.details } });
      return;
    }

    const parserErr = err as BodyParserError;
    if (parserErr.type === 'entity.parse.failed') {
      res.status(400).json({ error: { code: 'INVALID_JSON', message: 'Request body is not valid JSON' } });
      return;
    }
    if (parserErr.type === 'entity.too.large') {
      res.status(413).json({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Request body is too large' } });
      return;
    }

    logger.error('Unhandled error', { method: req.method, path: req.path, ...serializeError(err) });
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Something went wrong on the server' } });
  };
}
