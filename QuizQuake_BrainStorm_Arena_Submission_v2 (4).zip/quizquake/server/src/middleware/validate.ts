import type { NextFunction, Request, RequestHandler, Response } from 'express';
import type { ZodTypeAny, z } from 'zod';
import { badRequest } from '../errors';

type Source = 'body' | 'query' | 'params';

/**
 * Validates one part of the request against a Zod schema.
 * The parsed (and coerced / stripped) value is stored on `res.locals[source]` so handlers
 * only ever see data that passed validation.
 */
export function validate(source: Source, schema: ZodTypeAny): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      const details = result.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
      return next(badRequest('Request validation failed', details));
    }
    res.locals[source] = result.data;
    next();
  };
}

export function validated<T extends ZodTypeAny>(res: Response, source: Source): z.infer<T> {
  return res.locals[source] as z.infer<T>;
}
