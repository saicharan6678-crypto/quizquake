import type { Db } from '../db/database';
import type { AttemptInput } from '../validation/schemas';

interface AttemptRow {
  id: string;
  mode: 'adaptive' | 'assignment';
  title: string;
  topic_filter: string;
  completed_at: string;
  score: number;
  correct_count: number;
  total_count: number;
  accuracy_percent: number;
  passed: number;
  best_streak: number;
  payload: string;
}

export interface TopicStat {
  topic: string;
  attempts: number;
  averageAccuracy: number;
  bestScore: number;
}

function toAttempt(row: AttemptRow): AttemptInput {
  const payload = JSON.parse(row.payload) as Pick<AttemptInput, 'records' | 'bookmarkedIds'>;
  return {
    id: row.id,
    mode: row.mode,
    title: row.title,
    topicFilter: row.topic_filter,
    completedAt: row.completed_at,
    score: row.score,
    correctCount: row.correct_count,
    totalCount: row.total_count,
    accuracyPercent: row.accuracy_percent,
    passed: row.passed === 1,
    bestStreak: row.best_streak,
    bookmarkedIds: payload.bookmarkedIds,
    records: payload.records,
  };
}

export class AttemptRepository {
  constructor(private readonly db: Db) {}

  save(a: AttemptInput): void {
    this.db
      .prepare(
        `INSERT OR REPLACE INTO attempts
           (id, mode, title, topic_filter, completed_at, score, correct_count, total_count, accuracy_percent, passed, best_streak, payload)
         VALUES (@id, @mode, @title, @topicFilter, @completedAt, @score, @correctCount, @totalCount, @accuracyPercent, @passed, @bestStreak, @payload)`
      )
      .run({
        id: a.id,
        mode: a.mode,
        title: a.title,
        topicFilter: a.topicFilter,
        completedAt: a.completedAt,
        score: a.score,
        correctCount: a.correctCount,
        totalCount: a.totalCount,
        accuracyPercent: a.accuracyPercent,
        passed: a.passed ? 1 : 0,
        bestStreak: a.bestStreak,
        payload: JSON.stringify({ records: a.records, bookmarkedIds: a.bookmarkedIds }),
      });
  }

  recent(limit = 20): AttemptInput[] {
    const rows = this.db
      .prepare('SELECT * FROM attempts ORDER BY created_at DESC, rowid DESC LIMIT ?')
      .all(limit) as AttemptRow[];
    return rows.map(toAttempt);
  }

  count(): number {
    return (this.db.prepare('SELECT COUNT(*) AS n FROM attempts').get() as { n: number }).n;
  }

  /** Aggregated performance per topic filter — powers the analytics endpoint. */
  topicStats(): TopicStat[] {
    const rows = this.db
      .prepare(
        `SELECT topic_filter AS topic, COUNT(*) AS attempts,
                ROUND(AVG(accuracy_percent), 1) AS averageAccuracy, MAX(score) AS bestScore
         FROM attempts GROUP BY topic_filter ORDER BY attempts DESC, topic_filter ASC`
      )
      .all() as TopicStat[];
    return rows;
  }
}
