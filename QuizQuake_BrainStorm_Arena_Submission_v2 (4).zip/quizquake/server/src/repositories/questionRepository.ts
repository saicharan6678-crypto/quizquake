import type { Db } from '../db/database';
import type { QuestionInput, QuestionQuery } from '../validation/schemas';

export type QuestionSource = 'seed' | 'custom';

export interface StoredQuestion extends QuestionInput {
  source: QuestionSource;
}

interface QuestionRow {
  id: string;
  topic: string;
  subtopic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  options: string;
  correct_index: number;
  explanation: string;
  source: QuestionSource;
}

export type QuestionFilter = Pick<QuestionQuery, 'topic' | 'difficulty'>;

function toQuestion(row: QuestionRow): StoredQuestion {
  return {
    id: row.id,
    topic: row.topic,
    subtopic: row.subtopic,
    difficulty: row.difficulty,
    question: row.question,
    options: JSON.parse(row.options) as string[],
    correctIndex: row.correct_index,
    explanation: row.explanation,
    source: row.source,
  };
}

/** Data-access layer for questions. Uses prepared, parameterised statements only (no SQL injection). */
export class QuestionRepository {
  constructor(private readonly db: Db) {}

  private where(filter: QuestionFilter): { clause: string; params: string[] } {
    const parts: string[] = [];
    const params: string[] = [];
    if (filter.topic) {
      parts.push('topic = ?');
      params.push(filter.topic);
    }
    if (filter.difficulty) {
      parts.push('difficulty = ?');
      params.push(filter.difficulty);
    }
    return { clause: parts.length ? `WHERE ${parts.join(' AND ')}` : '', params };
  }

  list(filter: QuestionFilter, limit = 1000, offset = 0): StoredQuestion[] {
    const { clause, params } = this.where(filter);
    const rows = this.db
      .prepare(`SELECT * FROM questions ${clause} ORDER BY rowid ASC LIMIT ? OFFSET ?`)
      .all(...params, limit, offset) as QuestionRow[];
    return rows.map(toQuestion);
  }

  count(filter: QuestionFilter = {}): number {
    const { clause, params } = this.where(filter);
    const row = this.db.prepare(`SELECT COUNT(*) AS n FROM questions ${clause}`).get(...params) as { n: number };
    return row.n;
  }

  topics(): string[] {
    const rows = this.db.prepare('SELECT DISTINCT topic FROM questions ORDER BY topic ASC').all() as { topic: string }[];
    return rows.map((r) => r.topic);
  }

  getById(id: string): StoredQuestion | null {
    const row = this.db.prepare('SELECT * FROM questions WHERE id = ?').get(id) as QuestionRow | undefined;
    return row ? toQuestion(row) : null;
  }

  upsert(q: QuestionInput, source: QuestionSource = 'custom'): void {
    // A built-in question can never be overwritten by a custom upload that reuses its id.
    this.db
      .prepare(
        `INSERT INTO questions (id, topic, subtopic, difficulty, question, options, correct_index, explanation, source)
         VALUES (@id, @topic, @subtopic, @difficulty, @question, @options, @correctIndex, @explanation, @source)
         ON CONFLICT(id) DO UPDATE SET
           topic = excluded.topic, subtopic = excluded.subtopic, difficulty = excluded.difficulty,
           question = excluded.question, options = excluded.options, correct_index = excluded.correct_index,
           explanation = excluded.explanation
         WHERE questions.source = 'custom'`
      )
      .run({
        id: q.id,
        topic: q.topic,
        subtopic: q.subtopic,
        difficulty: q.difficulty,
        question: q.question,
        options: JSON.stringify(q.options),
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        source,
      });
  }

  /** Inserts many questions atomically: either all succeed or none do. */
  upsertMany(items: QuestionInput[], source: QuestionSource = 'custom'): void {
    const run = this.db.transaction((batch: QuestionInput[]) => {
      for (const q of batch) this.upsert(q, source);
    });
    run(items);
  }

  /** Removes a custom question. Returns 'deleted', 'not_found' or 'protected' (built-in). */
  delete(id: string): 'deleted' | 'not_found' | 'protected' {
    const existing = this.getById(id);
    if (!existing) return 'not_found';
    if (existing.source === 'seed') return 'protected';
    this.db.prepare('DELETE FROM questions WHERE id = ?').run(id);
    return 'deleted';
  }
}
