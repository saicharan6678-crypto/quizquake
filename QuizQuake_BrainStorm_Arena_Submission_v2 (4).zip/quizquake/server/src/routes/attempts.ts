import { Router } from 'express';
import type { RequestHandler } from 'express';
import type { AttemptRepository } from '../repositories/attemptRepository';
import { validate, validated } from '../middleware/validate';
import { attemptQuerySchema, attemptSchema, type AttemptInput } from '../validation/schemas';

export function attemptRoutes(repo: AttemptRepository, writeLimiter: RequestHandler): Router {
  const router = Router();

  router.get('/attempts', validate('query', attemptQuerySchema), (_req, res) => {
    const { limit } = validated<typeof attemptQuerySchema>(res, 'query') as { limit: number };
    res.json({ attempts: repo.recent(limit) });
  });

  router.post('/attempts', writeLimiter, validate('body', attemptSchema), (_req, res) => {
    const attempt = validated<typeof attemptSchema>(res, 'body') as AttemptInput;
    repo.save(attempt);
    res.status(201).json({ saved: true, id: attempt.id });
  });

  router.get('/stats', (_req, res) => {
    res.json({ totalAttempts: repo.count(), topics: repo.topicStats() });
  });

  return router;
}
