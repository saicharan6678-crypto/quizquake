import { Router } from 'express';
import type { AttemptRepository } from '../repositories/attemptRepository';
import type { QuestionRepository } from '../repositories/questionRepository';

export function healthRoutes(questions: QuestionRepository, attempts: AttemptRepository): Router {
  const router = Router();

  router.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptimeSec: Math.round(process.uptime()),
      database: { questions: questions.count(), attempts: attempts.count() },
    });
  });

  return router;
}
