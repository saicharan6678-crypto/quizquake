import { Router } from 'express';
import type { RequestHandler } from 'express';
import type { QuestionRepository } from '../repositories/questionRepository';
import { conflict, forbidden, notFound } from '../errors';
import { validate, validated } from '../middleware/validate';
import {
  idParamSchema,
  questionBatchSchema,
  questionQuerySchema,
  questionSchema,
  type QuestionInput,
  type QuestionQuery,
} from '../validation/schemas';

export function questionRoutes(repo: QuestionRepository, writeLimiter: RequestHandler): Router {
  const router = Router();

  router.get('/topics', (_req, res) => {
    res.json({ topics: repo.topics() });
  });

  router.get('/questions', validate('query', questionQuerySchema), (_req, res) => {
    const { topic, difficulty, limit, offset } = validated<typeof questionQuerySchema>(res, 'query') as QuestionQuery;
    const filter = { topic, difficulty };
    res.json({
      questions: repo.list(filter, limit, offset).map(({ source: _source, ...q }) => q),
      total: repo.count(filter),
      limit,
      offset,
    });
  });

  router.post('/questions', writeLimiter, validate('body', questionSchema), (_req, res) => {
    const q = validated<typeof questionSchema>(res, 'body') as QuestionInput;
    const existing = repo.getById(q.id);
    if (existing?.source === 'seed') throw conflict(`"${q.id}" is a built-in question and cannot be overwritten`);
    repo.upsert(q, 'custom');
    res.status(existing ? 200 : 201).json({ question: q });
  });

  router.post('/questions/bulk', writeLimiter, validate('body', questionBatchSchema), (_req, res) => {
    const { questions } = validated<typeof questionBatchSchema>(res, 'body') as { questions: QuestionInput[] };
    const clash = questions.find((q) => repo.getById(q.id)?.source === 'seed');
    if (clash) throw conflict(`"${clash.id}" is a built-in question and cannot be overwritten`);
    repo.upsertMany(questions, 'custom');
    res.status(201).json({ imported: questions.length });
  });

  router.delete('/questions/:id', writeLimiter, validate('params', idParamSchema), (_req, res) => {
    const { id } = validated<typeof idParamSchema>(res, 'params') as { id: string };
    const outcome = repo.delete(id);
    if (outcome === 'not_found') throw notFound(`Question "${id}" does not exist`);
    if (outcome === 'protected') throw forbidden('Built-in questions cannot be deleted');
    res.json({ deleted: true });
  });

  return router;
}
