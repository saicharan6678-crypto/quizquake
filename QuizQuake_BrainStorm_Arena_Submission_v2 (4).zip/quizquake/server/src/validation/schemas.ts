// Zod schemas: the single source of truth for every payload the API accepts.
// Anything that does not match is rejected with HTTP 400 before it reaches business logic.

import { z } from 'zod';

export const DIFFICULTIES = ['Easy', 'Medium', 'Hard'] as const;

const shortText = z.string().trim().min(1).max(100);

export const questionSchema = z
  .object({
    id: z
      .string()
      .trim()
      .min(1)
      .max(100)
      .regex(/^[A-Za-z0-9_.-]+$/, 'id may only contain letters, digits, "_", "-" and "."'),
    topic: shortText,
    subtopic: shortText,
    difficulty: z.enum(DIFFICULTIES),
    question: z.string().trim().min(1).max(2000),
    options: z.array(z.string().trim().min(1).max(500)).min(2).max(6),
    correctIndex: z.number().int().min(0),
    explanation: z.string().trim().max(3000).default(''),
  })
  .superRefine((q, ctx) => {
    if (q.correctIndex >= q.options.length) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['correctIndex'],
        message: 'correctIndex must point at one of the options',
      });
    }
  });

export const questionBatchSchema = z.object({ questions: z.array(questionSchema).min(1).max(500) });

const optionalFilter = z
  .string()
  .trim()
  .max(100)
  .optional()
  .transform((v) => (v === undefined || v === '' || v === 'All' ? undefined : v));

export const questionQuerySchema = z.object({
  topic: optionalFilter,
  difficulty: optionalFilter.refine((v) => v === undefined || (DIFFICULTIES as readonly string[]).includes(v), {
    message: 'difficulty must be Easy, Medium or Hard',
  }),
  limit: z.coerce.number().int().min(1).max(1000).default(1000),
  offset: z.coerce.number().int().min(0).default(0),
});

export const idParamSchema = z.object({
  id: z.string().trim().min(1).max(100).regex(/^[A-Za-z0-9_.-]+$/),
});

const answerRecordSchema = z.object({
  questionId: z.string().max(100),
  topic: z.string().max(100),
  subtopic: z.string().max(100),
  difficulty: z.enum(DIFFICULTIES),
  question: z.string().max(2000),
  options: z.array(z.string().max(500)).max(6),
  selectedIndex: z.number().int().nullable(),
  correctIndex: z.number().int(),
  isCorrect: z.boolean(),
  explanation: z.string().max(3000),
  timeSpentSec: z.number().min(0).max(86400),
});

export const attemptSchema = z.object({
  id: z.string().trim().min(1).max(100),
  mode: z.enum(['adaptive', 'assignment']),
  title: z.string().max(200),
  topicFilter: z.string().max(100),
  completedAt: z.string().max(64),
  score: z.number().min(0).max(1_000_000),
  correctCount: z.number().int().min(0).max(10000),
  totalCount: z.number().int().min(0).max(10000),
  accuracyPercent: z.number().min(0).max(100),
  passed: z.boolean(),
  bestStreak: z.number().int().min(0).max(10000),
  bookmarkedIds: z.array(z.string().max(100)).max(1000).optional(),
  records: z.array(answerRecordSchema).max(500),
});

export const attemptQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export type QuestionInput = z.infer<typeof questionSchema>;
export type AttemptInput = z.infer<typeof attemptSchema>;
export type QuestionQuery = z.infer<typeof questionQuerySchema>;
