import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { sampleAttempt, sampleQuestion } from './helpers';
import { startServer, type RunningServer } from './server';

const json = (body: unknown): RequestInit => ({
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
});

describe('QuizQuake HTTP API', () => {
  let srv: RunningServer;

  beforeAll(async () => {
    srv = await startServer();
  });
  afterAll(async () => {
    await srv.close();
  });

  describe('health & hardening', () => {
    it('reports status and database counts', async () => {
      const res = await fetch(`${srv.base}/api/health`);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.status).toBe('ok');
      expect(body.database.questions).toBeGreaterThan(0);
    });

    it('sets security headers, a request id, and hides the framework', async () => {
      const res = await fetch(`${srv.base}/api/health`);
      expect(res.headers.get('x-content-type-options')).toBe('nosniff');
      expect(res.headers.get('x-request-id')).toBeTruthy();
      expect(res.headers.get('x-powered-by')).toBeNull();
    });

    it('returns a JSON 404 for unknown API routes', async () => {
      const res = await fetch(`${srv.base}/api/nope`);
      expect(res.status).toBe(404);
      expect((await res.json()).error.code).toBe('NOT_FOUND');
    });
  });

  describe('GET /api/questions', () => {
    it('returns the seeded bank with paging metadata', async () => {
      const body = await (await fetch(`${srv.base}/api/questions`)).json();
      expect(body.total).toBe(body.questions.length);
      expect(body.questions[0]).not.toHaveProperty('source');
      expect(body.questions[0].options.length).toBeGreaterThanOrEqual(2);
    });

    it('filters by topic and difficulty', async () => {
      const body = await (await fetch(`${srv.base}/api/questions?topic=Algorithms&difficulty=Hard`)).json();
      expect(body.questions.length).toBeGreaterThan(0);
      for (const q of body.questions) {
        expect(q.topic).toBe('Algorithms');
        expect(q.difficulty).toBe('Hard');
      }
    });

    it('rejects an invalid difficulty with 400 and field details', async () => {
      const res = await fetch(`${srv.base}/api/questions?difficulty=Nightmare`);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error.code).toBe('BAD_REQUEST');
      expect(body.error.details[0].path).toBe('difficulty');
    });

    it('is not vulnerable to SQL injection through filters', async () => {
      const res = await fetch(`${srv.base}/api/questions?topic=${encodeURIComponent("' OR 1=1 --")}`);
      expect(res.status).toBe(200);
      expect((await res.json()).total).toBe(0);
    });

    it('lists distinct topics', async () => {
      const body = await (await fetch(`${srv.base}/api/topics`)).json();
      expect(body.topics).toEqual(expect.arrayContaining(['Algorithms', 'Data Structures']));
    });
  });

  describe('POST /api/questions', () => {
    it('creates a custom question (201) then updates it (200)', async () => {
      const first = await fetch(`${srv.base}/api/questions`, json(sampleQuestion()));
      expect(first.status).toBe(201);
      const second = await fetch(`${srv.base}/api/questions`, json(sampleQuestion({ explanation: 'Edited' })));
      expect(second.status).toBe(200);
      const list = await (await fetch(`${srv.base}/api/questions?topic=Databases`)).json();
      expect(list.total).toBe(1);
      expect(list.questions[0].explanation).toBe('Edited');
    });

    it('rejects an out-of-range correctIndex', async () => {
      const res = await fetch(`${srv.base}/api/questions`, json(sampleQuestion({ id: 'bad', correctIndex: 9 })));
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error.details.some((d: { path: string }) => d.path === 'correctIndex')).toBe(true);
    });

    it('rejects malformed JSON with a clear error', async () => {
      const res = await fetch(`${srv.base}/api/questions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{ not json',
      });
      expect(res.status).toBe(400);
      expect((await res.json()).error.code).toBe('INVALID_JSON');
    });

    it('rejects oversized payloads with 413', async () => {
      const res = await fetch(`${srv.base}/api/questions`, json({ blob: 'x'.repeat(1_200_000) }));
      expect(res.status).toBe(413);
    });

    it('refuses to overwrite a built-in question', async () => {
      const res = await fetch(`${srv.base}/api/questions`, json(sampleQuestion({ id: 'qq-01' })));
      expect(res.status).toBe(409);
    });

    it('bulk-imports valid batches atomically and rejects batches with invalid items', async () => {
      const ok = await fetch(
        `${srv.base}/api/questions/bulk`,
        json({ questions: [sampleQuestion({ id: 'bulk-1' }), sampleQuestion({ id: 'bulk-2' })] })
      );
      expect(ok.status).toBe(201);
      expect((await ok.json()).imported).toBe(2);

      const bad = await fetch(
        `${srv.base}/api/questions/bulk`,
        json({ questions: [sampleQuestion({ id: 'bulk-3' }), sampleQuestion({ id: 'bulk-4', correctIndex: 99 })] })
      );
      expect(bad.status).toBe(400);
      expect(srv.ctx.questions.getById('bulk-3')).toBeNull();
    });
  });

  describe('DELETE /api/questions/:id', () => {
    it('deletes custom questions, protects built-ins, 404s unknown ids', async () => {
      await fetch(`${srv.base}/api/questions`, json(sampleQuestion({ id: 'to-delete' })));
      expect((await fetch(`${srv.base}/api/questions/to-delete`, { method: 'DELETE' })).status).toBe(200);
      expect((await fetch(`${srv.base}/api/questions/to-delete`, { method: 'DELETE' })).status).toBe(404);
      expect((await fetch(`${srv.base}/api/questions/qq-01`, { method: 'DELETE' })).status).toBe(403);
    });

    it('rejects unsafe ids', async () => {
      const res = await fetch(`${srv.base}/api/questions/${encodeURIComponent("x'; DROP TABLE questions;--")}`, { method: 'DELETE' });
      expect(res.status).toBe(400);
    });
  });

  describe('attempts & stats', () => {
    it('stores and lists attempts', async () => {
      const res = await fetch(`${srv.base}/api/attempts`, json(sampleAttempt()));
      expect(res.status).toBe(201);
      const body = await (await fetch(`${srv.base}/api/attempts?limit=5`)).json();
      expect(body.attempts[0]).toMatchObject({ id: 'attempt-1', passed: true });
    });

    it('rejects an invalid attempt', async () => {
      const res = await fetch(`${srv.base}/api/attempts`, json({ ...sampleAttempt(), accuracyPercent: 500 }));
      expect(res.status).toBe(400);
    });

    it('serves per-topic stats', async () => {
      const body = await (await fetch(`${srv.base}/api/stats`)).json();
      expect(body.totalAttempts).toBeGreaterThanOrEqual(1);
      expect(body.topics[0]).toHaveProperty('averageAccuracy');
    });
  });

  describe('rate limiting & CORS', () => {
    it('returns 429 once the write limit is exhausted', async () => {
      const limited = await startServer({ config: { writeRateLimitMax: 2 } });
      try {
        const statuses: number[] = [];
        for (let i = 0; i < 4; i++) {
          const r = await fetch(`${limited.base}/api/questions`, json(sampleQuestion({ id: `rl-${i}` })));
          statuses.push(r.status);
        }
        expect(statuses.slice(0, 2)).toEqual([201, 201]);
        expect(statuses.slice(2)).toEqual([429, 429]);
      } finally {
        await limited.close();
      }
    });

    it('only echoes allow-listed origins', async () => {
      const allowed = await fetch(`${srv.base}/api/health`, { headers: { Origin: 'http://localhost:5173' } });
      expect(allowed.headers.get('access-control-allow-origin')).toBe('http://localhost:5173');
      const denied = await fetch(`${srv.base}/api/health`, { headers: { Origin: 'https://evil.example' } });
      expect(denied.headers.get('access-control-allow-origin')).toBeNull();
    });
  });
});
