import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createContext, sampleAttempt } from './helpers';

describe('AttemptRepository', () => {
  let ctx: ReturnType<typeof createContext>;

  beforeEach(() => {
    ctx = createContext();
  });
  afterEach(() => ctx.db.close());

  it('saves and returns attempts with their answer records', () => {
    ctx.attempts.save(sampleAttempt());
    const [saved] = ctx.attempts.recent();
    expect(saved).toMatchObject({ id: 'attempt-1', passed: true, score: 80, mode: 'assignment' });
    expect(saved.records).toHaveLength(1);
    expect(saved.records[0].isCorrect).toBe(true);
  });

  it('is idempotent for the same attempt id', () => {
    ctx.attempts.save(sampleAttempt());
    ctx.attempts.save(sampleAttempt({ score: 95 }));
    expect(ctx.attempts.count()).toBe(1);
    expect(ctx.attempts.recent()[0].score).toBe(95);
  });

  it('respects the limit and returns newest first', () => {
    for (let i = 1; i <= 5; i++) ctx.attempts.save(sampleAttempt({ id: `a${i}` }));
    expect(ctx.attempts.recent(2).map((a) => a.id)).toEqual(['a5', 'a4']);
  });

  it('aggregates per-topic statistics', () => {
    ctx.attempts.save(sampleAttempt({ id: 'x1', topicFilter: 'Algorithms', accuracyPercent: 60, score: 50 }));
    ctx.attempts.save(sampleAttempt({ id: 'x2', topicFilter: 'Algorithms', accuracyPercent: 80, score: 90 }));
    ctx.attempts.save(sampleAttempt({ id: 'x3', topicFilter: 'Networks', accuracyPercent: 100, score: 70 }));
    const stats = ctx.attempts.topicStats();
    expect(stats[0]).toEqual({ topic: 'Algorithms', attempts: 2, averageAccuracy: 70, bestScore: 90 });
    expect(stats[1]).toMatchObject({ topic: 'Networks', attempts: 1 });
  });
});
