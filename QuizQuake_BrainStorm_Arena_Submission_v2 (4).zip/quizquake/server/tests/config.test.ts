import { describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config';

describe('loadConfig', () => {
  it('uses safe defaults', () => {
    const c = loadConfig({});
    expect(c.port).toBe(4000);
    expect(c.logLevel).toBe('info');
    expect(c.corsOrigins).toContain('http://localhost:5173');
    expect(c.isProduction).toBe(false);
  });

  it('reads overrides from the environment', () => {
    const c = loadConfig({ PORT: '8080', LOG_LEVEL: 'debug', CORS_ORIGINS: 'https://a.test, https://b.test', NODE_ENV: 'production' });
    expect(c.port).toBe(8080);
    expect(c.logLevel).toBe('debug');
    expect(c.corsOrigins).toEqual(['https://a.test', 'https://b.test']);
    expect(c.isProduction).toBe(true);
  });

  it('fails fast on invalid values', () => {
    expect(() => loadConfig({ PORT: 'abc' })).toThrow(/PORT/);
    expect(() => loadConfig({ PORT: '70000' })).toThrow(/PORT/);
    expect(() => loadConfig({ LOG_LEVEL: 'loud' })).toThrow(/LOG_LEVEL/);
  });
});
