import path from 'path';
import type { AppConfig } from '../src/config';
import { openDatabase, seedIfEmpty } from '../src/db/database';
import { createLogger } from '../src/logger';
import { AttemptRepository } from '../src/repositories/attemptRepository';
import { QuestionRepository } from '../src/repositories/questionRepository';
import type { AttemptInput, QuestionInput } from '../src/validation/schemas';

export const SEED_PATH = path.join(__dirname, '..', 'data', 'questions.json');

export function testConfig(overrides: Partial<AppConfig> = {}): AppConfig {
  return {
    port: 0,
    dbPath: ':memory:',
    seedPath: SEED_PATH,
    clientDist: path.join(__dirname, 'does-not-exist'),
    corsOrigins: ['http://localhost:5173'],
    logLevel: 'silent',
    rateLimitMax: 10000,
    writeRateLimitMax: 10000,
    isProduction: false,
    ...overrides,
  };
}

export function createContext(options: { seed?: boolean; config?: Partial<AppConfig> } = {}) {
  const db = openDatabase(':memory:');
  const questions = new QuestionRepository(db);
  const attempts = new AttemptRepository(db);
  const logger = createLogger('silent');
  const config = testConfig(options.config);
  if (options.seed) seedIfEmpty(questions, config.seedPath, logger);
  return { db, questions, attempts, logger, config };
}

export function sampleQuestion(overrides: Partial<QuestionInput> = {}): QuestionInput {
  return {
    id: 'custom-1',
    topic: 'Databases',
    subtopic: 'Indexes',
    difficulty: 'Medium',
    question: 'Which structure do most relational databases use for indexes?',
    options: ['B-Tree', 'Stack', 'Queue', 'Linked list'],
    correctIndex: 0,
    explanation: 'B-Trees keep keys sorted and give O(log n) lookups.',
    ...overrides,
  };
}

export function sampleAttempt(overrides: Partial<AttemptInput> = {}): AttemptInput {
  return {
    id: 'attempt-1',
    mode: 'assignment',
    title: 'Data Structures assignment',
    topicFilter: 'Data Structures',
    completedAt: '2026-11-20T10:00:00.000Z',
    score: 80,
    correctCount: 4,
    totalCount: 5,
    accuracyPercent: 80,
    passed: true,
    bestStreak: 3,
    records: [
      {
        questionId: 'qq-01',
        topic: 'Data Structures',
        subtopic: 'Arrays & Lists',
        difficulty: 'Easy',
        question: 'Access by index complexity?',
        options: ['O(1)', 'O(n)'],
        selectedIndex: 0,
        correctIndex: 0,
        isCorrect: true,
        explanation: 'Direct offset.',
        timeSpentSec: 4,
      },
    ],
    ...overrides,
  };
}
