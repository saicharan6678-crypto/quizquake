import { describe, expect, it } from 'vitest';
import { createLogger, serializeError } from '../src/logger';

describe('server logger', () => {
  it('emits JSON lines with level, message, bindings and meta', () => {
    const lines: string[] = [];
    const log = createLogger('info', { service: 'qq' }, (l) => lines.push(l));
    log.info('hello', { requestId: 'r1' });
    const entry = JSON.parse(lines[0]);
    expect(entry).toMatchObject({ level: 'info', msg: 'hello', service: 'qq', requestId: 'r1' });
    expect(typeof entry.ts).toBe('string');
  });

  it('filters messages below the configured level', () => {
    const lines: string[] = [];
    const log = createLogger('warn', {}, (l) => lines.push(l));
    log.debug('d');
    log.info('i');
    log.warn('w');
    log.error('e');
    expect(lines.map((l) => JSON.parse(l).msg)).toEqual(['w', 'e']);
  });

  it('is fully silent at level "silent" and child loggers inherit bindings', () => {
    const lines: string[] = [];
    createLogger('silent', {}, (l) => lines.push(l)).error('nope');
    expect(lines).toHaveLength(0);
    const child = createLogger('info', { a: 1 }, (l) => lines.push(l)).child({ b: 2 });
    child.info('x');
    expect(JSON.parse(lines[0])).toMatchObject({ a: 1, b: 2 });
  });

  it('serialises Error and non-Error values', () => {
    expect(serializeError(new Error('boom'))).toMatchObject({ errorName: 'Error', errorMessage: 'boom' });
    expect(serializeError('text')).toEqual({ errorMessage: 'text' });
  });
});
