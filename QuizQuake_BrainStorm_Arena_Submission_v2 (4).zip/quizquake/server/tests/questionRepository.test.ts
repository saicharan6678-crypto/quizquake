import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createContext, sampleQuestion } from './helpers';

describe('QuestionRepository', () => {
  let ctx: ReturnType<typeof createContext>;

  beforeEach(() => {
    ctx = createContext();
  });
  afterEach(() => ctx.db.close());

  it('starts empty', () => {
    expect(ctx.questions.count()).toBe(0);
    expect(ctx.questions.list({})).toEqual([]);
    expect(ctx.questions.topics()).toEqual([]);
  });

  it('round-trips a question including its options array', () => {
    ctx.questions.upsert(sampleQuestion());
    const stored = ctx.questions.getById('custom-1');
    expect(stored).toMatchObject({ topic: 'Databases', correctIndex: 0, source: 'custom' });
    expect(stored?.options).toEqual(['B-Tree', 'Stack', 'Queue', 'Linked list']);
  });

  it('updates an existing custom question instead of duplicating it', () => {
    ctx.questions.upsert(sampleQuestion());
    ctx.questions.upsert(sampleQuestion({ question: 'Updated text?' }));
    expect(ctx.questions.count()).toBe(1);
    expect(ctx.questions.getById('custom-1')?.question).toBe('Updated text?');
  });

  it('filters by topic and difficulty and paginates', () => {
    ctx.questions.upsertMany([
      sampleQuestion({ id: 'a', difficulty: 'Easy' }),
      sampleQuestion({ id: 'b', difficulty: 'Hard' }),
      sampleQuestion({ id: 'c', topic: 'Networks', difficulty: 'Hard' }),
    ]);
    expect(ctx.questions.count({ topic: 'Databases' })).toBe(2);
    expect(ctx.questions.list({ difficulty: 'Hard' }).map((q) => q.id)).toEqual(['b', 'c']);
    expect(ctx.questions.list({}, 1, 1).map((q) => q.id)).toEqual(['b']);
    expect(ctx.questions.topics()).toEqual(['Databases', 'Networks']);
  });

  it('treats SQL metacharacters in filters as plain data', () => {
    ctx.questions.upsert(sampleQuestion());
    expect(ctx.questions.list({ topic: "' OR '1'='1" })).toEqual([]);
    expect(ctx.questions.count()).toBe(1);
  });

  it('upsertMany is atomic: a failing item rolls back the whole batch', () => {
    const bad = { ...sampleQuestion({ id: 'bad' }), difficulty: 'Nope' as never };
    expect(() => ctx.questions.upsertMany([sampleQuestion({ id: 'good' }), bad])).toThrow();
    expect(ctx.questions.count()).toBe(0);
  });

  it('never lets a custom question overwrite a built-in one', () => {
    ctx.questions.upsert(sampleQuestion({ id: 'seed-1', question: 'Original?' }), 'seed');
    ctx.questions.upsert(sampleQuestion({ id: 'seed-1', question: 'Hijacked?' }), 'custom');
    expect(ctx.questions.getById('seed-1')?.question).toBe('Original?');
  });

  it('delete reports deleted / not_found / protected', () => {
    ctx.questions.upsert(sampleQuestion({ id: 'mine' }));
    ctx.questions.upsert(sampleQuestion({ id: 'builtin' }), 'seed');
    expect(ctx.questions.delete('mine')).toBe('deleted');
    expect(ctx.questions.delete('mine')).toBe('not_found');
    expect(ctx.questions.delete('builtin')).toBe('protected');
    expect(ctx.questions.getById('builtin')).not.toBeNull();
  });
});
