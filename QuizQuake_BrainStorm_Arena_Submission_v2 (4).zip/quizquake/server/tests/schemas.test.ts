import { describe, expect, it } from 'vitest';
import { attemptSchema, idParamSchema, questionQuerySchema, questionSchema } from '../src/validation/schemas';
import { sampleAttempt, sampleQuestion } from './helpers';

describe('questionSchema', () => {
  it('accepts a well-formed question and trims whitespace', () => {
    const result = questionSchema.safeParse(sampleQuestion({ topic: '  Databases  ' }));
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.topic).toBe('Databases');
  });

  it('defaults a missing explanation to an empty string', () => {
    const { explanation: _omit, ...rest } = sampleQuestion();
    const result = questionSchema.safeParse(rest);
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.explanation).toBe('');
  });

  it('strips unknown properties', () => {
    const result = questionSchema.safeParse({ ...sampleQuestion(), isAdmin: true });
    expect(result.success).toBe(true);
    if (result.success) expect('isAdmin' in result.data).toBe(false);
  });

  it.each([
    ['correctIndex beyond options', { correctIndex: 4 }],
    ['negative correctIndex', { correctIndex: -1 }],
    ['fractional correctIndex', { correctIndex: 1.5 }],
    ['unknown difficulty', { difficulty: 'Impossible' }],
    ['only one option', { options: ['A'], correctIndex: 0 }],
    ['more than six options', { options: ['1', '2', '3', '4', '5', '6', '7'] }],
    ['blank option', { options: ['A', '  ', 'C', 'D'] }],
    ['empty question text', { question: '   ' }],
    ['id with spaces/slashes', { id: '../etc/passwd' }],
    ['overlong question', { question: 'x'.repeat(2001) }],
  ])('rejects %s', (_label, patch) => {
    expect(questionSchema.safeParse(sampleQuestion(patch as never)).success).toBe(false);
  });

  it('rejects non-object payloads', () => {
    expect(questionSchema.safeParse(null).success).toBe(false);
    expect(questionSchema.safeParse('hello').success).toBe(false);
    expect(questionSchema.safeParse([]).success).toBe(false);
  });
});

describe('questionQuerySchema', () => {
  it('applies defaults', () => {
    const r = questionQuerySchema.parse({});
    expect(r).toEqual({ topic: undefined, difficulty: undefined, limit: 1000, offset: 0 });
  });

  it('treats "All" and empty strings as no filter', () => {
    const r = questionQuerySchema.parse({ topic: 'All', difficulty: '' });
    expect(r.topic).toBeUndefined();
    expect(r.difficulty).toBeUndefined();
  });

  it('coerces numeric strings and enforces bounds', () => {
    expect(questionQuerySchema.parse({ limit: '5', offset: '10' })).toMatchObject({ limit: 5, offset: 10 });
    expect(questionQuerySchema.safeParse({ limit: '0' }).success).toBe(false);
    expect(questionQuerySchema.safeParse({ limit: '5000' }).success).toBe(false);
    expect(questionQuerySchema.safeParse({ offset: '-1' }).success).toBe(false);
  });

  it('rejects an invalid difficulty', () => {
    expect(questionQuerySchema.safeParse({ difficulty: 'Nightmare' }).success).toBe(false);
  });
});

describe('idParamSchema', () => {
  it('accepts safe ids and rejects unsafe ones', () => {
    expect(idParamSchema.safeParse({ id: 'qq-01' }).success).toBe(true);
    expect(idParamSchema.safeParse({ id: "x'; DROP TABLE questions;--" }).success).toBe(false);
  });
});

describe('attemptSchema', () => {
  it('accepts a valid attempt', () => {
    expect(attemptSchema.safeParse(sampleAttempt()).success).toBe(true);
  });

  it('rejects out-of-range accuracy and unknown modes', () => {
    expect(attemptSchema.safeParse(sampleAttempt({ accuracyPercent: 140 })).success).toBe(false);
    expect(attemptSchema.safeParse({ ...sampleAttempt(), mode: 'cheat' }).success).toBe(false);
  });
});
