import fs from 'fs';
import os from 'os';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { seedIfEmpty } from '../src/db/database';
import { createContext, SEED_PATH } from './helpers';

describe('seedIfEmpty', () => {
  it('imports every bundled question and is idempotent', () => {
    const ctx = createContext();
    const expected = (JSON.parse(fs.readFileSync(SEED_PATH, 'utf-8')) as unknown[]).length;
    expect(seedIfEmpty(ctx.questions, SEED_PATH, ctx.logger)).toBe(expected);
    expect(ctx.questions.count()).toBe(expected);
    expect(seedIfEmpty(ctx.questions, SEED_PATH, ctx.logger)).toBe(0);
    expect(ctx.questions.count()).toBe(expected);
    ctx.db.close();
  });

  it('survives a missing seed file without crashing', () => {
    const ctx = createContext();
    expect(seedIfEmpty(ctx.questions, '/no/such/file.json', ctx.logger)).toBe(0);
    ctx.db.close();
  });

  it('skips invalid seed entries but keeps valid ones', () => {
    const ctx = createContext();
    const file = path.join(os.tmpdir(), `qq-seed-${Date.now()}.json`);
    fs.writeFileSync(
      file,
      JSON.stringify([
        { id: 'ok', topic: 'T', subtopic: 'S', difficulty: 'Easy', question: 'Q?', options: ['a', 'b'], correctIndex: 1, explanation: '' },
        { id: 'broken', topic: 'T' },
      ])
    );
    expect(seedIfEmpty(ctx.questions, file, ctx.logger)).toBe(1);
    fs.unlinkSync(file);
    ctx.db.close();
  });
});
