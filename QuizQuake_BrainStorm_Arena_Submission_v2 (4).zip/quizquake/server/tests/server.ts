import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { createApp } from '../src/app';
import type { AppConfig } from '../src/config';
import { createContext } from './helpers';

export interface RunningServer {
  base: string;
  close: () => Promise<void>;
  ctx: ReturnType<typeof createContext>;
}

export async function startServer(options: { seed?: boolean; config?: Partial<AppConfig> } = {}): Promise<RunningServer> {
  const ctx = createContext({ seed: true, ...options });
  const app = createApp(ctx);
  const server: Server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const { port } = server.address() as AddressInfo;
  return {
    base: `http://127.0.0.1:${port}`,
    ctx,
    close: () =>
      new Promise<void>((resolve) => {
        server.close(() => {
          ctx.db.close();
          resolve();
        });
      }),
  };
}
